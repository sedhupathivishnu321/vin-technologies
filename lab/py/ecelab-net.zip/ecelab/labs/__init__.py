from ..net import examples as _nx

if "Computer Networks Lab" not in _nx.GROUPS:
    _nx.GROUPS.append("Computer Networks Lab")
from . import net_lab  # noqa: E402,F401
