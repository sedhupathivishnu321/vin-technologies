"""Computer Networks Laboratory: ARP, subnetting, routing, traceroute and TTL, loss and RTT, packet size, queues, TCP congestion, VLAN trunks, file transfer."""
from __future__ import annotations

from ..net.examples import ex, _c
from ..net.model import NetProject

G = "Computer Networks Lab"


def _chain(apps_h1="", ttl_note=False):
    """H1 - R1 - R2 - R3 - H2 on four subnets with static routes."""
    p = NetProject("Three routers")
    h1 = p.add_node("host", 40, 160, name="H1", ip="10.0.0.2/24", gateway="10.0.0.1", apps=apps_h1)
    r1 = p.add_node("router", 220, 160, name="R1", ips="p1=10.0.0.1/24\np2=10.0.1.1/24", routes="10.0.2.0/24 via 10.0.1.2\n10.0.3.0/24 via 10.0.1.2")
    r2 = p.add_node("router", 420, 160, name="R2", ips="p1=10.0.1.2/24\np2=10.0.2.1/24", routes="10.0.0.0/24 via 10.0.1.1\n10.0.3.0/24 via 10.0.2.2")
    r3 = p.add_node("router", 620, 160, name="R3", ips="p1=10.0.2.2/24\np2=10.0.3.1/24", routes="10.0.0.0/24 via 10.0.2.1\n10.0.1.0/24 via 10.0.2.1")
    h2 = p.add_node("host", 800, 160, name="H2", ip="10.0.3.2/24", gateway="10.0.3.1")
    for a, b in ((h1, r1), (r1, r2), (r2, r3), (r3, h2)):
        p.connect(a, b, mbps=100, delay_ms=2)
    return p


@ex("cn_arp", G, "ARP packet inspection", "Watch H1 resolve H2's MAC address with ARP: one broadcast request, one unicast reply, then the answer is cached.",
    "Before an IP packet can be sent on Ethernet the sender needs the next hop's MAC address. It broadcasts 'who-has 192.168.1.2?'; the owner replies 'is-at <MAC>'. The sender caches the answer (see the ARP cache in the block's property panel while replaying), so later pings need no ARP.",
    ["Press ▶ Run network and watch the first packets: ARP? broadcast, ARP! reply, then ping / pong.", "Click a packet on the canvas (or a row in the capture list) to decode the Ethernet and ARP headers.",
     "Select H1 and scrub the time slider: its ARP cache is empty before the reply and has one entry after."], 4.0)
def _arp():
    def build():
        p = NetProject("ARP")
        sw = p.add_node("switch", 300, 160, name="SW")
        h1 = p.add_node("host", 100, 160, name="H1", ip="192.168.1.1/24", apps="ping 192.168.1.2 count=4 interval=0.5")
        h2 = p.add_node("host", 500, 160, name="H2", ip="192.168.1.2/24")
        p.connect(h1, sw); p.connect(h2, sw)
        return p

    def check(res):
        cap = res["capture"]
        return [_c("Exactly one ARP request broadcast by H1", sum(1 for c in cap if c["summary"].startswith("ARP who-has") and c["src"] == "H1") == 1),
                _c("H2 answered with a unicast ARP reply", any("is-at" in c["summary"] and c["src"] == "H2" for c in cap)),
                _c("All 4 pings answered", res["pings"][0]["received"] == 4)]
    return build, check


@ex("cn_subnet", G, "IP subnetting (two /26 subnets)", "Split 10.0.0.0/24 into two /26 subnets joined by a router: hosts in one subnet talk directly, hosts in the other need the router.",
    "A /26 mask leaves 6 host bits: 62 hosts per subnet (10.0.0.0–63 and 10.0.0.64–127). A host compares the destination with its own network: inside the subnet it ARPs for the destination, outside it sends to the default gateway.",
    ["Run: A → B stays inside 10.0.0.0/26 (no router hop); A → C crosses R1 (two extra hops, TTL 63).", "Change C's mask to /24 and run again: C no longer sees the subnet split and the ping fails."], 6.0)
def _subnet():
    def build():
        p = NetProject("Subnetting")
        sw1 = p.add_node("switch", 220, 100, name="SW1"); sw2 = p.add_node("switch", 220, 280, name="SW2")
        r = p.add_node("router", 420, 190, name="R1", ips="p1=10.0.0.1/26\np2=10.0.0.65/26")
        a = p.add_node("host", 40, 60, name="A", ip="10.0.0.10/26", gateway="10.0.0.1", apps="ping 10.0.0.11 count=3 interval=0.5\nping 10.0.0.70 count=3 interval=0.5 start=2")
        b = p.add_node("host", 40, 140, name="B", ip="10.0.0.11/26", gateway="10.0.0.1")
        c = p.add_node("host", 40, 280, name="C", ip="10.0.0.70/26", gateway="10.0.0.65")
        p.connect(a, sw1); p.connect(b, sw1); p.connect(sw1, r); p.connect(r, sw2); p.connect(c, sw2)
        return p

    def check(res):
        near, far = res["pings"]
        return [_c("A → B (same /26) answered", near["received"] == 3), _c("A → C (other /26, via router) answered", far["received"] == 3),
                _c("Crossing the router costs extra delay", far["rtt_min"] > near["rtt_min"], f"{near['rtt_min']:.2f} ms vs {far['rtt_min']:.2f} ms"),
                _c("Router forwarded the packets for the second subnet", any(n["node"] == "R1" and n.get("forwarded", 0) >= 3 for n in res["nodes"]))]
    return build, check


@ex("cn_static_routing", G, "Static routing across three routers", "H1 reaches H2 through R1, R2 and R3, each with a static route toward the far side.",
    "Each router forwards by longest-prefix match: directly connected networks first, then static routes ('network via next-hop'). Every router decrements the TTL, so a packet arriving at H2 has TTL 64 − 3 = 61. Return routes must exist too.",
    ["Run: pings answered. Click a ping packet near H2 and read its TTL.", "Delete the route '10.0.0.0/24 via 10.0.2.1' from R3: replies are lost (no route back)."], 6.0)
def _static():
    def build():
        return _chain("ping 10.0.3.2 count=4 interval=0.5")

    def check(res):
        ping = res["pings"][0]
        fwd = {n["node"]: n.get("forwarded", 0) for n in res["nodes"]}
        return [_c("All pings answered", ping["received"] == 4), _c("Each router forwarded the traffic both ways", all(fwd.get(r, 0) >= 8 for r in ("R1", "R2", "R3")), str(fwd)),
                _c("TTL 61 at the destination", any("ttl=61" in c["summary"] and "echo " in c["summary"] for c in res["capture"]))]
    return build, check


@ex("cn_traceroute", G, "Traceroute: discovering the path with TTL", "Send probes with TTL 1, 2, 3 …: every router that discards one reveals itself with an ICMP 'time exceeded'.",
    "A router decrements the TTL; at zero it drops the packet and returns ICMP time-exceeded from its own address. By raising the TTL one at a time the sender learns each hop and its round-trip time. The destination finally answers with an echo reply.",
    ["Run: watch the probes (ping) die at R1, then R2, then R3; the 'TTL!' packets come back.", "Open the Summary tab: the hop list with RTT per hop."], 8.0)
def _trace():
    def build():
        return _chain("trace 10.0.3.2 hops=8")

    def check(res):
        t = res["trace"][0]
        addrs = [h["addr"] for h in t["hops"]]
        rtts = [h["rtt_ms"] for h in t["hops"] if h["rtt_ms"] is not None]
        return [_c("Hops 10.0.0.1, 10.0.1.2, 10.0.2.2, 10.0.3.2", addrs == ["10.0.0.1", "10.0.1.2", "10.0.2.2", "10.0.3.2"], ", ".join(map(str, addrs))), _c("Destination reached", t["reached"]),
                _c("RTT grows with every hop", rtts == sorted(rtts), ", ".join(f"{x:.2f}" for x in rtts))]
    return build, check


@ex("cn_ttl", G, "TTL expiry and ICMP time-exceeded", "Ping with TTL 2 across three routers: the packet dies in R2 and the sender gets 'time exceeded' instead of a reply.",
    "The Time-To-Live field stops packets circling forever in routing loops. R1 makes it 1, R2 makes it 0 and drops the packet, sending ICMP type 11 back to the sender.",
    ["Run: no echo reply, but 'TTL exceeded' answers.", "Raise ttl to 4 in H1's ping line: the pings are answered."], 5.0)
def _ttl():
    def build():
        return _chain("ping 10.0.3.2 count=3 interval=0.5 ttl=2")

    def check(res):
        ping = res["pings"][0]
        return [_c("No echo replies", ping["received"] == 0), _c("3 'TTL exceeded' messages came back", ping["ttl_exceeded"] == 3, str(ping["ttl_exceeded"])),
                _c("R2 discarded the probes", any(n["node"] == "R2" and n.get("ttl_expired", 0) == 3 for n in res["nodes"]))]
    return build, check


@ex("cn_rtt_loss", G, "RTT and packet loss on a lossy link", "Ping 100 times over a link that loses 20 % of the frames in each direction and measure the loss and the RTT.",
    "A ping succeeds only if both the request and the reply survive: P(success) = (1 − p)² = 0.64, so about 36 % of the pings are lost. RTT is unaffected for those that arrive.",
    ["Run and read the Summary: loss percentage and RTT.", "Select the link and set Loss to 0 %: 0 % ping loss.", "Set it to 5 %: expect 1 − 0.95² ≈ 10 %."], 7.0)
def _rttloss():
    def build():
        p = NetProject("RTT and loss")
        a = p.add_node("host", 100, 160, name="A", ip="10.0.0.1/24", apps="ping 10.0.0.2 count=200 interval=0.03 start=0.2")
        b = p.add_node("host", 500, 160, name="B", ip="10.0.0.2/24")
        p.connect(a, b, mbps=10, delay_ms=10, loss=20.0)
        return p

    def check(res):
        ping = res["pings"][0]
        return [_c("Ping loss ≈ 1 − 0.8² = 36 % (25–48 %)", 25.0 < ping["loss"] < 48.0, f"{ping['loss']:.1f} %"),
                _c("RTT of delivered pings ≈ 2·(10 ms + serialisation)", ping["rtt_min"] is not None and 20.0 < ping["rtt_min"] < 21.0, f"{ping['rtt_min']:.3f} ms")]
    return build, check


@ex("cn_packet_size", G, "Packet size versus latency", "Ping with 64-byte and with 1400-byte packets over a slow 2 Mbit/s link and compare the round-trip times.",
    "Serialisation delay = bits / rate. Over 2 Mbit/s a 64-byte packet (+38 B Ethernet overhead) takes 0.41 ms, a 1400-byte packet 5.75 ms; the RTT grows by twice the difference because the reply is as large as the request.",
    ["Run: two ping lines, small packets then large ones.", "Raise the link rate to 100 Mbit/s: the difference nearly vanishes."], 8.0)
def _psize():
    def build():
        p = NetProject("Packet size")
        a = p.add_node("host", 100, 160, name="A", ip="10.0.0.1/24", apps="ping 10.0.0.2 count=3 interval=0.5 size=64 start=0.5\nping 10.0.0.2 count=3 interval=0.5 size=1400 start=3")
        b = p.add_node("host", 500, 160, name="B", ip="10.0.0.2/24")
        p.connect(a, b, mbps=2, delay_ms=5)
        return p

    def check(res):
        small, big = res["pings"]
        exp_small = 2 * ((64 + 38) * 8 / 2e6 + 5e-3) * 1e3; exp_big = 2 * ((1400 + 38) * 8 / 2e6 + 5e-3) * 1e3
        return [_c("Small-packet RTT ≈ 2·(0.41 ms + 5 ms)", abs(small["rtt_min"] - exp_small) < 0.05, f"{small['rtt_min']:.2f} ms vs {exp_small:.2f}"),
                _c("Large-packet RTT ≈ 2·(5.75 ms + 5 ms)", abs(big["rtt_min"] - exp_big) < 0.05, f"{big['rtt_min']:.2f} ms vs {exp_big:.2f}")]
    return build, check


@ex("cn_queue", G, "Queueing delay and loss on an overloaded link", "Offer 12 Mbit/s of UDP to a 10 Mbit/s link with a 20-packet queue: the queue fills, delay rises and about 1/6 of the packets are dropped.",
    "When the arrival rate exceeds the service rate the queue grows until it is full; then the excess is dropped (tail drop). Loss ≈ (λ − μ)/λ = 16.7 % and the queueing delay saturates at queue length × packet time.",
    ["Run and read the UDP loss and delay in the Summary.", "Select the bottleneck link and raise the queue to 200 packets: delay grows, loss shrinks (for a short burst).", "Lower the offered rate to 8 Mbit/s: no loss."], 8.0)
def _queue():
    def build():
        p = NetProject("Queue")
        a = p.add_node("host", 100, 160, name="A", ip="10.0.0.1/24", apps="udp 10.0.1.2:5001 rate=12M size=1000 dur=5 start=0.2")
        r = p.add_node("router", 300, 160, name="R", ips="p1=10.0.0.254/24\np2=10.0.1.254/24")
        b = p.add_node("host", 500, 160, name="B", ip="10.0.1.2/24", gateway="10.0.1.254")
        a.params["gateway"] = "10.0.0.254"
        p.connect(a, r, mbps=100, delay_ms=1); p.connect(r, b, mbps=10, delay_ms=1, queue=20)
        return p

    def check(res):
        u = res["udp"][0]
        return [_c("Loss ≈ 16.7 % (12–22 %)", 12.0 < u["loss"] < 22.0, f"{u['loss']:.1f} %"), _c("Delivered ≈ 10 Mbit/s of the offered 12", 8000 < u["throughput_kbps"] < 10500, f"{u['throughput_kbps']:.0f} kbit/s"),
                _c("Queueing adds delay (> 5 ms)", u["delay_ms"] is not None and u["delay_ms"] > 5.0, f"{u['delay_ms']:.1f} ms")]
    return build, check


@ex("cn_tcp_congestion", G, "TCP congestion control (slow start and loss recovery)", "Send 2 MB over a link that loses 1 % of the frames and watch the congestion window: slow start, then halving on loss.",
    "TCP Reno grows cwnd exponentially in slow start and linearly afterwards. Three duplicate ACKs trigger fast retransmit and halve cwnd; a timeout drops it to 1. Random loss therefore keeps the average window — and the throughput — far below the link rate.",
    ["Run and read the Summary: goodput, retransmissions, timeouts, maximum cwnd.", "Open What is happening: lines tagged TCP tell when the window was cut.", "Set the link loss to 0 %: the transfer is limited only by the 10 Mbit/s link."], 15.0)
def _tcp_cc():
    def build():
        p = NetProject("TCP congestion")
        a = p.add_node("host", 100, 160, name="A", ip="10.0.0.1/24", apps="tcp 10.0.0.2:80 bytes=2M start=0.2")
        b = p.add_node("host", 500, 160, name="B", ip="10.0.0.2/24")
        p.connect(a, b, mbps=10, delay_ms=20, loss=1.0, queue=50)
        return p

    def check(res):
        t = res["tcp"][0]
        return [_c("Transfer completed", t["state"] == "done"), _c("Loss caused retransmissions", t["retransmits"] > 0, str(t["retransmits"])),
                _c("Goodput clearly below the 10 Mbit/s link rate", t["goodput_mbps"] is not None and t["goodput_mbps"] < 8.0, f"{t['goodput_mbps']:.2f} Mbit/s"), _c("Window grew beyond 8 segments", t["max_cwnd"] > 8, f"{t['max_cwnd']:.0f}")]
    return build, check


@ex("cn_file_transfer", G, "File transfer over TCP: LAN versus WAN", "Copy a 500 kB file across a fast LAN and across a slow, long WAN link and compare the times.",
    "Transfer time ≈ size / goodput. On the LAN the 100 Mbit/s link and 1 ms delay keep the pipe full; on a 2 Mbit/s link with 40 ms delay the rate limit and the window dynamics dominate.",
    ["Run and compare the two TCP lines in the Summary.", "Raise the WAN link to 10 Mbit/s and compare again."], 20.0)
def _ftp():
    def build():
        p = NetProject("File transfer")
        a = p.add_node("host", 80, 100, name="A", ip="10.0.0.1/24", gateway="10.0.0.254", apps="tcp 10.0.0.2:21 bytes=500k start=0.2\ntcp 10.0.1.2:21 bytes=500k start=0.2")
        l = p.add_node("host", 80, 260, name="LAN-SRV", ip="10.0.0.2/24", gateway="10.0.0.254")
        sw = p.add_node("switch", 260, 180, name="SW")
        r = p.add_node("router", 440, 180, name="R", ips="p1=10.0.0.254/24\np2=10.0.1.254/24")
        w = p.add_node("host", 640, 180, name="WAN-SRV", ip="10.0.1.2/24", gateway="10.0.1.254")
        p.connect(a, sw, mbps=100, delay_ms=0.5); p.connect(l, sw, mbps=100, delay_ms=0.5); p.connect(sw, r, mbps=100, delay_ms=0.5); p.connect(r, w, mbps=2, delay_ms=40, queue=60)
        return p

    def check(res):
        lan = next(t for t in res["tcp"] if t["flow"].endswith("10.0.0.2:21")); wan = next(t for t in res["tcp"] if t["flow"].endswith("10.0.1.2:21"))
        return [_c("Both transfers completed", lan["state"] == "done" and wan["state"] == "done"), _c("LAN is much faster than the WAN", lan["time_s"] * 5 < wan["time_s"], f"{lan['time_s']:.2f} s vs {wan['time_s']:.2f} s"),
                _c("WAN goodput below its 2 Mbit/s rate", wan["goodput_mbps"] < 2.0, f"{wan['goodput_mbps']:.2f} Mbit/s")]
    return build, check


@ex("cn_vlan_trunk", G, "VLANs across a trunk link", "Two switches carry VLAN 10 and VLAN 20 over one trunk: hosts of the same VLAN talk across the trunk, different VLANs stay isolated.",
    "Access ports belong to one VLAN; the trunk port tags frames with the VLAN id (802.1Q) so the far switch can deliver them to the right VLAN. Without a router, different VLANs cannot talk to each other at all.",
    ["Run: A1 ↔ B1 (VLAN 10) and A2 ↔ B2 (VLAN 20) are answered, A1 → B2 is not.", "Click a frame on the trunk link and read its VLAN tag in the Packet inspector."], 8.0)
def _vlan():
    def build():
        p = NetProject("VLAN trunk")
        s1 = p.add_node("switch", 260, 160, name="SW1", vlans="p1=10 p2=20 p3=trunk")
        s2 = p.add_node("switch", 520, 160, name="SW2", vlans="p1=trunk p2=10 p3=20")
        a1 = p.add_node("host", 100, 60, name="A1", ip="10.0.0.1/24", apps="ping 10.0.0.3 count=2 interval=0.5\nping 10.0.0.4 count=2 interval=0.5 start=1.5")
        a2 = p.add_node("host", 100, 260, name="A2", ip="10.0.0.2/24", apps="ping 10.0.0.4 count=2 interval=0.5 start=3")
        b1 = p.add_node("host", 680, 60, name="B1", ip="10.0.0.3/24")
        b2 = p.add_node("host", 680, 260, name="B2", ip="10.0.0.4/24")
        p.connect(a1, s1); p.connect(a2, s1); p.connect(s1, s2); p.connect(b1, s2); p.connect(b2, s2)
        return p

    def check(res):
        same, cross, same2 = res["pings"]
        return [_c("A1 → B1 (VLAN 10) answered", same["received"] == 2), _c("A1 → B2 (VLAN 10 → 20) blocked", cross["received"] == 0), _c("A2 → B2 (VLAN 20) answered", same2["received"] == 2),
                _c("Frames on the trunk carry a VLAN tag", any(c["vlan"] for c in res["capture"] if c["link"] == "SW1-SW2"))]
    return build, check
