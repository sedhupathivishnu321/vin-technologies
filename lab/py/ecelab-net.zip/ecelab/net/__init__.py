"""Computer-network simulation blocks (discrete-event engine, project model, examples)."""
