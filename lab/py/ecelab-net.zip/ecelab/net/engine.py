"""Discrete-event network simulator.

Blocks: Host (apps: ping, UDP constant-bit-rate flow, TCP bulk transfer with Reno congestion control, DNS query, DHCP client; services: DNS
server, DHCP server), Hub (shared-bandwidth repeater), Switch (MAC learning, flooding, access-port VLANs), Access point (a switch whose clients
connect over wireless links), Router / Firewall (static routing, TTL, ICMP errors, ordered allow/deny rules) and point-to-point Links
(rate, propagation delay, random loss, finite FIFO queue).

Everything is event driven: serialization time = bits / rate, queueing is real (a full queue drops), ARP is resolved on the wire, TCP
retransmits on timeout or three duplicate ACKs. Not modelled: collisions / CSMA-CD back-off, 802.11 contention, STP, routing protocols,
TCP options, IPv6. Results come from the simulated packets only; nothing is predetermined.
"""
from __future__ import annotations
import copy
import heapq
import ipaddress
import itertools
import math
import random
from dataclasses import dataclass, field

BCAST_MAC = "ff:ff:ff:ff:ff:ff"
BCAST_IP = "255.255.255.255"
ETH_OVH = 38            # preamble + start delimiter + header + FCS + inter-frame gap
IP_HDR, UDP_HDR, TCP_HDR, ICMP_HDR = 20, 8, 20, 8
MSS = 1460
MAX_EVENTS = 4_000_000


class NetError(Exception):
    pass


@dataclass
class Packet:
    id: int
    src_mac: str = ""
    dst_mac: str = ""
    etype: str = "IP"                 # IP | ARP
    vlan: int = 0
    op: str = ""                      # ARP: request | reply
    sip: str = ""
    tip: str = ""
    src: str = ""
    dst: str = ""
    ttl: int = 64
    proto: str = ""                   # ICMP | UDP | TCP
    sport: int = 0
    dport: int = 0
    flags: str = ""
    seq: int = 0
    ack: int = 0
    icmp: str = ""                    # echo | echo-reply | ttl-exceeded | unreachable
    size: int = 0                     # bytes above Ethernet
    data: dict = field(default_factory=dict)
    flow: str = ""
    t0: float = 0.0

    def wire_bytes(self):
        return max(self.size, 46) + ETH_OVH

    def label(self):
        """Very short tag drawn next to the moving packet."""
        if self.etype == "ARP":
            return "ARP?" if self.op == "request" else "ARP!"
        if self.proto == "ICMP":
            return {"echo": "ping", "echo-reply": "pong", "ttl-exceeded": "TTL!", "unreachable": "unreach"}.get(self.icmp, "ICMP")
        if self.proto == "TCP":
            if self.flags in ("SYN", "SYN-ACK", "FIN"):
                return self.flags
            return "DATA" if self.data.get("len", 0) > 0 else "ACK"
        if self.proto == "UDP":
            if 53 in (self.dport, self.sport):
                return "DNS?" if self.dport == 53 else "DNS!"
            if self.dport in (67, 68) or self.sport in (67, 68):
                return str(self.data.get("m", "DHCP"))
            return "UDP"
        return self.etype

    def layers(self):
        """Decoded headers, outermost first: [(layer, [(field, value), ...]), ...]"""
        eth = [("src MAC", self.src_mac), ("dst MAC", self.dst_mac), ("type", "ARP (0x0806)" if self.etype == "ARP" else "IPv4 (0x0800)")]
        if self.vlan:
            eth.append(("VLAN tag", self.vlan))
        out = [("Ethernet", eth)]
        if self.etype == "ARP":
            out.append(("ARP", [("operation", "request (who-has)" if self.op == "request" else "reply (is-at)"), ("sender IP", self.sip), ("target IP", self.tip)]))
            return out
        out.append(("IPv4", [("src", self.src), ("dst", self.dst), ("TTL", self.ttl), ("protocol", self.proto), ("length", f"{self.size} B")]))
        if self.proto == "TCP":
            out.append(("TCP", [("src port", self.sport), ("dst port", self.dport), ("flags", self.flags), ("seq", self.seq), ("ack", self.ack), ("payload", f"{self.data.get('len', 0)} B")]))
        elif self.proto == "UDP":
            rows = [("src port", self.sport), ("dst port", self.dport), ("payload", f"{max(self.size - IP_HDR - UDP_HDR, 0)} B")]
            if self.data.get("m"):
                rows.append(("message", self.data["m"]))
            out.append(("UDP", rows))
        elif self.proto == "ICMP":
            out.append(("ICMP", [("type", self.icmp), ("id", self.data.get("id", 0)), ("seq", self.seq)]))
        return out

    def summary(self):
        if self.etype == "ARP":
            return f"ARP who-has {self.tip} tell {self.sip}" if self.op == "request" else f"ARP {self.sip} is-at {self.src_mac}"
        if self.proto == "ICMP":
            return f"IP {self.src} > {self.dst} ICMP {self.icmp} id={self.data.get('id', 0)} seq={self.seq} ttl={self.ttl}"
        if self.proto == "TCP":
            return f"IP {self.src}:{self.sport} > {self.dst}:{self.dport} TCP [{self.flags}] seq={self.seq} ack={self.ack} len={self.data.get('len', 0)}"
        if self.proto == "UDP":
            extra = ""
            if self.dport in (53, 67, 68) or self.sport in (53, 67, 68):
                extra = " " + ("DNS " if 53 in (self.dport, self.sport) else "DHCP ") + str(self.data.get("m") or self.data.get("q") or "")
            return f"IP {self.src}:{self.sport} > {self.dst}:{self.dport} UDP len={self.size - IP_HDR - UDP_HDR}{extra}"
        return f"{self.etype} {self.src} > {self.dst}"


class Port:
    def __init__(self, node, idx):
        self.node, self.idx = node, idx
        self.name = f"p{idx + 1}"
        self.link = None
        self.mac = ""
        self.ip = None            # ipaddress.IPv4Address
        self.net = None           # ipaddress.IPv4Network
        self.vlan = 1
        self.trunk = False

    @property
    def peer(self):
        if self.link is None:
            return None
        a, b = self.link.ends
        return b if a is self else a

    def __repr__(self):
        return f"{self.node.name}.{self.name}"


class Link:
    def __init__(self, net, a: Port, b: Port, mbps=100.0, delay_ms=1.0, loss=0.0, queue=100, name="", wireless=False):
        self.net, self.ends = net, (a, b)
        a.link = b.link = self
        self.mbps, self.delay, self.loss, self.qlimit, self.wireless = float(mbps), delay_ms / 1000.0, float(loss), int(queue), wireless
        self.name = name or f"{a.node.name}-{b.node.name}"
        self.busy = {a: 0.0, b: 0.0}
        self.q = {a: 0, b: 0}
        self.bytes = {a: 0, b: 0}
        self.pkts = {a: 0, b: 0}
        self.drops_q = {a: 0, b: 0}
        self.drops_loss = {a: 0, b: 0}

    def transmit(self, src: Port, pkt: Packet):
        net = self.net
        dst = self.ends[1] if src is self.ends[0] else self.ends[0]
        if self.q[src] >= self.qlimit:
            self.drops_q[src] += 1
            net.note_drop(pkt, f"queue full on {src}", self.name)
            return
        tx = pkt.wire_bytes() * 8 / (self.mbps * 1e6)
        start = max(net.now, self.busy[src])
        self.busy[src] = start + tx
        self.q[src] += 1
        self.bytes[src] += pkt.wire_bytes()
        self.pkts[src] += 1
        net.at(start + tx, self._sent, src)
        if net.rng.random() < self.loss:
            self.drops_loss[src] += 1
            net.note_drop(pkt, f"lost on {self.name} (random loss)", self.name)
            return
        net.at(start + tx + self.delay, self._arrive, src, dst, pkt, start)

    def _sent(self, src):
        self.q[src] -= 1

    def _arrive(self, src, dst, pkt, t_start):
        self.net.record(self, src, dst, pkt, t_start)
        dst.node.receive(dst, pkt)


class Node:
    kind = "node"

    def __init__(self, net, name):
        self.net, self.name = net, name
        self.ports: list[Port] = []
        self.stats: dict = {}

    def add_port(self):
        p = Port(self, len(self.ports))
        p.mac = self.net.new_mac()
        self.ports.append(p)
        return p

    def count(self, key, n=1):
        self.stats[key] = self.stats.get(key, 0) + n

    def say(self, kind, text, **data):
        self.net.log(self.name, kind, text, **data)

    def receive(self, port, pkt):
        raise NotImplementedError


# ---------------------------------------------------------------------------------------------------------------- layer 2
class Hub(Node):
    """Repeater: every frame goes out of every other port; the hub's internal bus is shared, so bandwidth is shared too."""
    kind = "hub"

    def __init__(self, net, name):
        super().__init__(net, name)
        self.bus = 0.0

    def receive(self, port, pkt):
        self.count("frames")
        rate = min((p.link.mbps for p in self.ports if p.link), default=10.0) * 1e6
        t = max(self.net.now, self.bus) + pkt.wire_bytes() * 8 / rate
        self.bus = t
        self.say("flood", f"hub repeats {pkt.label()} out of every other port (shared bus, no filtering)", fwd=True)
        for p in self.ports:
            if p is not port and p.link:
                self.net.at(t, p.link.transmit, p, copy.copy(pkt))


class Switch(Node):
    """Learning bridge. Access ports carry one VLAN; a trunk port carries all of them."""
    kind = "switch"
    DELAY = 5e-6

    def __init__(self, net, name, ageing=300.0):
        super().__init__(net, name)
        self.table: dict = {}
        self.ageing = ageing

    def receive(self, port, pkt):
        self.count("frames")
        vlan = pkt.vlan if (port.trunk and pkt.vlan) else port.vlan
        old = self.table.get((vlan, pkt.src_mac))
        self.table[(vlan, pkt.src_mac)] = (port, self.net.now)
        if old is None or old[0] is not port:
            self.say("learn", f"learned {pkt.src_mac} is behind {port.name}" + (f" (VLAN {vlan})" if vlan else ""), table="mac", vlan=vlan, mac=pkt.src_mac, port=port.name)
        out = None
        if pkt.dst_mac != BCAST_MAC:
            hit = self.table.get((vlan, pkt.dst_mac))
            if hit and self.net.now - hit[1] <= self.ageing:
                out = hit[0]
        if out is port:
            self.count("filtered")
            self.say("filter", f"destination {pkt.dst_mac} is on the same port ({port.name}): frame filtered", fwd=True)
            return
        targets = [out] if out else [p for p in self.ports if p is not port and p.link]
        if not out:
            self.count("flooded")
            why = "broadcast" if pkt.dst_mac == BCAST_MAC else "unknown destination"
            names = ", ".join(p.name for p in targets if p.trunk or p.vlan == vlan)
            self.say("flood", f"{pkt.label()} to {pkt.dst_mac}: {why} -> flooding out of {names or 'no port'}" + (f" (VLAN {vlan} only)" if vlan else ""), fwd=True)
        else:
            self.say("fwd", f"{pkt.label()} to {pkt.dst_mac}: table hit -> out of {out.name}", fwd=True)
        for p in targets:
            if p.trunk or p.vlan == vlan:
                q = copy.copy(pkt)
                q.vlan = vlan if p.trunk else 0
                self.net.after(self.DELAY, p.link.transmit, p, q)


class AccessPoint(Switch):
    kind = "ap"

    def __init__(self, net, name, ssid="LAB-WIFI", channel=6):
        super().__init__(net, name)
        self.ssid, self.channel = ssid, int(channel)


# ---------------------------------------------------------------------------------------------------------------- layer 3
def parse_iface(text):
    """'10.0.0.1/24' -> (IPv4Address, IPv4Network)"""
    i = ipaddress.ip_interface(text.strip())
    return i.ip, i.network


class IpNode(Node):
    forwarding = False

    def __init__(self, net, name):
        super().__init__(net, name)
        self.arp: dict = {}
        self.pending: dict = {}
        self.routes: list = []                # (IPv4Network, next hop IPv4Address | None)
        self.udp: dict = {}                   # port -> handler(pkt, port)
        self.tcp_listen: dict = {}
        self.tcp_conn: dict = {}
        self.icmp_hooks: list = []

    # -- addressing / routing
    def my_ips(self):
        return {str(p.ip) for p in self.ports if p.ip}

    def route(self, dst: str):
        d = ipaddress.ip_address(dst)
        best = None
        for p in self.ports:
            if p.ip and d in p.net and p.link:
                if best is None or p.net.prefixlen > best[2]:
                    best = (p, d, p.net.prefixlen)
        for net_, nh in self.routes:
            if d in net_:
                for p in self.ports:
                    if p.ip and p.link and nh and nh in p.net and (best is None or net_.prefixlen > best[2]):
                        best = (p, nh, net_.prefixlen)
        return (best[0], best[1]) if best else None

    # -- layer 2
    def l2_send(self, port, nexthop, pkt):
        if pkt.dst == BCAST_IP or (port.net and pkt.dst == str(port.net.broadcast_address)):
            pkt.src_mac, pkt.dst_mac = port.mac, BCAST_MAC
            port.link.transmit(port, pkt)
            return
        key = str(nexthop)
        mac = self.arp.get(key)
        if mac:
            pkt.src_mac, pkt.dst_mac = port.mac, mac
            port.link.transmit(port, pkt)
            return
        first = key not in self.pending
        self.pending.setdefault(key, []).append((port, pkt))
        if first:
            self.say("arp", f"no ARP entry for {key}: queue the packet and broadcast 'who-has {key}?'")
            req = Packet(self.net.new_id(), port.mac, BCAST_MAC, "ARP", op="request", sip=str(port.ip), tip=key, size=28, t0=self.net.now)
            port.link.transmit(port, req)
            self.net.after(1.0, self._arp_timeout, key)

    def _arp_timeout(self, key):
        for port, pkt in self.pending.pop(key, []):
            self.say("drop", f"ARP for {key} unanswered after 1 s: packet discarded")
            self.net.note_drop(pkt, f"ARP for {key} unanswered", self.name)
            self.count("arp_fail")

    def handle_arp(self, port, pkt):
        if self.arp.get(pkt.sip) != pkt.src_mac:
            self.say("arp", f"ARP cache: {pkt.sip} is at {pkt.src_mac}", table="arp", ip=pkt.sip, mac=pkt.src_mac)
        self.arp[pkt.sip] = pkt.src_mac
        if pkt.op == "request" and port.ip and pkt.tip == str(port.ip):
            self.say("arp", f"that is my address: replying '{pkt.tip} is at {port.mac}'")
            rep = Packet(self.net.new_id(), port.mac, pkt.src_mac, "ARP", op="reply", sip=str(port.ip), tip=pkt.sip, size=28, t0=self.net.now)
            port.link.transmit(port, rep)
        for p, q in self.pending.pop(pkt.sip, []):
            q.src_mac, q.dst_mac = p.mac, pkt.src_mac
            p.link.transmit(p, q)

    def receive(self, port, pkt):
        if pkt.etype == "ARP":
            return self.handle_arp(port, pkt)
        if pkt.dst_mac not in (port.mac, BCAST_MAC):
            return
        mine = pkt.dst in self.my_ips() or pkt.dst == BCAST_IP or (port.net and pkt.dst == str(port.net.broadcast_address))
        if mine:
            self.deliver(port, pkt)
        elif self.forwarding:
            self.forward(port, pkt)
        else:
            self.count("misdelivered")

    # -- layer 3 sending
    def send_ip(self, pkt: Packet):
        r = self.route(pkt.dst)
        if r is None:
            self.say("drop", f"no route to {pkt.dst}: packet discarded")
            self.net.note_drop(pkt, f"{self.name}: no route to {pkt.dst}", self.name)
            self.count("no_route")
            return False
        port, nh = r
        pkt.src = pkt.src or str(port.ip)
        self.l2_send(port, nh, pkt)
        return True

    def new_ip(self, proto, dst, size, **kw):
        return Packet(self.net.new_id(), etype="IP", dst=dst, proto=proto, size=size, t0=self.net.now, **kw)

    # -- delivery
    def deliver(self, port, pkt):
        raise NotImplementedError

    def forward(self, port, pkt):
        raise NotImplementedError


class Host(IpNode):
    kind = "host"

    def __init__(self, net, name):
        super().__init__(net, name)
        self.gateway = None
        self.apps: list = []
        self.dns_records: dict = {}
        self.dhcp_pool = None
        self.leases: dict = {}

    def set_gateway(self, gw):
        self.gateway = ipaddress.ip_address(gw) if gw else None
        self.routes = [(ipaddress.ip_network("0.0.0.0/0"), self.gateway)] if self.gateway else []

    def deliver(self, port, pkt):
        if pkt.proto == "ICMP":
            if pkt.icmp == "echo":
                self.say("rx", f"echo request from {pkt.src} (seq {pkt.seq}): sending echo reply")
                rep = self.new_ip("ICMP", pkt.src, pkt.size, icmp="echo-reply", seq=pkt.seq, data=dict(pkt.data), flow=pkt.flow)
                rep.t0 = pkt.t0
                self.send_ip(rep)
            else:
                self.say("rx", f"ICMP {pkt.icmp} from {pkt.src}")
                for h in self.icmp_hooks:
                    h(pkt)
        elif pkt.proto == "UDP":
            h = self.udp.get(pkt.dport)
            if h:
                h(pkt, port)
            else:
                self.count("udp_closed")
        elif pkt.proto == "TCP":
            tcp_input(self, pkt)

    def forward(self, port, pkt):
        pass


class Router(IpNode):
    kind = "router"
    forwarding = True
    DELAY = 10e-6

    def __init__(self, net, name, policy="allow"):
        super().__init__(net, name)
        self.rules: list = []                 # dicts: action, proto, src, dst, dport, iface, direction
        self.policy = policy
        self.conn: dict = {}                  # connection tracking: allowed flows
        self.why = ""

    def deliver(self, port, pkt):
        if pkt.proto == "ICMP" and pkt.icmp == "echo":
            self.say("rx", f"echo request to the router itself from {pkt.src}: replying")
            rep = self.new_ip("ICMP", pkt.src, pkt.size, icmp="echo-reply", seq=pkt.seq, data=dict(pkt.data), flow=pkt.flow)
            rep.t0 = pkt.t0
            self.send_ip(rep)

    def _match(self, rule, pkt, in_port, out_port):
        if rule["proto"] not in ("any", pkt.proto.lower()):
            return False
        if rule["src"] != "any" and ipaddress.ip_address(pkt.src) not in ipaddress.ip_network(rule["src"], strict=False):
            return False
        if rule["dst"] != "any" and ipaddress.ip_address(pkt.dst) not in ipaddress.ip_network(rule["dst"], strict=False):
            return False
        if rule["dport"] and pkt.dport != rule["dport"]:
            return False
        if rule.get("iface"):
            port = in_port if rule.get("direction", "in") == "in" else out_port
            if port.name != rule["iface"]:
                return False
        return True

    @staticmethod
    def _flow(pkt):
        sp, dp = (pkt.data.get("id", 0), pkt.data.get("id", 0)) if pkt.proto == "ICMP" else (pkt.sport, pkt.dport)
        return (pkt.proto, pkt.src, sp, pkt.dst, dp)

    def permits(self, pkt, in_port, out_port):
        """Stateful: the rules decide about a new flow; once allowed, its packets and its return traffic pass without matching again."""
        f = self._flow(pkt)
        rev = (f[0], f[3], f[4], f[1], f[2])
        if f in self.conn or rev in self.conn:
            return True
        for k, r in enumerate(self.rules, 1):
            if self._match(r, pkt, in_port, out_port):
                ok = r["action"] == "allow"
                self.why = f"rule {k}: {r['action']} {r['proto']} {r['src']} {r['dst']}" + (f" port {r['dport']}" if r["dport"] else "")
                break
        else:
            ok = self.policy == "allow"
            self.why = f"no rule matched: default policy is {self.policy}"
        if ok:
            self.conn[f] = self.net.now
            if self.rules or self.policy == "deny":
                self.say("fw", f"firewall ALLOW new flow {pkt.proto} {pkt.src} > {pkt.dst} ({self.why}); return traffic is now tracked")
        return ok

    def forward(self, port, pkt):
        self.net.after(self.DELAY, self._forward, port, pkt)

    def _forward(self, port, pkt):
        pkt = copy.copy(pkt)
        pkt.ttl -= 1
        if pkt.ttl <= 0:
            self.say("ttl", f"TTL reached 0 for {pkt.src} > {pkt.dst}: dropped, ICMP time-exceeded sent back")
            self.count("ttl_expired")
            if pkt.proto != "ICMP" or pkt.icmp == "echo":
                err = self.new_ip("ICMP", pkt.src, 56, icmp="ttl-exceeded", flow=pkt.flow, seq=pkt.seq, data={"orig": pkt.summary(), "id": pkt.data.get("id", 0)})
                err.src = str(port.ip)
                self.send_ip(err)
            return
        r = self.route(pkt.dst)
        if r is None:
            self.count("no_route")
            self.say("drop", f"no route to {pkt.dst}: dropped, ICMP unreachable sent back")
            self.net.note_drop(pkt, f"{self.name}: no route to {pkt.dst}", self.name)
            err = self.new_ip("ICMP", pkt.src, 56, icmp="unreachable", flow=pkt.flow, data={"orig": pkt.summary()})
            err.src = str(port.ip)
            self.send_ip(err)
            return
        out, nh = r
        if not self.permits(pkt, port, out):
            self.count("firewall_drops")
            self.say("fw", f"firewall DENY {pkt.proto} {pkt.src} > {pkt.dst} ({self.why})")
            self.net.note_drop(pkt, f"{self.name}: firewall denied ({self.why})", self.name)
            return
        self.say("route", f"{pkt.label()} {pkt.src} > {pkt.dst}: route via {out.name} next hop {nh}, TTL now {pkt.ttl}", fwd=True)
        self.count("forwarded")
        self.l2_send(out, nh, pkt)


# ---------------------------------------------------------------------------------------------------------------- applications
class FlowStats:
    def __init__(self, name, kind):
        self.name, self.kind = name, kind
        self.sent = self.recv = 0
        self.bytes_recv = 0
        self.delays: list = []
        self.jitter = 0.0
        self._last = None
        self.t_first = self.t_last = None

    def on_recv(self, now, pkt_bytes, delay):
        self.recv += 1
        self.bytes_recv += pkt_bytes
        self.delays.append(delay)
        if self._last is not None:
            self.jitter += (abs(delay - self._last) - self.jitter) / 16.0         # RFC 3550
        self._last = delay
        self.t_first = now if self.t_first is None else self.t_first
        self.t_last = now


class PingApp:
    def __init__(self, host, target, count=5, interval=1.0, size=64, start=0.0, ttl=64):
        self.host, self.target, self.count, self.interval, self.size, self.start, self.ttl = host, target, int(count), interval, int(size), start, int(ttl)
        self.id = host.net.new_id() & 0xFFFF
        self.rtts: list = []
        self.sent = 0
        self.unreach = 0
        self.ttl_exceeded = 0
        self.sent_at: dict = {}
        host.icmp_hooks.append(self._hook)
        host.net.at(start, self._send, 0)
        self.name = f"ping {host.name}>{target}"
        host.apps.append(self)

    def _send(self, k):
        if k >= self.count:
            return
        pkt = self.host.new_ip("ICMP", self.target, IP_HDR + ICMP_HDR + max(self.size - IP_HDR - ICMP_HDR, 0), icmp="echo", seq=k, data={"id": self.id}, flow=self.name, ttl=self.ttl)
        self.sent_at[k] = self.host.net.now
        self.host.say("app", f"ping {self.target}: sending echo request seq {k}")
        self.sent += 1
        self.host.send_ip(pkt)
        self.host.net.after(self.interval, self._send, k + 1)

    def _hook(self, pkt):
        if pkt.data.get("id") == self.id and pkt.icmp == "echo-reply":
            self.rtts.append(self.host.net.now - self.sent_at[pkt.seq])
            self.host.say("app", f"echo reply from {pkt.src} seq {pkt.seq}: round-trip {self.rtts[-1] * 1e3:.3f} ms")
        elif pkt.icmp == "unreachable" and pkt.dst == str(self.host.ports[0].ip):
            self.unreach += 1
        elif pkt.icmp == "ttl-exceeded":
            self.ttl_exceeded += 1

    def result(self):
        r = self.rtts
        return dict(app="ping", host=self.host.name, target=self.target, sent=self.sent, received=len(r), loss=100.0 * (1 - len(r) / self.sent) if self.sent else 0.0,
                    rtt_min=min(r) * 1e3 if r else None, rtt_avg=sum(r) / len(r) * 1e3 if r else None, rtt_max=max(r) * 1e3 if r else None,
                    unreachable=self.unreach, ttl_exceeded=self.ttl_exceeded)


class TraceApp:
    """traceroute: echo requests with TTL 1, 2, 3 ... ; every router that discards one answers 'time exceeded' and so reveals itself."""

    def __init__(self, host, target, maxhops=8, start=0.0, wait=1.0):
        self.host, self.target, self.maxhops, self.wait = host, target, int(maxhops), float(wait)
        self.id = host.net.new_id() & 0xFFFF
        self.name = f"traceroute {host.name}>{target}"
        self.hops: list = []              # (ttl, address or None, rtt s or None)
        self.done = False
        self._sent = {}
        host.icmp_hooks.append(self._hook)
        host.net.at(start, self._probe, 1)
        host.apps.append(self)

    def _probe(self, ttl):
        if self.done or ttl > self.maxhops:
            return
        pkt = self.host.new_ip("ICMP", self.target, 64, icmp="echo", seq=ttl, data={"id": self.id}, flow=self.name, ttl=ttl)
        self._sent[ttl] = self.host.net.now
        self.host.say("app", f"traceroute: probe with TTL {ttl}")
        self.host.send_ip(pkt)
        self.host.net.after(self.wait, self._timeout, ttl)

    def _timeout(self, ttl):
        if self.done or any(h[0] == ttl for h in self.hops):
            return
        self.hops.append((ttl, None, None))
        self.host.say("app", f"traceroute: no answer for TTL {ttl}")
        self._probe(ttl + 1)

    def _hook(self, pkt):
        if pkt.data.get("id") != self.id or pkt.icmp not in ("echo-reply", "ttl-exceeded"):
            return
        ttl = pkt.seq
        if any(h[0] == ttl for h in self.hops):
            return
        self.hops.append((ttl, pkt.src, self.host.net.now - self._sent[ttl]))
        self.host.say("app", f"traceroute: hop {ttl} is {pkt.src} ({(self.host.net.now - self._sent[ttl]) * 1e3:.3f} ms)")
        if pkt.icmp == "echo-reply":
            self.done = True
        else:
            self._probe(ttl + 1)

    def result(self):
        hops = sorted(self.hops)
        return dict(app="traceroute", host=self.host.name, target=self.target, reached=self.done,
                    hops=[dict(ttl=t, addr=a, rtt_ms=None if r is None else r * 1e3) for t, a, r in hops])


class UdpFlow:
    """Constant-bit-rate UDP sender + automatic sink at the destination."""

    def __init__(self, host, target, port=5001, rate_bps=1e6, size=1000, start=0.0, duration=5.0, name=""):
        self.host, self.target, self.port, self.size, self.start, self.duration = host, target, int(port), int(size), start, duration
        self.rate = float(rate_bps)
        self.name = name or f"udp {host.name}>{target}:{port}"
        self.stats = FlowStats(self.name, "udp")
        self.sport = 40000 + len(host.apps)
        host.net.flows[self.name] = self.stats
        host.net.at(start, self._send)
        host.apps.append(self)

    def _send(self):
        if self.host.net.now >= self.start + self.duration:
            return
        pkt = self.host.new_ip("UDP", self.target, self.size + IP_HDR + UDP_HDR, sport=self.sport, dport=self.port, flow=self.name)
        self.stats.sent += 1
        self.host.send_ip(pkt)
        self.host.net.after(self.size * 8 / self.rate, self._send)

    def result(self):
        s = self.stats
        span = (s.t_last - s.t_first) if s.recv > 1 else 0.0
        return dict(app="udp", flow=self.name, sent=s.sent, received=s.recv, loss=100.0 * (1 - s.recv / s.sent) if s.sent else 0.0,
                    throughput_kbps=(s.bytes_recv * 8 / 1e3 / self.duration), delay_ms=(sum(s.delays) / len(s.delays) * 1e3) if s.delays else None,
                    jitter_ms=s.jitter * 1e3)


def udp_sink(host, port, flow_lookup):
    def handler(pkt, in_port):
        st = flow_lookup.get(pkt.flow)
        if st is not None:
            st.on_recv(host.net.now, pkt.size - IP_HDR - UDP_HDR, host.net.now - pkt.t0)
    host.udp[port] = handler


class TcpSender:
    def __init__(self, host, dst, dport, nbytes, start=0.0, name=""):
        self.host, self.dst, self.dport, self.nbytes = host, dst, int(dport), int(nbytes)
        self.total = max(1, math.ceil(self.nbytes / MSS))
        self.name = name or f"tcp {host.name}>{dst}:{dport}"
        self.sport = 49152 + len(host.apps)
        self.state = "closed"
        self.cwnd, self.ssthresh = 1.0, 64.0
        self.nxt = self.una = 0
        self.dup = 0
        self.srtt = None
        self.rttvar = 0.0
        self.rto = 1.0
        self.sent_at: dict = {}
        self.retx_set: set = set()
        self.retransmits = 0
        self.timeouts = 0
        self.t_start = start
        self.t_done = None
        self.max_cwnd = 1.0
        self.trace: list = []
        self._timer = 0
        host.net.at(start, self._open)
        host.apps.append(self)
        host.net.tcp_flows.append(self)
        host.tcp_conn[(self.sport, dst, self.dport)] = self

    def _pkt(self, flags, seq=0, ack=0, length=0):
        p = self.host.new_ip("TCP", self.dst, IP_HDR + TCP_HDR + length, sport=self.sport, dport=self.dport, flags=flags, seq=seq, ack=ack, flow=self.name,
                             data={"len": length})
        return p

    def _open(self):
        self.state = "syn-sent"
        self.host.send_ip(self._pkt("SYN"))
        self._arm()

    def _arm(self):
        self._timer += 1
        self.host.net.after(self.rto, self._fire, self._timer)

    def _fire(self, tid):
        if tid != self._timer or self.state in ("done", "closed"):
            return
        self.timeouts += 1
        self.rto = min(self.rto * 2, 8.0)
        self.host.say("tcp", f"retransmission timeout: cwnd {self.cwnd:.1f} -> 1, ssthresh {max(self.cwnd / 2, 2.0):.1f}, RTO now {self.rto:.2f} s")
        if self.state == "syn-sent":
            if self.timeouts > 6:
                self.state = "closed"
                return
            self.host.send_ip(self._pkt("SYN"))
            self._arm()
            return
        self.ssthresh = max(self.cwnd / 2, 2.0)
        self.cwnd = 1.0
        self.dup = 0
        self.nxt = self.una
        self.trace.append((self.host.net.now, self.cwnd))
        self._send_window()

    def _send_seg(self, i):
        last = i == self.total - 1
        length = self.nbytes - i * MSS if last else MSS
        if i in self.sent_at:
            self.retx_set.add(i)
            self.retransmits += 1
        self.sent_at[i] = self.host.net.now
        self.host.send_ip(self._pkt("ACK", seq=i, length=max(length, 1)))

    def _send_window(self):
        while self.nxt < self.total and self.nxt - self.una < max(int(self.cwnd), 1):
            self._send_seg(self.nxt)
            self.nxt += 1
        self._arm()

    def on_packet(self, pkt):
        now = self.host.net.now
        if self.state == "syn-sent" and pkt.flags == "SYN-ACK":
            self.state = "established"
            self.host.say("tcp", "connection established (SYN-ACK received): slow start begins, cwnd = 1 segment")
            self.rto = 1.0
            self.timeouts = 0
            self.host.send_ip(self._pkt("ACK"))
            self.trace.append((now, self.cwnd))
            self._send_window()
            return
        if self.state != "established" or pkt.flags != "ACK":
            return
        k = pkt.ack
        if k > self.una:
            if (k - 1) not in self.retx_set and (k - 1) in self.sent_at:
                rtt = now - self.sent_at[k - 1]
                if self.srtt is None:
                    self.srtt, self.rttvar = rtt, rtt / 2
                else:
                    self.rttvar = 0.75 * self.rttvar + 0.25 * abs(self.srtt - rtt)
                    self.srtt = 0.875 * self.srtt + 0.125 * rtt
                self.rto = min(max(self.srtt + 4 * self.rttvar, 0.2), 8.0)
            newly = k - self.una
            self.una = k
            self.nxt = max(self.nxt, self.una)
            self.dup = 0
            if self.cwnd < self.ssthresh:
                self.cwnd += newly
            else:
                self.cwnd += newly / self.cwnd
            self.max_cwnd = max(self.max_cwnd, self.cwnd)
            self.trace.append((now, self.cwnd))
            if self.una >= self.total:
                self.state, self.t_done = "done", now
                self.host.say("tcp", f"transfer complete: all {self.total} segments acknowledged")
                self._timer += 1
                return
            self._send_window()
        elif k == self.una:
            self.dup += 1
            if self.dup == 3:
                self.host.say("tcp", f"3 duplicate ACKs: fast retransmit of segment {self.una}, cwnd {self.cwnd:.1f} -> {max(self.cwnd / 2, 2.0):.1f}")
                self.ssthresh = max(self.cwnd / 2, 2.0)
                self.cwnd = self.ssthresh
                self.trace.append((now, self.cwnd))
                self._send_seg(self.una)
                self._arm()

    def result(self):
        done = self.t_done is not None
        dur = (self.t_done - self.t_start) if done else None
        return dict(app="tcp", flow=self.name, bytes=self.nbytes, state=self.state, time_s=dur,
                    goodput_mbps=(self.nbytes * 8 / dur / 1e6) if dur else None, retransmits=self.retransmits, timeouts=self.timeouts, max_cwnd=self.max_cwnd,
                    srtt_ms=self.srtt * 1e3 if self.srtt else None)


class TcpReceiver:
    def __init__(self, host, peer_ip, peer_port, local_port):
        self.host, self.peer, self.pp, self.lp = host, peer_ip, peer_port, local_port
        self.nxt = 0
        self.ooo: set = set()
        self.bytes = 0


def tcp_input(host, pkt):
    key = (pkt.dport, pkt.src, pkt.sport)
    snd = host.tcp_conn.get(key)
    if snd is not None:                                # we are the sender: this is a SYN-ACK / ACK
        snd.on_packet(pkt)
        return
    if pkt.dport not in host.tcp_listen:
        return
    rcv = host.tcp_listen[pkt.dport].get((pkt.src, pkt.sport))
    if pkt.flags == "SYN":
        host.tcp_listen[pkt.dport][(pkt.src, pkt.sport)] = rcv or TcpReceiver(host, pkt.src, pkt.sport, pkt.dport)
        r = host.new_ip("TCP", pkt.src, IP_HDR + TCP_HDR, sport=pkt.dport, dport=pkt.sport, flags="SYN-ACK", flow=pkt.flow, data={"len": 0})
        host.send_ip(r)
        return
    if rcv is None or pkt.data.get("len", 0) == 0:
        return
    i = pkt.seq
    if i == rcv.nxt:
        rcv.nxt += 1
        rcv.bytes += pkt.data["len"]
        while rcv.nxt in rcv.ooo:
            rcv.ooo.discard(rcv.nxt)
            rcv.nxt += 1
    elif i > rcv.nxt:
        rcv.ooo.add(i)
    ack = host.new_ip("TCP", pkt.src, IP_HDR + TCP_HDR, sport=pkt.dport, dport=pkt.sport, flags="ACK", ack=rcv.nxt, flow=pkt.flow, data={"len": 0})
    host.send_ip(ack)


class DnsServer:
    def __init__(self, host, records):
        self.host, self.records = host, {k.lower(): v for k, v in records.items()}
        host.udp[53] = self.on_query
        self.queries = 0

    def on_query(self, pkt, port):
        self.queries += 1
        name = str(pkt.data.get("q", "")).lower()
        ans = self.records.get(name)
        self.host.say("app", f"DNS query for {name} from {pkt.src}: answer {ans or 'NXDOMAIN'}")
        r = self.host.new_ip("UDP", pkt.src, IP_HDR + UDP_HDR + 40, sport=53, dport=pkt.sport, flow=pkt.flow, data={"q": name, "a": ans, "m": f"{name} -> {ans or 'NXDOMAIN'}"})
        r.t0 = pkt.t0
        self.host.send_ip(r)


class DnsQuery:
    def __init__(self, host, server, name, start=0.0):
        self.host, self.server, self.qname, self.start = host, server, name, start
        self.sport = 53000 + len(host.apps)
        self.answer = None
        self.rtt = None
        self.done = False
        self.name = f"dns {host.name}>{server} {name}"
        host.udp[self.sport] = self.on_reply
        host.net.at(start, self._go)
        host.apps.append(self)

    def _go(self):
        pkt = self.host.new_ip("UDP", self.server, IP_HDR + UDP_HDR + 32, sport=self.sport, dport=53, flow=self.name, data={"q": self.qname, "m": f"{self.qname}?"})
        self.t_sent = self.host.net.now
        self.host.send_ip(pkt)

    def on_reply(self, pkt, port):
        self.done, self.answer, self.rtt = True, pkt.data.get("a"), self.host.net.now - self.t_sent
        self.host.say("app", f"DNS answer: {self.qname} = {self.answer or 'NXDOMAIN'} ({self.rtt * 1e3:.3f} ms)")

    def result(self):
        return dict(app="dns", host=self.host.name, query=self.qname, server=self.server, answer=self.answer or ("NXDOMAIN" if self.done else "no reply"),
                    rtt_ms=self.rtt * 1e3 if self.rtt is not None else None)


class DhcpServer:
    def __init__(self, host, first, last, lease=3600, gateway="", mask=24):
        self.host = host
        self.pool = [str(ipaddress.ip_address(a)) for a in range(int(ipaddress.ip_address(first)), int(ipaddress.ip_address(last)) + 1)]
        self.lease, self.gateway, self.mask = lease, gateway, int(mask)
        self.leases: dict = {}
        host.udp[67] = self.on_msg

    def on_msg(self, pkt, port):
        mac, m = pkt.data.get("mac"), pkt.data.get("m")
        self.host.say("app", f"DHCP {m} from {mac}")
        if m == "DISCOVER":
            ip = self.leases.get(mac) or next((a for a in self.pool if a not in self.leases.values()), None)
            if ip:
                self._reply(port, mac, "OFFER", ip)
        elif m == "REQUEST":
            ip = pkt.data.get("ip")
            if self.leases.get(mac, ip) == ip and (ip in self.pool):
                self.leases[mac] = ip
                self._reply(port, mac, "ACK", ip)

    def _reply(self, port, mac, m, ip):
        r = self.host.new_ip("UDP", BCAST_IP, IP_HDR + UDP_HDR + 240, sport=67, dport=68, data={"m": m, "ip": ip, "mac": mac, "gw": self.gateway, "mask": self.mask,
                                                                                               "lease": self.lease})
        r.src = str(port.ip)
        r.src_mac, r.dst_mac = port.mac, mac
        port.link.transmit(port, r)


class DhcpClient:
    def __init__(self, host, start=0.0):
        self.host, self.start = host, start
        self.port = host.ports[0]
        self.name = f"dhcp {host.name}"
        self.ip = None
        self.t_bound = None
        host.udp[68] = self.on_msg
        host.net.at(start, self._discover)
        host.apps.append(self)

    def _bcast(self, m, **kw):
        p = Packet(self.host.net.new_id(), etype="IP", src="0.0.0.0", dst=BCAST_IP, proto="UDP", size=IP_HDR + UDP_HDR + 240, sport=68, dport=67, t0=self.host.net.now,
                   data=dict(m=m, mac=self.port.mac, **kw))
        p.src_mac, p.dst_mac = self.port.mac, BCAST_MAC
        self.port.link.transmit(self.port, p)

    def _discover(self):
        self.host.say("app", "DHCP: no address yet, broadcasting DISCOVER")
        self._bcast("DISCOVER")

    def on_msg(self, pkt, port):
        if pkt.data.get("mac") != self.port.mac:
            return
        m = pkt.data["m"]
        if m == "OFFER":
            self._bcast("REQUEST", ip=pkt.data["ip"])
        elif m == "ACK":
            ip = pkt.data["ip"]
            self.port.ip = ipaddress.ip_address(ip)
            self.port.net = ipaddress.ip_network(f"{ip}/{pkt.data['mask']}", strict=False)
            if pkt.data.get("gw"):
                self.host.set_gateway(pkt.data["gw"])
            self.ip, self.t_bound = ip, self.host.net.now
            self.host.say("app", f"DHCP ACK: now configured as {ip}/{pkt.data['mask']}" + (f", gateway {pkt.data['gw']}" if pkt.data.get("gw") else ""))

    def result(self):
        return dict(app="dhcp", host=self.host.name, ip=self.ip or "no lease", bound_at_ms=self.t_bound * 1e3 if self.t_bound is not None else None)


# ---------------------------------------------------------------------------------------------------------------- the network
class Network:
    capture_limit_default = 20000

    def __init__(self, seed=1):
        self.now = 0.0
        self._q: list = []
        self._seq = itertools.count()
        self.rng = random.Random(seed)
        self.nodes: dict = {}
        self.links: list = []
        self.flows: dict = {}
        self.tcp_flows: list = []
        self.apps: list = []
        self.capture: list = []
        self.drops: list = []
        self.events: list = []                # narration: dict(t, node, kind, text)
        self._fwd_logged = 0
        self.capture_limit = self.capture_limit_default
        self._pid = itertools.count(1)
        self._mac = itertools.count(1)
        self.nevents = 0

    def log(self, node, kind, text, fwd=False, **data):
        if fwd:
            if self._fwd_logged >= 6000:
                return
            self._fwd_logged += 1
        if len(self.events) < 40000:
            self.events.append(dict(t=self.now, node=node, kind=kind, text=text, **data))

    def new_id(self):
        return next(self._pid)

    def new_mac(self):
        n = next(self._mac)
        return "02:00:00:%02x:%02x:%02x" % ((n >> 16) & 255, (n >> 8) & 255, n & 255)

    def at(self, t, fn, *a):
        heapq.heappush(self._q, (t, next(self._seq), fn, a))

    def after(self, dt, fn, *a):
        self.at(self.now + dt, fn, *a)

    def add(self, node):
        if node.name in self.nodes:
            raise NetError(f"Duplicate node name {node.name!r}")
        self.nodes[node.name] = node
        return node

    def connect(self, a: Node, b: Node, **kw):
        pa, pb = a.add_port(), b.add_port()
        lk = Link(self, pa, pb, **kw)
        self.links.append(lk)
        return lk

    def find_ip(self, ip):
        for n in self.nodes.values():
            if isinstance(n, IpNode) and ip in n.my_ips():
                return n
        return None

    def record(self, link, src, dst, pkt, t_start):
        if len(self.capture) < self.capture_limit:
            self.capture.append(dict(t=self.now, link=link.name, src=src.node.name, dst=dst.node.name, bytes=pkt.wire_bytes(), summary=pkt.summary(), vlan=pkt.vlan,
                                     proto=pkt.proto or pkt.etype, sent_at=t_start, pid=pkt.id, label=pkt.label(), layers=pkt.layers(), flow=pkt.flow))

    def note_drop(self, pkt, why, where=""):
        if len(self.drops) < 20000:
            self.drops.append(dict(t=self.now, why=why, summary=pkt.summary(), where=where, label=pkt.label()))

    def run(self, until):
        while self._q and self._q[0][0] <= until:
            t, _, fn, a = heapq.heappop(self._q)
            self.now = t
            fn(*a)
            self.nevents += 1
            if self.nevents > MAX_EVENTS:
                raise NetError(f"Simulation stopped after {MAX_EVENTS} events (too much traffic for the chosen duration)")
        self.now = until

    # -- reporting
    def results(self, duration):
        pings = [a.result() for n in self.nodes.values() if isinstance(n, Host) for a in n.apps if isinstance(a, PingApp)]
        udp = [a.result() for n in self.nodes.values() if isinstance(n, Host) for a in n.apps if isinstance(a, UdpFlow)]
        tcp = [f.result() for f in self.tcp_flows]
        dns = [a.result() for n in self.nodes.values() if isinstance(n, Host) for a in n.apps if isinstance(a, DnsQuery)]
        dhcp = [a.result() for n in self.nodes.values() if isinstance(n, Host) for a in n.apps if isinstance(a, DhcpClient)]
        trace = [a.result() for n in self.nodes.values() if isinstance(n, Host) for a in n.apps if isinstance(a, TraceApp)]
        links = []
        for lk in self.links:
            a, b = lk.ends
            cap = lk.mbps * 1e6 * max(duration, 1e-9)
            links.append(dict(link=lk.name, mbps=lk.mbps, util_ab=100.0 * lk.bytes[a] * 8 / cap, util_ba=100.0 * lk.bytes[b] * 8 / cap, pkts_ab=lk.pkts[a], pkts_ba=lk.pkts[b],
                              queue_drops=lk.drops_q[a] + lk.drops_q[b], loss_drops=lk.drops_loss[a] + lk.drops_loss[b]))
        nodes = [dict(node=n.name, kind=n.kind, **n.stats) for n in self.nodes.values() if n.stats]
        return dict(pings=pings, udp=udp, tcp=tcp, dns=dns, dhcp=dhcp, trace=trace, links=links, nodes=nodes, capture=self.capture, drops=self.drops, events=self.nevents, log=self.events)
