"""Ready-made network topologies. Each is a normal NetProject (drag blocks, edit settings) with notes and automated checks."""
from __future__ import annotations
from dataclasses import dataclass, field

from .model import NetProject

GROUPS = ["Local networks", "Routing and security", "Traffic and performance"]


@dataclass
class NetExample:
    key: str
    group: str
    title: str
    build: object
    objective: str
    theory: str = ""
    steps: list = field(default_factory=list)
    duration: float = 10.0
    check: object = None


EXAMPLES: dict[str, NetExample] = {}


def ex(key, group, title, objective, theory="", steps=(), duration=10.0):
    def deco(fn):
        build, check = fn()
        EXAMPLES[key] = NetExample(key, group, title, build, objective, theory, list(steps), duration, check)
        return fn
    return deco


def _c(name, ok, detail=""):
    return (name, bool(ok), detail)


def grouped():
    out = {g: [] for g in GROUPS}
    for e in EXAMPLES.values():
        out[e.group].append(e)
    return out


@ex("lan_ping", "Local networks", "Switched LAN: ping and ARP", "Three PCs on one switch. H1 pings H2; watch ARP resolution and MAC learning in the capture.",
    "The first packet triggers an ARP broadcast (flooded by the switch). The reply teaches the switch where H1 and H2 are, so later frames are forwarded only to the right port. "
    "RTT = 2 × hops × (frame bits / rate + propagation delay), plus the switch's few microseconds.",
    ["Press ▶ Run.", "Open Packet capture: the first lines are ARP who-has / is-at, then ICMP echo request / reply.", "Select the link H1–SW and change its delay to 5 ms; run again and compare the RTT."], 5.0)
def _lan():
    def build():
        p = NetProject("Switched LAN")
        sw = p.add_node("switch", 300, 160, name="SW")
        h1 = p.add_node("host", 100, 60, name="H1", ip="192.168.1.1/24", apps="ping 192.168.1.2 count=5 interval=0.5")
        h2 = p.add_node("host", 500, 60, name="H2", ip="192.168.1.2/24")
        h3 = p.add_node("host", 300, 320, name="H3", ip="192.168.1.3/24")
        for h in (h1, h2, h3):
            p.connect(h, sw, mbps=100, delay_ms=1)
        return p

    def check(res):
        ping = res["pings"][0]
        tx = (64 + 38) * 8 / 100e6
        expected = 2 * (2 * (tx + 1e-3) + 5e-6)                                  # two links each way plus the switch's 5 µs
        return [_c("5 of 5 pings answered", ping["received"] == 5, f"{ping['received']}/5"),
                _c("RTT ≈ 4·(serialisation + 1 ms)", abs(ping["rtt_min"] / 1e3 - expected) < 5e-5, f"{ping['rtt_min']:.3f} ms"),
                _c("Exactly one ARP request on the wire", sum(1 for c in res["capture"] if c["summary"].startswith("ARP who-has") and c["dst"] == "SW") == 1)]
    return build, check


@ex("hub_vs_switch", "Local networks", "Hub versus switch", "Same traffic through a hub: every host sees every frame. Replace the hub with a switch to stop that.",
    "A hub repeats each frame to all ports (one shared collision domain). A switch learns MAC addresses and forwards unicast frames only to the destination port.",
    ["Press ▶ Run and look at the capture: frames addressed to H2 are also delivered to H3 and H4.", "Delete the hub, add a Switch, relink the hosts and run again."], 5.0)
def _hub():
    def build():
        p = NetProject("Hub vs switch")
        hub = p.add_node("hub", 300, 180, name="HUB")
        h1 = p.add_node("host", 100, 80, name="H1", ip="10.0.0.1/24", apps="ping 10.0.0.2 count=3 interval=0.5")
        h2 = p.add_node("host", 500, 80, name="H2", ip="10.0.0.2/24")
        h3 = p.add_node("host", 100, 300, name="H3", ip="10.0.0.3/24")
        h4 = p.add_node("host", 500, 300, name="H4", ip="10.0.0.4/24")
        for h in (h1, h2, h3, h4):
            p.connect(h, hub, mbps=10, delay_ms=0.5)
        return p

    def check(res):
        seen = sum(1 for c in res["capture"] if c["dst"] == "H3" and "ICMP" in c["summary"])
        return [_c("Pings succeed", res["pings"][0]["received"] == 3), _c("H3 receives frames it is not addressed by (hub repeats everything)", seen == 6, f"{seen} ICMP frames")]
    return build, check


@ex("vlans", "Local networks", "VLANs on one switch", "Ports 1–2 are VLAN 10, port 3 is VLAN 20: A reaches B but not C although all three share a subnet.",
    "A VLAN is a separate broadcast domain. Even ARP broadcasts do not cross VLANs, so A cannot resolve C's address.",
    ["Run: ping to B succeeds, ping to C fails (100 % loss).", "Select the switch and change its VLANs to p1=10 p2=10 p3=10: both pings work."], 5.0)
def _vlan():
    def build():
        p = NetProject("VLANs")
        sw = p.add_node("switch", 300, 160, name="SW", vlans="p1=10 p2=10 p3=20")
        a = p.add_node("host", 100, 60, name="A", ip="10.0.0.1/24", apps="ping 10.0.0.2 count=3 interval=0.5\nping 10.0.0.3 count=3 interval=0.5")
        b = p.add_node("host", 500, 60, name="B", ip="10.0.0.2/24")
        c = p.add_node("host", 300, 320, name="C", ip="10.0.0.3/24")
        for h in (a, b, c):
            p.connect(h, sw)
        return p

    def check(res):
        to_b, to_c = res["pings"]
        return [_c("A → B (same VLAN) answered", to_b["received"] == 3), _c("A → C (other VLAN) unreachable", to_c["received"] == 0, f"{to_c['loss']:.0f} % loss")]
    return build, check


@ex("wifi_ap", "Local networks", "Wi-Fi access point", "A phone and a laptop join the wired LAN through an access point (slower, lossier wireless links).",
    "The access point bridges wireless clients onto the wired segment. Wireless links are modelled as point-to-point links with their own rate, delay and loss; no 802.11 contention.",
    ["Run: the phone's ping crosses the 54 Mbit/s wireless hop and the wired hop.", "Select the phone link and raise Loss to 10 %: some pings are lost."], 6.0)
def _wifi():
    def build():
        p = NetProject("Wi-Fi")
        ap = p.add_node("ap", 300, 180, name="AP1", ssid="LEARNERS-LAB", channel=6)
        srv = p.add_node("server", 300, 40, name="SRV", ip="192.168.0.10/24")
        ph = p.add_node("host", 100, 320, name="PHONE", ip="192.168.0.21/24", apps="ping 192.168.0.10 count=5 interval=0.5\nudp 192.168.0.10:5001 rate=2M dur=3 start=1")
        lp = p.add_node("host", 500, 320, name="LAPTOP", ip="192.168.0.22/24")
        p.connect(srv, ap, mbps=1000, delay_ms=0.1)
        p.connect(ph, ap, mbps=54, delay_ms=2, loss=1.0, wireless=True)
        p.connect(lp, ap, mbps=54, delay_ms=2, wireless=True)
        return p

    def check(res):
        return [_c("Phone reaches the server", res["pings"][0]["received"] >= 4, f"{res['pings'][0]['received']}/5"), _c("UDP stream delivered", res["udp"][0]["received"] > 0)]
    return build, check


@ex("two_subnets", "Routing and security", "Two subnets joined by a router", "PC1 (10.0.0.0/24) and PC2 (10.0.1.0/24) talk through router R1; a TCP download crosses it.",
    "Hosts send off-subnet packets to their default gateway. The router looks up the destination in its routing table, decrements the TTL and forwards out of the right port.",
    ["Press ▶ Run: ping and the TCP transfer both work.", "Open Packet capture and check the TTL: 64 at the sender, 63 after one router.", "Clear PC2's gateway and run again: replies cannot return, the pings fail."], 10.0)
def _two():
    def build():
        p = NetProject("Two subnets")
        pc1 = p.add_node("host", 80, 160, name="PC1", ip="10.0.0.2/24", gateway="10.0.0.1", apps="ping 10.0.1.2 count=3 interval=0.5\ntcp 10.0.1.2:80 bytes=500k start=2")
        r1 = p.add_node("router", 300, 160, name="R1", ips="p1=10.0.0.1/24\np2=10.0.1.1/24")
        pc2 = p.add_node("host", 520, 160, name="PC2", ip="10.0.1.2/24", gateway="10.0.1.1")
        p.connect(pc1, r1, mbps=100, delay_ms=1)
        p.connect(r1, pc2, mbps=100, delay_ms=1)
        return p

    def check(res):
        ttl63 = any("ttl=63" in c["summary"] and "echo " in c["summary"] for c in res["capture"])
        return [_c("Pings across the router answered", res["pings"][0]["received"] == 3), _c("TCP transfer completed", res["tcp"][0]["state"] == "done", f"{res['tcp'][0]['goodput_mbps'] or 0:.1f} Mbit/s"),
                _c("TTL decremented by the router", ttl63)]
    return build, check


@ex("firewall", "Routing and security", "Firewall rules", "A firewall allows ping and web traffic (port 80) from the LAN to the server but blocks port 23 (telnet).",
    "Rules are checked top to bottom, first match wins; unmatched packets follow the default policy. A TCP connection whose SYN is dropped never opens.",
    ["Run: ping and the port-80 transfer work, the telnet (port 23) transfer never connects.", "Edit the firewall rules (select FW) and swap 'deny … 23' for 'allow … 23': telnet works."], 15.0)
def _fw():
    def build():
        p = NetProject("Firewall")
        pc = p.add_node("host", 80, 160, name="PC", ip="10.0.0.2/24", gateway="10.0.0.1",
                        apps="ping 10.0.1.80 count=3 interval=0.5\ntcp 10.0.1.80:80 bytes=100k start=1\ntcp 10.0.1.80:23 bytes=10k start=1")
        fw = p.add_node("firewall", 300, 160, name="FW", ips="p1=10.0.0.1/24\np2=10.0.1.1/24", rules="deny tcp any any 23\nallow icmp any any\nallow tcp any any 80", policy="deny")
        srv = p.add_node("server", 520, 160, name="WEB", ip="10.0.1.80/24", gateway="10.0.1.1")
        p.connect(pc, fw)
        p.connect(fw, srv)
        return p

    def check(res):
        web = next(t for t in res["tcp"] if ":80" in t["flow"])
        tel = next(t for t in res["tcp"] if ":23" in t["flow"])
        return [_c("Ping allowed", res["pings"][0]["received"] == 3), _c("Port 80 transfer completes", web["state"] == "done"), _c("Port 23 blocked (connection never opens)", tel["state"] != "done"),
                _c("Firewall counted dropped packets", res["nodes"] and any(n["node"] == "FW" and n.get("firewall_drops", 0) > 0 for n in res["nodes"]))]
    return build, check


@ex("dhcp_dns", "Routing and security", "DHCP and DNS server", "Two PCs get addresses from a DHCP server, then look up a name on the DNS server.",
    "DHCP: DISCOVER (broadcast) → OFFER → REQUEST → ACK. The ACK carries the address, mask and gateway. DNS: a UDP query on port 53 returns the A record, or NXDOMAIN if the name is unknown.",
    ["Run: the Summary tab lists the leases and the DNS answers.", "Open Packet capture and follow the four DHCP messages."], 5.0)
def _dhcp():
    def build():
        p = NetProject("DHCP + DNS")
        sw = p.add_node("switch", 300, 160, name="SW")
        srv = p.add_node("server", 300, 20, name="SRV", ip="10.0.0.2/24", dns_records="www.lab.test 10.0.0.80\nmail.lab.test 10.0.0.25",
                         dhcp_pool="10.0.0.100-10.0.0.150 gw=10.0.0.1 mask=24 lease=3600")
        a = p.add_node("host", 100, 300, name="PC-A", apps="dhcp\ndns 10.0.0.2 www.lab.test start=1")
        b = p.add_node("host", 500, 300, name="PC-B", apps="dhcp start=0.3\ndns 10.0.0.2 ftp.lab.test start=1.5")
        for n in (srv, a, b):
            p.connect(n, sw)
        return p

    def check(res):
        ips = {d["host"]: d["ip"] for d in res["dhcp"]}
        ans = {d["query"]: d["answer"] for d in res["dns"]}
        return [_c("Both PCs got a lease", ips == {"PC-A": "10.0.0.100", "PC-B": "10.0.0.101"}, str(ips)), _c("DNS resolves a known name", ans.get("www.lab.test") == "10.0.0.80"),
                _c("DNS reports NXDOMAIN for an unknown name", ans.get("ftp.lab.test") == "NXDOMAIN")]
    return build, check


@ex("bottleneck", "Traffic and performance", "TCP and UDP share a bottleneck", "A bulk TCP transfer and a 6 Mbit/s UDP stream compete for an 8 Mbit/s link.",
    "Queues fill, packets are dropped, TCP's congestion window shrinks. UDP does not back off, so it keeps its rate and TCP gets what remains.",
    ["Run and read the Summary tab: UDP loss, TCP goodput, retransmissions.", "Select the bottleneck link and raise its rate to 20 Mbit/s: both flows run unhindered.",
     "Increase the queue length: more delay, fewer drops."], 20.0)
def _bn():
    def build():
        p = NetProject("Bottleneck")
        a = p.add_node("host", 60, 80, name="A", ip="10.0.0.1/24", gateway="10.0.0.254", apps="tcp 10.0.1.1:80 bytes=4M")
        b = p.add_node("host", 60, 260, name="B", ip="10.0.0.2/24", gateway="10.0.0.254", apps="udp 10.0.1.2:5001 rate=6M size=1000 dur=18 start=0.5")
        s1 = p.add_node("switch", 240, 170, name="SW1")
        r = p.add_node("router", 440, 170, name="R", ips="p1=10.0.0.254/24\np2=10.0.1.254/24")
        s2 = p.add_node("switch", 640, 170, name="SW2")
        c = p.add_node("host", 840, 80, name="C", ip="10.0.1.1/24", gateway="10.0.1.254")
        d = p.add_node("host", 840, 260, name="D", ip="10.0.1.2/24", gateway="10.0.1.254")
        p.connect(a, s1, mbps=100, delay_ms=0.5); p.connect(b, s1, mbps=100, delay_ms=0.5)
        p.connect(s1, r, mbps=100, delay_ms=0.5)
        p.connect(r, s2, mbps=8, delay_ms=10, queue=50)                       # the bottleneck
        p.connect(s2, c, mbps=100, delay_ms=0.5); p.connect(s2, d, mbps=100, delay_ms=0.5)
        return p

    def check(res):
        t, u = res["tcp"][0], res["udp"][0]
        bott = next(l for l in res["links"] if l["link"] == "R-SW2")
        return [_c("TCP transfer finishes", t["state"] == "done", f"{t['goodput_mbps'] or 0:.2f} Mbit/s"), _c("TCP retransmitted after losses", t["retransmits"] > 0, f"{t['retransmits']}"),
                _c("UDP stream lost packets at the full queue", u["loss"] > 1.0, f"{u['loss']:.1f} %"), _c("Bottleneck link dropped packets", bott["queue_drops"] > 0, f"{bott['queue_drops']}")]
    return build, check


from .. import labs  # noqa: E402,F401  (lab-wise experiments register themselves)
