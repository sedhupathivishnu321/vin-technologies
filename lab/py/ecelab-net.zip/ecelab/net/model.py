"""Network project model (topology + per-block settings, JSON) and the builder that turns it into an engine `Network`.

Settings are plain text so they can be edited in the Properties panel and saved with the project:

  host / server    ip = 10.0.0.2/24      gateway = 10.0.0.1
                   apps (one per line):
                     ping <ip> [count=5] [interval=1] [size=64] [ttl=64] [start=0]
                     trace <ip> [hops=8] [start=0]
                     udp  <ip>[:port] [rate=1M] [size=1000] [start=0] [dur=5]
                     tcp  <ip>[:port] [bytes=1M] [start=0]
                     dns  <server-ip> <name> [start=0]
                     dhcp [start=0]
                   dns_records (server): "www.lab.test 10.0.0.80"      dhcp_pool (server): "10.0.0.100-10.0.0.150 gw=10.0.0.1 mask=24 lease=3600"
  switch           vlans = "p1=10 p2=20 p3=trunk"   (p<n> = the n-th link attached to the block)
  router/firewall  ips = "p1=10.0.0.1/24"  routes = "10.2.0.0/24 via 10.0.1.2"  rules = "deny tcp any any 80"  policy = allow|deny
  access point     ssid, channel
"""
from __future__ import annotations
import ipaddress
import json
import re
from dataclasses import dataclass, field

from . import engine as E

SCHEMA = "ecelab.network"
NODE_TYPES = {
    "host": ("Host / PC", "H"), "server": ("Server (DNS + DHCP)", "S"), "switch": ("Switch", "SW"), "hub": ("Hub", "HUB"), "ap": ("Access point", "AP"),
    "router": ("Router", "R"), "firewall": ("Firewall", "FW"),
}
DEFAULTS = {
    "host": {"ip": "", "gateway": "", "apps": ""},
    "server": {"ip": "", "gateway": "", "apps": "", "dns_records": "", "dhcp_pool": ""},
    "switch": {"vlans": ""},
    "hub": {},
    "ap": {"ssid": "LAB-WIFI", "channel": "6", "vlans": ""},
    "router": {"ips": "", "routes": "", "rules": "", "policy": "allow"},
    "firewall": {"ips": "", "routes": "", "rules": "", "policy": "deny"},
}
HELP = {
    "ip": "Address of the block's only interface, e.g. 10.0.0.2/24 (empty = use a DHCP client app)", "gateway": "Default gateway, e.g. 10.0.0.1",
    "apps": "One application per line, e.g.\nping 10.0.0.1 count=5\nudp 10.0.0.2:5001 rate=2M dur=5\ntcp 10.0.0.2:80 bytes=2M\ndns 10.0.0.53 www.lab.test\ndhcp",
    "dns_records": "One record per line: www.lab.test 10.0.0.80", "dhcp_pool": "first-last [gw=ip] [mask=24] [lease=3600], e.g. 10.0.0.100-10.0.0.150 gw=10.0.0.1",
    "vlans": "Port VLANs: p1=10 p2=20 p3=trunk (default: all ports in VLAN 1)", "ips": "One interface per line: p1=10.0.0.1/24",
    "routes": "One route per line: 10.2.0.0/24 via 10.0.1.2", "rules": "First match wins: allow|deny <tcp|udp|icmp|any> <src|any> <dst|any> [port] [iface=p1 dir=in|out]",
    "policy": "allow or deny packets that match no rule", "ssid": "Network name (informational)", "channel": "Wi-Fi channel (informational)",
}
MULTILINE = {"apps", "dns_records", "ips", "routes", "rules"}


@dataclass
class NetNode:
    id: str
    type: str
    name: str
    x: float = 0.0
    y: float = 0.0
    params: dict = field(default_factory=dict)


@dataclass
class NetLink:
    id: str
    a: str
    b: str
    mbps: float = 100.0
    delay_ms: float = 1.0
    loss: float = 0.0
    queue: int = 100
    wireless: bool = False


class NetProject:
    def __init__(self, name="Untitled network"):
        self.name = name
        self.nodes: dict[str, NetNode] = {}
        self.links: list[NetLink] = []
        self.sim = {"duration": 10.0, "seed": 1}
        self.notes = ""
        self._n = 0

    def _id(self, p):
        self._n += 1
        return f"{p}{self._n}"

    def add_node(self, type_, x=0.0, y=0.0, name=None, **params):
        if type_ not in NODE_TYPES:
            raise KeyError(type_)
        prefix = NODE_TYPES[type_][1]
        used = {n.name for n in self.nodes.values()}
        k = 1
        while name is None and f"{prefix}{k}" in used:
            k += 1
        nid = self._id("n")
        p = dict(DEFAULTS[type_]); p.update({k_: str(v) for k_, v in params.items()})
        n = NetNode(nid, type_, name or f"{prefix}{k}", x, y, p)
        self.nodes[nid] = n
        return n

    def by_name(self, name):
        for n in self.nodes.values():
            if n.name == name:
                return n
        raise KeyError(name)

    def connect(self, a, b, **kw):
        a_id = a.id if isinstance(a, NetNode) else a
        b_id = b.id if isinstance(b, NetNode) else b
        if a_id == b_id:
            raise E.NetError("A block cannot be linked to itself")
        if a_id not in self.nodes or b_id not in self.nodes:
            raise E.NetError("Unknown block")
        for t in (a_id, b_id):
            if self.nodes[t].type in ("host", "server") and any(t in (l.a, l.b) for l in self.links):
                raise E.NetError(f"{self.nodes[t].name} has a single network interface and is already linked")
        lk = NetLink(self._id("l"), a_id, b_id, **kw)
        self.links.append(lk)
        return lk

    def links_of(self, nid):
        return [l for l in self.links if nid in (l.a, l.b)]

    def remove_node(self, nid):
        self.nodes.pop(nid, None)
        self.links = [l for l in self.links if nid not in (l.a, l.b)]

    def remove_link(self, lid):
        self.links = [l for l in self.links if l.id != lid]

    def port_of(self, nid, lid):
        """Index (1-based) of the link among the block's links = the p<n> name."""
        k = 0
        for l in self.links:
            if nid in (l.a, l.b):
                k += 1
                if l.id == lid:
                    return k
        return 0

    def to_dict(self):
        return {"schema": SCHEMA, "version": 1, "name": self.name, "sim": self.sim, "notes": self.notes,
                "nodes": [dict(id=n.id, type=n.type, name=n.name, x=n.x, y=n.y, params=n.params) for n in self.nodes.values()],
                "links": [dict(id=l.id, a=l.a, b=l.b, mbps=l.mbps, delay_ms=l.delay_ms, loss=l.loss, queue=l.queue, wireless=l.wireless) for l in self.links]}

    @staticmethod
    def from_dict(d):
        if not isinstance(d, dict) or d.get("schema") != SCHEMA:
            raise E.NetError("Not a LEARNERS LAB network file")
        p = NetProject(d.get("name", "Untitled network"))
        p.sim.update(d.get("sim", {})); p.notes = d.get("notes", "")
        for nd in d["nodes"]:
            if nd["type"] not in NODE_TYPES:
                raise E.NetError(f"Unknown block type {nd['type']!r}")
            params = dict(DEFAULTS[nd["type"]]); params.update(nd.get("params", {}))
            p.nodes[nd["id"]] = NetNode(nd["id"], nd["type"], nd["name"], nd.get("x", 0), nd.get("y", 0), params)
        for ld in d["links"]:
            if ld["a"] not in p.nodes or ld["b"] not in p.nodes:
                raise E.NetError(f"Link {ld['id']} refers to a missing block")
            p.links.append(NetLink(**ld))
        p._n = 1 + max([0] + [int(re.sub(r"\D", "", x) or 0) for x in list(p.nodes) + [l.id for l in p.links]])
        return p

    def save(self, path):
        with open(path, "w", encoding="utf-8") as f:
            json.dump(self.to_dict(), f, indent=1)

    @staticmethod
    def load(path):
        try:
            with open(path, "r", encoding="utf-8") as f:
                return NetProject.from_dict(json.load(f))
        except (OSError, json.JSONDecodeError) as ex:
            raise E.NetError(f"Cannot read {path}: {ex}") from ex


# ---------------------------------------------------------------------------------------------------------------- parsing helpers
def si(text, what="value"):
    m = re.fullmatch(r"([0-9.]+)\s*([kKmMgG]?)", str(text).strip())
    if not m:
        raise E.NetError(f"Bad {what} {text!r}")
    return float(m.group(1)) * {"": 1, "k": 1e3, "m": 1e6, "g": 1e9}[m.group(2).lower()]


def _lines(text):
    for n, raw in enumerate(str(text).splitlines(), start=1):
        s = raw.split("#", 1)[0].strip()
        if s:
            yield n, s


def _kv(tokens):
    out = {}
    for t in tokens:
        if "=" in t:
            k, v = t.split("=", 1)
            out[k.lower()] = v
    return out


def _err(node, field_, n, msg):
    return E.NetError(f"{node.name}: {field_} line {n}: {msg}")


def build(proj: NetProject):
    """Returns (Network, warnings)."""
    net = E.Network(int(proj.sim.get("seed", 1)))
    warn = []
    objs = {}
    for n in proj.nodes.values():
        cls = {"host": E.Host, "server": E.Host, "switch": E.Switch, "hub": E.Hub, "ap": E.AccessPoint, "router": E.Router, "firewall": E.Router}[n.type]
        o = cls(net, n.name)
        if n.type == "ap":
            o.ssid, o.channel = n.params.get("ssid", ""), n.params.get("channel", "6")
        if isinstance(o, E.Router):
            o.policy = n.params.get("policy", "allow")
        objs[n.id] = net.add(o)
    portmap = {}
    for lk in proj.links:
        a, b = objs[lk.a], objs[lk.b]
        L = net.connect(a, b, mbps=lk.mbps, delay_ms=lk.delay_ms, loss=lk.loss / 100.0, queue=lk.queue, wireless=lk.wireless,
                        name=f"{proj.nodes[lk.a].name}-{proj.nodes[lk.b].name}")
        portmap[(lk.a, lk.id)], portmap[(lk.b, lk.id)] = L.ends
    for n in proj.nodes.values():
        o = objs[n.id]
        p = n.params
        by_name = {pt.name: pt for pt in o.ports}
        if isinstance(o, E.Host):
            if p.get("ip", "").strip():
                if not o.ports:
                    warn.append(f"{n.name}: has an address but no link")
                else:
                    try:
                        o.ports[0].ip, o.ports[0].net = E.parse_iface(p["ip"])
                    except ValueError as ex:
                        raise E.NetError(f"{n.name}: ip {p['ip']!r}: {ex}") from ex
            if p.get("gateway", "").strip():
                try:
                    o.set_gateway(p["gateway"].strip())
                except ValueError as ex:
                    raise E.NetError(f"{n.name}: gateway: {ex}") from ex
            if n.type == "server":
                recs = {}
                for ln, s in _lines(p.get("dns_records", "")):
                    t = s.split()
                    if len(t) != 2:
                        raise _err(n, "dns_records", ln, "expected: name ip")
                    recs[t[0]] = t[1]
                if recs:
                    E.DnsServer(o, recs)
                for ln, s in _lines(p.get("dhcp_pool", "")):
                    t = s.split()
                    try:
                        first, last = t[0].split("-")
                        kv = _kv(t[1:])
                        E.DhcpServer(o, first, last, int(kv.get("lease", 3600)), kv.get("gw", ""), int(kv.get("mask", 24)))
                    except (ValueError, IndexError) as ex:
                        raise _err(n, "dhcp_pool", ln, f"expected first-last [gw=ip] [mask=24] [lease=s] ({ex})") from ex
        else:
            if isinstance(o, E.Router):
                for ln, s in _lines(p.get("ips", "")):
                    m = re.fullmatch(r"(p\d+)\s*=\s*(\S+)", s)
                    if not m or m.group(1) not in by_name:
                        raise _err(n, "ips", ln, "expected p<n>=a.b.c.d/len for an existing port")
                    try:
                        by_name[m.group(1)].ip, by_name[m.group(1)].net = E.parse_iface(m.group(2))
                    except ValueError as ex:
                        raise _err(n, "ips", ln, str(ex)) from ex
                for ln, s in _lines(p.get("routes", "")):
                    m = re.fullmatch(r"(\S+)\s+via\s+(\S+)", s)
                    if not m:
                        raise _err(n, "routes", ln, "expected: a.b.c.d/len via a.b.c.d")
                    try:
                        o.routes.append((ipaddress.ip_network(m.group(1), strict=False), ipaddress.ip_address(m.group(2))))
                    except ValueError as ex:
                        raise _err(n, "routes", ln, str(ex)) from ex
                for ln, s in _lines(p.get("rules", "")):
                    t = s.split()
                    if len(t) < 4 or t[0] not in ("allow", "deny") or t[1].lower() not in ("any", "tcp", "udp", "icmp"):
                        raise _err(n, "rules", ln, "expected: allow|deny tcp|udp|icmp|any <src|any> <dst|any> [port] [iface=p1 dir=in|out]")
                    rule = dict(action=t[0], proto=t[1].lower(), src=t[2], dst=t[3], dport=0)
                    rest = [x for x in t[4:] if "=" not in x]
                    if rest:
                        if not rest[0].isdigit():
                            raise _err(n, "rules", ln, f"bad port {rest[0]!r}")
                        rule["dport"] = int(rest[0])
                    kv = _kv(t[4:])
                    if "iface" in kv:
                        rule["iface"], rule["direction"] = kv["iface"], kv.get("dir", "in")
                    for k_ in ("src", "dst"):
                        if rule[k_] != "any":
                            try:
                                ipaddress.ip_network(rule[k_], strict=False)
                            except ValueError as ex:
                                raise _err(n, "rules", ln, str(ex)) from ex
                    o.rules.append(rule)
            if isinstance(o, E.Switch):
                for tok in p.get("vlans", "").replace(",", " ").split():
                    m = re.fullmatch(r"(p\d+)=(\d+|trunk)", tok)
                    if not m or m.group(1) not in by_name:
                        raise E.NetError(f"{n.name}: vlans: bad entry {tok!r} (expected p1=10 or p2=trunk)")
                    pt = by_name[m.group(1)]
                    if m.group(2) == "trunk":
                        pt.trunk = True
                    else:
                        pt.vlan = int(m.group(2))
    # applications (after every address is known)
    hosts = [o for o in objs.values() if isinstance(o, E.Host)]
    for n in proj.nodes.values():
        if n.type not in ("host", "server"):
            continue
        h = objs[n.id]
        for ln, s in _lines(n.params.get("apps", "")):
            t = s.split()
            kv = _kv(t[1:])
            try:
                kind = t[0].lower()
                start = float(kv.get("start", 0))
                if kind == "ping":
                    E.PingApp(h, t[1], int(kv.get("count", 5)), float(kv.get("interval", 1)), int(kv.get("size", 64)), start, int(kv.get("ttl", 64)))
                elif kind == "trace":
                    E.TraceApp(h, t[1], int(kv.get("hops", 8)), start)
                elif kind == "udp":
                    ip, _, port = t[1].partition(":")
                    port = int(port or 5001)
                    E.UdpFlow(h, ip, port, si(kv.get("rate", "1M"), "rate"), int(kv.get("size", 1000)), start, float(kv.get("dur", 5)), name=f"udp {h.name}>{ip}:{port}")
                    for o in hosts:
                        if port not in o.udp:
                            E.udp_sink(o, port, net.flows)
                elif kind == "tcp":
                    ip, _, port = t[1].partition(":")
                    port = int(port or 80)
                    E.TcpSender(h, ip, port, si(kv.get("bytes", "1M"), "bytes"), start, name=f"tcp {h.name}>{ip}:{port}")
                    for o in hosts:
                        o.tcp_listen.setdefault(port, {})
                elif kind == "dns":
                    E.DnsQuery(h, t[1], t[2], float(kv.get("start", 0)))
                elif kind == "dhcp":
                    if not h.ports:
                        raise E.NetError("has no link")
                    E.DhcpClient(h, start)
                else:
                    raise E.NetError(f"unknown application {kind!r}")
            except (IndexError, ValueError) as ex:
                raise _err(n, "apps", ln, f"cannot parse {s!r} ({ex})") from ex
            except E.NetError as ex:
                raise _err(n, "apps", ln, str(ex)) from ex
    for o in objs.values():
        if not o.ports:
            warn.append(f"{o.name}: not linked to anything")
        if isinstance(o, E.Host) and o.ports and o.ports[0].ip is None and not any(isinstance(a, E.DhcpClient) for a in o.apps):
            warn.append(f"{o.name}: has no IP address (set one or add a 'dhcp' app)")
    seen = {}
    for o in objs.values():
        if isinstance(o, E.IpNode):
            for ip in o.my_ips():
                if ip in seen:
                    warn.append(f"Duplicate address {ip} on {seen[ip]} and {o.name}")
                seen[ip] = o.name
    return net, warn


def simulate(proj: NetProject, duration=None):
    net, warn = build(proj)
    dur = float(duration if duration is not None else proj.sim.get("duration", 10.0))
    net.run(dur)
    res = net.results(dur)
    res["warnings"] = warn
    res["duration"] = dur
    res["network"] = net
    return res


# ---------------------------------------------------------------------------------------------------------------- probes (simulate any point to any point)
def node_ip(n: NetNode):
    """First IPv4 address configured on the block, or None (e.g. a DHCP client before it has a lease, a switch)."""
    if n.type in ("host", "server"):
        ip = n.params.get("ip", "").split("/")[0].strip()
        return ip or None
    if n.type in ("router", "firewall"):
        for ln in n.params.get("ips", "").splitlines():
            m = re.fullmatch(r"\s*p\d+\s*=\s*([\d.]+)(?:/\d+)?\s*", ln)
            if m:
                return m.group(1)
    return None


PROBES = {"ping": "Ping (2 echo requests)", "trace": "Traceroute", "tcp": "TCP transfer (100 kB)", "udp": "UDP burst (2 Mbit/s, 0.3 s)"}


def _only_dhcp(text: str):
    return "\n".join(l for l in text.splitlines() if l.strip().lower().startswith("dhcp"))


def probe_project(proj: NetProject, src_id: str, dst_ip: str, kind: str):
    """A copy of the project in which the only traffic is one test from `src_id` to `dst_ip` (DHCP clients keep their lease request)."""
    p = NetProject.from_dict(proj.to_dict())
    dhcp = False
    for n in p.nodes.values():
        if n.type in ("host", "server"):
            keep = _only_dhcp(n.params.get("apps", ""))
            n.params["apps"] = keep
            dhcp = dhcp or bool(keep)
    t0 = 0.5 if dhcp else 0.0
    line = {"ping": f"ping {dst_ip} count=2 interval=0.5 start={t0}", "trace": f"trace {dst_ip} hops=8 start={t0}", "tcp": f"tcp {dst_ip}:80 bytes=100k start={t0}",
            "udp": f"udp {dst_ip}:5001 rate=2M size=1000 dur=0.3 start={t0}"}[kind]
    s = p.nodes[src_id]
    s.params["apps"] = (s.params.get("apps", "") + "\n" + line).strip()
    dur = {"ping": 3.0 + t0, "trace": 6.0 + t0, "tcp": 4.0 + t0, "udp": 1.5 + t0}[kind]
    return p, dur


def matrix_project(proj: NetProject):
    """A copy in which every host pings every block that has an address once; returns (project, duration, {ip: block name}, [source names])."""
    p = NetProject.from_dict(proj.to_dict())
    ips = {}
    for n in p.nodes.values():
        ip = node_ip(n)
        if ip:
            ips[ip] = n.name
    k = 0
    srcs = []
    for n in p.nodes.values():
        if n.type not in ("host", "server"):
            continue
        keep = [_only_dhcp(n.params.get("apps", ""))] if _only_dhcp(n.params.get("apps", "")) else []
        mine = node_ip(n)
        for ip in ips:
            if ip != mine:
                keep.append(f"ping {ip} count=1 start={0.5 + k * 0.02:.3f}")
                k += 1
        n.params["apps"] = "\n".join(keep)
        if mine:
            srcs.append(n.name)
    return p, 3.0 + k * 0.02, ips, srcs
