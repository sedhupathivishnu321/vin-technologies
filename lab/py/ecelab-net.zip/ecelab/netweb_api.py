"""JSON entry points for the browser Network app (Pyodide). Only the network engine is loaded; the page never sees Python objects."""
from __future__ import annotations
import json
import math

from .net import examples as _nx
from .net import engine as _ne
from .net.model import NetProject, simulate as _net_simulate, probe_project, matrix_project, node_ip, NODE_TYPES, DEFAULTS, HELP, MULTILINE, PROBES


def _clean(v):
    """Make engine results JSON-safe: NaN and infinity become null, tuples become lists, unknown objects become text."""
    if isinstance(v, float):
        return v if math.isfinite(v) else None
    if isinstance(v, (list, tuple)):
        return [_clean(x) for x in v]
    if isinstance(v, dict):
        return {str(k): _clean(x) for k, x in v.items() if not str(k).startswith("_")}
    if isinstance(v, (str, int, bool)) or v is None:
        return v
    return str(v)

def _web_text(t: str) -> str:
    return str(t).replace("▶ Start Simulation", "Run").replace("Start Simulation", "Run").replace("▶", "").replace("  ", " ")


def net_types() -> str:
    return json.dumps(dict(types={k: dict(name=v[0], short=v[1]) for k, v in NODE_TYPES.items()}, defaults=DEFAULTS, help=HELP, multiline=sorted(MULTILINE), probes=PROBES))


def net_example_list() -> str:
    return json.dumps([dict(key=k, title=e.title, group=e.group) for k, e in _nx.EXAMPLES.items()])


def net_load_example(key: str) -> str:
    e = _nx.EXAMPLES[key]
    p = e.build()
    return json.dumps(dict(project=p.to_dict(), info=_clean(dict(key=key, title=e.title, group=e.group, objective=e.objective, theory=e.theory, steps=[_web_text(t) for t in e.steps], duration=e.duration))))


def _net_pack(res, key="", proj=None):
    out = {k: _clean(v) for k, v in res.items() if k != "network"}
    out["ok"] = True
    e = _nx.EXAMPLES.get(key)
    if e is not None and e.check:
        try:
            out["checks"] = [dict(name=n, passed=bool(ok), detail=d) for n, ok, d in e.check(res)]
        except Exception:                                                    # noqa: BLE001
            out["checks"] = []
    return out


def net_run(project_json: str, duration: float = 0.0, key: str = "") -> str:
    try:
        p = NetProject.from_dict(json.loads(project_json))
        res = _net_simulate(p, float(duration) if duration else None)
        return json.dumps(_net_pack(res, key))
    except _ne.NetError as ex:
        return json.dumps(dict(ok=False, error=str(ex)))
    except Exception as ex:                                                  # noqa: BLE001
        return json.dumps(dict(ok=False, error=f"{type(ex).__name__}: {ex}"))


def net_probe(project_json: str, src_id: str, dst_ip: str, kind: str) -> str:
    try:
        p, dur = probe_project(NetProject.from_dict(json.loads(project_json)), src_id, dst_ip, kind)
        return json.dumps(_net_pack(_net_simulate(p, dur)))
    except _ne.NetError as ex:
        return json.dumps(dict(ok=False, error=str(ex)))
    except Exception as ex:                                                  # noqa: BLE001
        return json.dumps(dict(ok=False, error=f"{type(ex).__name__}: {ex}"))


def net_matrix(project_json: str) -> str:
    try:
        p, dur, ips, srcs = matrix_project(NetProject.from_dict(json.loads(project_json)))
        if not srcs:
            return json.dumps(dict(ok=False, error="Give at least one host an IP address first"))
        res = _net_simulate(p, dur)
        out = _net_pack(res)
        out["ips"] = ips; out["srcs"] = srcs
        return json.dumps(out)
    except _ne.NetError as ex:
        return json.dumps(dict(ok=False, error=str(ex)))
    except Exception as ex:                                                  # noqa: BLE001
        return json.dumps(dict(ok=False, error=f"{type(ex).__name__}: {ex}"))


def net_node_ip(project_json: str) -> str:
    p = NetProject.from_dict(json.loads(project_json))
    return json.dumps({n.id: node_ip(n) for n in p.nodes.values()})


