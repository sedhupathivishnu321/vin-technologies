"""Buzzer sound: synthesised from the simulated drive waveform and played through the system speaker (Windows winsound).

* active buzzer  – sounds its built-in 2.3 kHz tone while the simulated supply across it is ≥ 2 V
* passive buzzer – reproduces the waveform it is driven with (e.g. the square wave of Arduino tone()), taken from the logged pin edges
"""
from __future__ import annotations
import io
import struct
import wave

import numpy as np

RATE = 22050
MAX_SECONDS = 12.0
ACTIVE_HZ = 2300.0
ACTIVE_THRESHOLD_V = 2.0


def synth_buzzer(b: dict) -> np.ndarray:
    """Float samples in [-1, 1] for one buzzer description (see AnalogEngine._collect_buzzers)."""
    dur = min(float(b["tstop"]), MAX_SECONDS)
    n = int(dur * RATE)
    if n <= 0:
        return np.zeros(0)
    t = np.arange(n) / RATE
    powered = np.abs(np.interp(t, b["t"], b["v"])) >= ACTIVE_THRESHOLD_V
    if b["kind"] == "speaker":                                      # reproduce the voltage across the speaker (full scale 5 V)
        return np.clip(np.interp(t, b["t"], b["v"]) / 5.0, -1.0, 1.0) * 0.8 * float(b["volume"])
    if b["kind"] == "active":
        wave_ = np.sign(np.sin(2 * np.pi * ACTIVE_HZ * t)) * 0.45
        return wave_ * powered * float(b["volume"])
    ev = b.get("events")
    if not ev:
        return np.zeros(n)                                         # a passive buzzer driven by DC only clicks, it does not sustain a tone
    times = np.array([e[0] for e in ev])
    levels = np.array([e[1] for e in ev], float)
    idx = np.searchsorted(times, t, side="right") - 1
    lv = np.where(idx >= 0, levels[np.clip(idx, 0, None)], 0.0)
    since = t - times[np.clip(idx, 0, None)]
    toggling = (idx >= 0) & (since < 0.01)                            # no edge for 10 ms = the pin is idle, so no sound
    return (2 * lv - 1) * 0.45 * float(b["volume"]) * toggling


def mix(buzzers: list) -> np.ndarray:
    parts = [synth_buzzer(b) for b in buzzers]
    parts = [p for p in parts if p.size]
    if not parts:
        return np.zeros(0)
    n = max(p.size for p in parts)
    out = np.zeros(n)
    for p in parts:
        out[: p.size] += p
    return np.clip(out, -1, 1)


def to_wav_bytes(samples: np.ndarray) -> bytes:
    pcm = (np.clip(samples, -1, 1) * 32000).astype("<i2")
    buf = io.BytesIO()
    with wave.open(buf, "wb") as w:
        w.setnchannels(1); w.setsampwidth(2); w.setframerate(RATE); w.writeframes(pcm.tobytes())
    return buf.getvalue()


def dominant_frequency(samples: np.ndarray) -> float:
    """Frequency of the loudest component (used by tests and the status bar)."""
    if samples.size < 64 or not np.any(samples):
        return 0.0
    spec = np.abs(np.fft.rfft(samples * np.hanning(samples.size)))
    return float(np.argmax(spec[1:]) + 1) * RATE / samples.size


def play(samples: np.ndarray) -> bool:
    """Play through the default audio device (asynchronously). Returns False if there is nothing to play or no speaker API."""
    if samples.size == 0 or not np.any(samples):
        return False
    try:
        import os
        import tempfile
        import winsound
        path = os.path.join(tempfile.gettempdir(), "learnerslab_buzzer.wav")
        stop()
        with open(path, "wb") as f:
            f.write(to_wav_bytes(samples))
        winsound.PlaySound(path, winsound.SND_FILENAME | winsound.SND_ASYNC)
        return True
    except Exception:                                             # noqa: BLE001 — no audio device / not Windows
        return False


def stop():
    try:
        import winsound
        winsound.PlaySound(None, winsound.SND_PURGE)
    except Exception:                                             # noqa: BLE001
        pass
