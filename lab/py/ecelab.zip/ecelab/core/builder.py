"""Small helper for programmatically building projects (templates and analyses)."""
from __future__ import annotations
from .model import Project


class Builder:
    def __init__(self, name="Untitled"):
        self.p = Project(name)

    def add(self, type_, x=0, y=0, rot=0, mirror=False, **params):
        return self.p.add_component(type_, x, y, rot, mirror, params=params).ref

    def wire(self, *chains):
        """wire('V1.+', 'R1.1', 'R2.1') connects consecutive pins pairwise (a-b, b-c)."""
        for ch in chains:
            for a, b in zip(ch, ch[1:]):
                if a == b:
                    continue
                self.p.connect(a, b)
        return self

    def gnd(self, x, y, *pins):
        g = self.add("ground", x, y)
        for pin in pins:
            self.p.connect(pin, f"{g}.G")
        return g

    def set(self, ref, **params):
        self.p.by_ref(ref).params.update(params)

    def __getattr__(self, k):
        return getattr(self.p, k)
