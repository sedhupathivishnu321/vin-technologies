"""Behavioural models of the catalogue's digital ICs.

Each model is `fn(ins, prev, st) -> (outs, new_state)`; levels are 0/1.
* `ins`  – input levels now,
* `prev` – input levels at the last accepted time step (data inputs of edge-triggered parts are sampled from here, so the
           result does not depend on how often the solver re-evaluates inside one step),
* `st`   – committed internal state (flip-flop bits, counter values).
Propagation delay is not modelled; outputs follow within the solver time step.
"""
from __future__ import annotations


class Model:
    def __init__(self, ins, outs, fn, init=None, oc=()):
        self.ins, self.outs, self.fn = tuple(ins), tuple(outs), fn
        self.oc = frozenset(oc)                    # open-collector outputs: only pull low
        self._init = init or (lambda: {})

    def init(self):
        return dict(self._init())


# ------------------------------------------------------------------ gates
OPS = {
    "nand": lambda a, b: 1 - (a & b), "nor": lambda a, b: 1 - (a | b), "and": lambda a, b: a & b,
    "or": lambda a, b: a | b, "xor": lambda a, b: a ^ b, "not": lambda a: 1 - a,
}


def gates(op, groups):
    """groups: [(inputs..., output)] pin names."""
    f = OPS[op]
    ins = [p for g in groups for p in g[:-1]]
    outs = [g[-1] for g in groups]

    def fn(i, prev, st):
        return {g[-1]: f(*[i[p] for p in g[:-1]]) for g in groups}, st
    return Model(ins, outs, fn)


# ------------------------------------------------------------------ flip-flops
def dual_d():
    """7474: positive-edge D flip-flop with active-low preset and clear (two per package)."""
    def fn(i, prev, st):
        o, ns = {}, dict(st)
        for n in "12":
            q = st.get(n + "Q", 0)
            clr, pre = i[n + "CLR"], i[n + "PRE"]
            if clr == 0 and pre == 0:
                o[n + "Q"], o[n + "QN"] = 1, 1          # both outputs high while both are asserted (datasheet)
                ns[n + "Q"] = q
                continue
            if clr == 0:
                q = 0
            elif pre == 0:
                q = 1
            elif prev[n + "CLK"] == 0 and i[n + "CLK"] == 1:
                q = prev[n + "D"]
            ns[n + "Q"] = q
            o[n + "Q"], o[n + "QN"] = q, 1 - q
        return o, ns
    ins = [f"{n}{p}" for n in "12" for p in ("CLR", "D", "CLK", "PRE")]
    return Model(ins, [f"{n}{p}" for n in "12" for p in ("Q", "QN")], fn)


def dual_jk():
    """7476: negative-edge JK flip-flop with active-low preset and clear (two per package)."""
    def fn(i, prev, st):
        o, ns = {}, dict(st)
        for n in "12":
            q = st.get(n + "Q", 0)
            clr, pre = i[n + "CLR"], i[n + "PRE"]
            if clr == 0 and pre == 0:
                o[n + "Q"], o[n + "QN"] = 1, 1
                continue
            if clr == 0:
                q = 0
            elif pre == 0:
                q = 1
            elif prev[n + "CLK"] == 1 and i[n + "CLK"] == 0:
                j, k = prev[n + "J"], prev[n + "K"]
                q = q if (j, k) == (0, 0) else 1 if (j, k) == (1, 0) else 0 if (j, k) == (0, 1) else 1 - q
            ns[n + "Q"] = q
            o[n + "Q"], o[n + "QN"] = q, 1 - q
        return o, ns
    ins = [f"{n}{p}" for n in "12" for p in ("CLK", "PRE", "CLR", "J", "K")]
    return Model(ins, [f"{n}{p}" for n in "12" for p in ("Q", "QN")], fn)


# ------------------------------------------------------------------ counters
def _fall(i, prev, p):
    return prev[p] == 1 and i[p] == 0


def counter7493():
    """7493: ÷2 (CKA→QA) and ÷8 (CKB→QB,QC,QD) ripple counters, count on the falling clock edge, reset when R0(1)·R0(2)."""
    def fn(i, prev, st):
        a, b = st.get("a", 0), st.get("b", 0)
        if i["R01"] and i["R02"]:
            a = b = 0
        else:
            if _fall(i, prev, "CKA"):
                a ^= 1
            if _fall(i, prev, "CKB"):
                b = (b + 1) & 7
        return {"QA": a, "QB": b & 1, "QC": (b >> 1) & 1, "QD": (b >> 2) & 1}, {"a": a, "b": b}
    return Model(["CKA", "CKB", "R01", "R02"], ["QA", "QB", "QC", "QD"], fn)


def counter7490():
    """7490: ÷2 (CKA→QA) and ÷5 (CKB→QB,QC,QD); R9 inputs set the count to 9, R0 inputs clear it."""
    def fn(i, prev, st):
        a, b = st.get("a", 0), st.get("b", 0)
        if i["R91"] and i["R92"]:
            a, b = 1, 4                                   # QD QC QB QA = 1001
        elif i["R01"] and i["R02"]:
            a = b = 0
        else:
            if _fall(i, prev, "CKA"):
                a ^= 1
            if _fall(i, prev, "CKB"):
                b = (b + 1) % 5
        return {"QA": a, "QB": b & 1, "QC": (b >> 1) & 1, "QD": (b >> 2) & 1}, {"a": a, "b": b}
    return Model(["CKA", "CKB", "R01", "R02", "R91", "R92"], ["QA", "QB", "QC", "QD"], fn)


# ------------------------------------------------------------------ BCD to seven-segment (7447, active-low open-collector outputs)
_SEG = "abcdefg"
#            a  b  c  d  e  f  g   (1 = segment lit)
_DIGITS = {
    0: "1111110", 1: "0110000", 2: "1101101", 3: "1111001", 4: "0110011", 5: "1011011", 6: "0011111", 7: "1110000",
    8: "1111111", 9: "1110011",
    10: "0001101", 11: "0011001", 12: "0100011", 13: "1001011", 14: "0001111", 15: "0000000",
}


def bcd7447():
    def fn(i, prev, st):
        n = i["A"] | (i["B"] << 1) | (i["C"] << 2) | (i["D"] << 3)
        if i["BI"] == 0:
            lit = "0000000"
        elif i["LT"] == 0:
            lit = "1111111"
        elif n == 0 and i["RBI"] == 0:
            lit = "0000000"
        else:
            lit = _DIGITS[n]
        return {s: (0 if lit[k] == "1" else 1) for k, s in enumerate(_SEG)}, st       # outputs are active low
    return Model(["A", "B", "C", "D", "LT", "RBI", "BI"], list(_SEG), fn, oc=_SEG)


# ------------------------------------------------------------------ decoders / muxes / arithmetic
def decoder138():
    def fn(i, prev, st):
        en = i["G1"] == 1 and i["G2A"] == 0 and i["G2B"] == 0
        idx = i["A"] | (i["B"] << 1) | (i["C"] << 2)
        return {f"Y{k}": (0 if (en and k == idx) else 1) for k in range(8)}, st
    return Model(["A", "B", "C", "G1", "G2A", "G2B"], [f"Y{k}" for k in range(8)], fn)


def mux151():
    def fn(i, prev, st):
        idx = i["A"] | (i["B"] << 1) | (i["C"] << 2)
        y = i[f"D{idx}"] if i["G"] == 0 else 0
        return {"Y": y, "W": 1 - y}, st
    return Model([f"D{k}" for k in range(8)] + ["A", "B", "C", "G"], ["Y", "W"], fn)


def adder7483():
    def fn(i, prev, st):
        a = sum(i[f"A{k}"] << (k - 1) for k in range(1, 5))
        b = sum(i[f"B{k}"] << (k - 1) for k in range(1, 5))
        s = a + b + i["C0"]
        o = {f"S{k}": (s >> (k - 1)) & 1 for k in range(1, 5)}
        o["C4"] = (s >> 4) & 1
        return o, st
    return Model([f"A{k}" for k in range(1, 5)] + [f"B{k}" for k in range(1, 5)] + ["C0"], [f"S{k}" for k in range(1, 5)] + ["C4"], fn)


def comparator7485():
    def fn(i, prev, st):
        a = sum(i[f"A{k}"] << k for k in range(4))
        b = sum(i[f"B{k}"] << k for k in range(4))
        if a > b:
            r = (1, 0, 0)
        elif a < b:
            r = (0, 0, 1)
        elif i["IEQ"]:
            r = (0, 1, 0)
        elif i["IGT"] and i["ILT"]:
            r = (0, 0, 0)
        elif i["IGT"]:
            r = (1, 0, 0)
        elif i["ILT"]:
            r = (0, 0, 1)
        else:
            r = (1, 0, 1)
        return {"OGT": r[0], "OEQ": r[1], "OLT": r[2]}, st
    return Model([f"A{k}" for k in range(4)] + [f"B{k}" for k in range(4)] + ["IGT", "IEQ", "ILT"], ["OGT", "OEQ", "OLT"], fn)
