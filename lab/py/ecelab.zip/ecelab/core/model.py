"""Project data model: components, wires, nets, versioned JSON persistence."""
from __future__ import annotations
import copy
import json
import uuid
from dataclasses import dataclass, field

from . import parts

SCHEMA = "ecelab.project"
SCHEMA_VERSION = 2


class ProjectError(Exception):
    pass


def _rot(dx: int, dy: int, rot: int, mirror: bool):
    if mirror:
        dx = -dx
    for _ in range(rot % 4):          # 90° clockwise in screen coordinates (y down)
        dx, dy = -dy, dx
    return dx, dy


@dataclass
class Component:
    id: str
    type: str
    ref: str
    x: int = 0
    y: int = 0
    rot: int = 0
    mirror: bool = False
    params: dict = field(default_factory=dict)

    @property
    def defn(self) -> parts.PartDef:
        return parts.get(self.type)

    def pin_offset(self, pin: str):
        p = self.defn.pin(pin)
        return _rot(p.dx, p.dy, self.rot, self.mirror)

    def pin_pos(self, pin: str):
        ox, oy = self.pin_offset(pin)
        return self.x + ox, self.y + oy

    def to_dict(self):
        return dict(id=self.id, type=self.type, ref=self.ref, x=self.x, y=self.y, rot=self.rot,
                    mirror=self.mirror, params=copy.deepcopy(self.params))

    @staticmethod
    def from_dict(d):
        t = d["type"]
        params = parts.default_params(t)
        params.update(d.get("params", {}))
        return Component(d["id"], t, d["ref"], int(d.get("x", 0)), int(d.get("y", 0)), int(d.get("rot", 0)),
                         bool(d.get("mirror", False)), params)


@dataclass
class Wire:
    id: str
    a: tuple      # (component_id, pin)
    b: tuple
    color: str = ""   # '' = automatic colour by net (realistic view)
    via: list = field(default_factory=list)   # user waypoints [(gx, gy)] in grid units; [] = automatic route

    def to_dict(self):
        d = dict(id=self.id, a=list(self.a), b=list(self.b), color=self.color)
        if self.via:
            d["via"] = [list(v) for v in self.via]
        return d

    @staticmethod
    def from_dict(d):
        return Wire(d["id"], tuple(d["a"]), tuple(d["b"]), d.get("color", ""), [tuple(v) for v in d.get("via", [])])


@dataclass
class Net:
    index: int
    name: str
    pins: list            # [(cid, pin)]
    is_ground: bool = False


def new_id() -> str:
    return uuid.uuid4().hex[:8]


class Project:
    def __init__(self, name="Untitled"):
        self.meta = {"name": name, "author": "", "notes": ""}
        self.components: dict[str, Component] = {}
        self.wires: list[Wire] = []
        self.canvas = {"grid": True, "snap": True, "view": "realistic"}
        self.sim = {"analysis": "transient", "tstop": 0.01, "points": 2000, "uic": True, "seed": 1,
                    "fmin": 1.0, "fmax": 1e6, "fpoints": 200}
        self.experiment = {"id": None, "completed": False, "answers": {}}
        self.params: dict = {}      # analysis-experiment parameters
        self.path: str | None = None

    # ---------------------------------------------------------------- editing
    def next_ref(self, type_: str) -> str:
        prefix = parts.get(type_).prefix
        used = {c.ref for c in self.components.values()}
        n = 1
        while f"{prefix}{n}" in used:
            n += 1
        return f"{prefix}{n}"

    def add_component(self, type_: str, x=0, y=0, rot=0, mirror=False, ref=None, params=None, cid=None):
        c = Component(cid or new_id(), type_, ref or self.next_ref(type_), x, y, rot, mirror,
                      parts.default_params(type_))
        if params:
            c.params.update(params)
        self.components[c.id] = c
        return c

    def remove_component(self, cid: str):
        self.components.pop(cid, None)
        self.wires = [w for w in self.wires if w.a[0] != cid and w.b[0] != cid]

    def by_ref(self, ref: str) -> Component:
        for c in self.components.values():
            if c.ref == ref:
                return c
        raise KeyError(ref)

    def can_wire(self, a, b):
        """Return (ok, reason)."""
        for cid, pin in (a, b):
            if cid not in self.components:
                return False, "Unknown component"
            try:
                self.components[cid].defn.pin(pin)
            except KeyError:
                return False, f"{self.components[cid].ref} has no pin {pin}"
        if a == b:
            return False, "Cannot connect a pin to itself"
        if any({w.a, w.b} == {a, b} for w in self.wires):
            return False, "Wire already exists"
        da, db = self.components[a[0]].defn.engine, self.components[b[0]].defn.engine
        if "board" in (da, db):
            return True, ""
        for cid in (a[0], b[0]):
            if self.components[cid].defn.engine == "none":
                return False, (f"{self.components[cid].ref} ({self.components[cid].defn.name}) has no simulation "
                               "model and cannot be wired")
        if da != db:
            return False, "Analog and digital pins cannot be wired together (no mixed-signal model)"
        return True, ""

    def add_wire(self, a, b, wid=None):
        ok, why = self.can_wire(tuple(a), tuple(b))
        if not ok:
            raise ProjectError(why)
        w = Wire(wid or new_id(), tuple(a), tuple(b))
        self.wires.append(w)
        return w

    def connect(self, ref_pin_a: str, ref_pin_b: str):
        """Convenience: connect('R1.2', 'C1.+')."""
        def split(s):
            ref, pin = s.split(".", 1)
            return (self.by_ref(ref).id, pin)
        return self.add_wire(split(ref_pin_a), split(ref_pin_b))

    # ---------------------------------------------------------------- breadboard seating
    def hole_map(self):
        """{(gx, gy): (board id, hole name)} for every breadboard hole."""
        out = {}
        for bd in self.components.values():
            if bd.defn.engine == "board":
                for p in bd.defn.pins:
                    out[bd.pin_pos(p.name)] = (bd.id, p.name)
        return out

    def seated_pins(self, cid: str, holes=None) -> int:
        """How many pins of component `cid` currently sit exactly in a breadboard hole."""
        holes = self.hole_map() if holes is None else holes
        c = self.components[cid]
        return sum(1 for p in c.defn.pins if c.pin_pos(p.name) in holes)

    def seated_on(self, board_id: str) -> list:
        """Ids of parts with at least one pin in a hole of the given breadboard."""
        bd = self.components[board_id]
        mine = {bd.pin_pos(p.name) for p in bd.defn.pins}
        out = []
        for c in self.components.values():
            if c.defn.engine == "board" or c.type in ("arduino", "ground"):
                continue
            if any(c.pin_pos(p.name) in mine for p in c.defn.pins):
                out.append(c.id)
        return out

    def snap_offset(self, cid: str, reach: int = 4):
        """Translation (dx, dy) in grid units, |d| <= reach, that puts the most pins of a part into breadboard holes.
        Among equally good placements the one that does not short the part to itself (two of its pins on one strip) wins, then the nearest.
        Returns (dx, dy, pins_seated). A part needs min(pins, 2) pins in holes to count as seated."""
        c = self.components[cid]
        pins = c.defn.pins
        holes = self.hole_map()
        if not holes or c.defn.engine == "board" or c.type in ("arduino", "ground") or not pins or len(pins) > 20:
            return 0, 0, 0
        pos = [c.pin_pos(p.name) for p in pins]
        cands = {(0, 0)}
        for (x, y) in pos[:3]:                              # translations that bring one of the first pins onto a nearby hole
            for dx in range(-reach, reach + 1):
                for dy in range(-reach, reach + 1):
                    if (x + dx, y + dy) in holes:
                        cands.add((dx, dy))
        best = None
        for dx, dy in cands:
            strips = [(holes[(x + dx, y + dy)][0], parts.breadboard_group(holes[(x + dx, y + dy)][1])) for (x, y) in pos if (x + dx, y + dy) in holes]
            n = len(strips)
            shorts = n - len(set(strips))
            key = (-n, shorts, abs(dx) + abs(dy))
            if best is None or key < best[0]:
                best = (key, dx, dy, n)
        _, dx, dy, n = best
        if n < min(len(pins), 2):
            return 0, 0, self.seated_pins(cid, holes)
        return dx, dy, n

    # ---------------------------------------------------------------- nets
    def nets(self) -> list[Net]:
        """Union-find over wired pins. Unwired pins form single-pin nets."""
        parent = {}

        def find(k):
            while parent[k] != k:
                parent[k] = parent[parent[k]]
                k = parent[k]
            return k

        for c in self.components.values():
            for p in c.defn.pins:
                parent[(c.id, p.name)] = (c.id, p.name)
        def union(x, y):
            rx, ry = find(x), find(y)
            if rx != ry:
                parent[rx] = ry

        for w in self.wires:
            if w.a in parent and w.b in parent:
                union(w.a, w.b)
        for c in self.components.values():                      # pins wired together inside a part (e.g. push-button pairs)
            for grp in c.defn.links:
                for other in grp[1:]:
                    union((c.id, grp[0]), (c.id, other))
        # breadboards: strips are internally connected, and any part pin sitting exactly on a hole is connected to that hole
        boards = [c for c in self.components.values() if c.defn.engine == "board"]
        if boards:
            hole_at, strips = {}, {}
            for bd in boards:
                for p in bd.defn.pins:
                    key = (bd.id, p.name)
                    strips.setdefault((bd.id, parts.breadboard_group(p.name)), []).append(key)
                    hole_at[bd.pin_pos(p.name)] = key
            for members in strips.values():
                for m in members[1:]:
                    union(members[0], m)
            for c in self.components.values():
                if c.defn.engine == "board":
                    continue
                for p in c.defn.pins:
                    h = hole_at.get(c.pin_pos(p.name))
                    if h is not None:
                        union((c.id, p.name), h)
        groups: dict = {}
        for k in parent:
            groups.setdefault(find(k), []).append(k)
        nets = []
        ordered = sorted(groups.values(), key=lambda g: min(self.components[c].ref + p for c, p in g))
        for g in ordered:
            ground = any(self.components[c].type == "ground" or (self.components[c].type == "arduino" and p.startswith("GND")) for c, p in g)
            nets.append(Net(len(nets), "", sorted(g, key=lambda k: (self.components[k[0]].ref, k[1])), ground))
        n = 0
        for net in nets:
            if net.is_ground:
                net.name = "GND"
            else:
                n += 1
                net.name = f"N{n}"
        return nets

    def net_of(self):
        out = {}
        for n in self.nets():
            for k in n.pins:
                out[k] = n
        return out

    # ---------------------------------------------------------------- persistence
    def to_dict(self):
        return {
            "schema": SCHEMA, "version": SCHEMA_VERSION, "meta": self.meta, "canvas": self.canvas,
            "components": [c.to_dict() for c in self.components.values()],
            "wires": [w.to_dict() for w in self.wires], "simulation": self.sim,
            "experiment": self.experiment, "parameters": self.params,
        }

    @staticmethod
    def from_dict(d):
        d = migrate(d)
        p = Project(d["meta"].get("name", "Untitled"))
        p.meta.update(d["meta"])
        p.canvas.update(d.get("canvas", {}))
        p.sim.update(d.get("simulation", {}))
        p.experiment.update(d.get("experiment", {}))
        p.params = dict(d.get("parameters", {}))
        for cd in d["components"]:
            try:
                c = Component.from_dict(cd)
            except KeyError as e:
                raise ProjectError(f"Project uses unknown part type: {e}") from e
            p.components[c.id] = c
        for wd in d["wires"]:
            w = Wire.from_dict(wd)
            ok, why = p.can_wire(w.a, w.b) if w.a != w.b else (False, "self")
            if not ok and why != "Wire already exists":
                raise ProjectError(f"Invalid wire {w.id} in file: {why}")
            if ok:
                p.wires.append(w)
        return p

    def clone(self):
        q = Project.from_dict(self.to_dict())
        q.path = self.path
        return q

    def save(self, path=None):
        path = path or self.path
        if not path:
            raise ProjectError("No path")
        with open(path, "w", encoding="utf-8") as f:
            json.dump(self.to_dict(), f, indent=1)
        self.path = path

    @staticmethod
    def load(path):
        try:
            with open(path, "r", encoding="utf-8") as f:
                d = json.load(f)
        except (OSError, json.JSONDecodeError) as e:
            raise ProjectError(f"Cannot read {path}: {e}") from e
        p = Project.from_dict(d)
        p.path = path
        return p


def migrate(d: dict) -> dict:
    """Validate the envelope and upgrade older schema versions."""
    if not isinstance(d, dict) or d.get("schema") != SCHEMA:
        raise ProjectError("Not a LEARNERS LAB project file")
    v = d.get("version", 0)
    if v > SCHEMA_VERSION:
        raise ProjectError(f"Project version {v} is newer than this application supports ({SCHEMA_VERSION})")
    d = copy.deepcopy(d)
    if v < 2:                       # v1 had no 'parameters' / 'experiment' blocks
        d.setdefault("parameters", {})
        d.setdefault("experiment", {})
        d["version"] = 2
    for key in ("meta", "components", "wires"):
        if key not in d:
            raise ProjectError(f"Project file is missing '{key}'")
    return d
