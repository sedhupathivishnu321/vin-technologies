"""Part registry: every placeable part, its pins (on the 0.1 in grid, ArduinoForge geometry for real-looking parts), parameters and model.

Pin offsets are in grid units relative to the part origin (rotation 0, no mirror). Parts drawn with ArduinoForge artwork carry `sprite`
= (sprite id, origin x px, origin y px, width px, height px) where one grid unit = 10 sprite px.
"""
from __future__ import annotations
import json
import math as _math
import os
from dataclasses import dataclass, field

SIMULATED = "simulated"
VISUAL_ONLY = "visual-only"
_AF_DIR = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "assets", "af")


@dataclass(frozen=True)
class Pin:
    name: str
    dx: int
    dy: int
    role: str = "io"          # io | in | out  (digital drivers use 'out')


@dataclass(frozen=True)
class Param:
    default: object
    unit: str = ""
    label: str = ""
    choices: tuple = ()        # non-empty => combo box
    help: str = ""


@dataclass
class PartDef:
    type: str
    name: str
    category: str
    description: str
    engine: str                # analog | digital | both | board | none
    prefix: str
    pins: tuple
    params: dict = field(default_factory=dict)
    status: str = SIMULATED
    level: str = "beginner"    # beginner | intermediate | advanced
    symbol: str = "box"
    box: tuple = (2, 2)        # half width/height (grid units) for box symbols
    label: str = ""            # text drawn inside box symbols
    model_note: str = ""
    presets: dict = field(default_factory=dict)      # name -> {param: value}: typical-part presets the user can start from and then edit
    sprite: tuple | None = None                      # (sprite id, origin x px, origin y px, width px, height px)
    links: tuple = ()                                # groups of pin names that are wired together inside the part
    optional: frozenset = frozenset()                # pins that may stay unconnected without a warning
    all_optional: bool = False
    base: str = ""                                   # catalogue parts: analog model type to build (e.g. "diode", "zener")
    spec: object = None                              # catalogue parts: model description (ecelab.catalogue.Spec)
    info: dict = field(default_factory=dict)         # catalogue parts: datasheet-style fields shown in the inspector
    supply: tuple = ()                               # pins that must be wired for the part to work

    def pin(self, name):
        for p in self.pins:
            if p.name == name:
                return p
        raise KeyError(f"{self.type} has no pin {name!r}")


REGISTRY: dict[str, PartDef] = {}

CATEGORIES = ["Boards and breadboards", "Passive components", "Semiconductors", "Analog ICs", "Digital ICs", "Power ICs", "Sources and power",
              "Switches and buzzers", "Digital logic", "Instruments"]


def _reg(p: PartDef):
    REGISTRY[p.type] = p
    return p


def P(default, unit="", label="", choices=(), help=""):
    return Param(default, unit, label, tuple(choices), help)


def _meta():
    with open(os.path.join(_AF_DIR, "_meta.json"), "r", encoding="utf-8") as f:
        return {m["id"]: m for m in json.load(f)}


_AF = _meta()


def af_pins(sprite_id, mapping, origin=None, role="io"):
    """Pins of an ArduinoForge part. mapping: {our_name: af_pin_id}. origin: (x, y) sprite px (default: top-left)."""
    m = _AF[sprite_id]
    by = {p["id"]: p for p in m["pins"]}
    ox, oy = origin if origin is not None else (0, 0)
    return tuple(Pin(name, int(round((by[i]["x"] - ox) / 10)), int(round((by[i]["y"] - oy) / 10)), role) for name, i in mapping.items())


def _spr(sprite_id, origin):
    m = _AF[sprite_id]
    return (sprite_id, origin[0], origin[1], m["w"], m["h"])


# ----------------------------------------------------------------------------------------- passive (ArduinoForge geometry)
_reg(PartDef("resistor", "Resistor", "Passive components", "Carbon-film resistor with colour bands.", "analog", "R",
             af_pins("r220", {"1": "A", "2": "B"}, (10, 10)),
             {"R": P(1000.0, "Ω", "Resistance"), "tol": P(5.0, "%", "Tolerance (drawn, not simulated)"), "P": P(0.25, "W", "Power rating")},
             symbol="resistor", sprite=_spr("r220", (10, 10))))
_reg(PartDef("capacitor", "Electrolytic capacitor", "Passive components", "Polarised capacitor (+ longer leg, stripe on −).", "analog", "C",
             af_pins("e100", {"+": "P", "−": "N"}, (10, 60)),
             {"C": P(100e-6, "F", "Capacitance"), "v0": P(0.0, "V", "Initial voltage"), "Vmax": P(25.0, "V", "Voltage rating")},
             symbol="capacitor", sprite=_spr("e100", (10, 60))))
_reg(PartDef("capacitor_ceramic", "Ceramic capacitor", "Passive components", "Non-polarised ceramic disc capacitor.", "analog", "C",
             af_pins("c104", {"+": "A", "−": "B"}, (10, 40)),
             {"C": P(100e-9, "F", "Capacitance"), "v0": P(0.0, "V", "Initial voltage"), "Vmax": P(50.0, "V", "Voltage rating")},
             symbol="capacitor", sprite=_spr("c104", (10, 40))))
_reg(PartDef("inductor", "Inductor", "Passive components", "Axial inductor.", "analog", "L", af_pins("inductor100u", {"1": "A", "2": "B"}, (10, 10)),
             {"L": P(1e-3, "H", "Inductance"), "i0": P(0.0, "A", "Initial current")}, symbol="inductor", level="intermediate",
             sprite=_spr("inductor100u", (10, 10))))
_reg(PartDef("pot", "Potentiometer", "Passive components", "Rotary potentiometer: R·pos between 1–W, R·(1−pos) between W–2.", "analog", "RV",
             af_pins("pot10k", {"1": "1", "W": "W", "2": "2"}, (10, 50)),
             {"R": P(10000.0, "Ω", "Total resistance"), "pos": P(0.5, "", "Wiper position (0–1)"), "P": P(0.25, "W", "Power rating")},
             symbol="resistor", sprite=_spr("pot10k", (10, 50))))

# ----------------------------------------------------------------------------------------- switches, buzzers
_reg(PartDef("switch", "Toggle switch (SPST)", "Switches and buzzers", "Ideal switch; closed = 1 mΩ, open = 1 GΩ.", "analog", "S",
             af_pins("toggle-spst", {"1": "A", "2": "B"}, (10, 50)), {"closed": P(False, "", "Closed")}, symbol="switch", sprite=_spr("toggle-spst", (10, 50))))
_reg(PartDef("pushbutton", "Push button", "Switches and buzzers",
             "Tactile button (pins 1–2 are joined, 3–4 are joined). Pressed per the pattern: each character is one step; 1 = pressed.", "analog", "SW",
             af_pins("button6", {"1": "1", "2": "2", "3": "3", "4": "4"}, (10, 10)),
             {"pattern": P("0", "", "Press pattern (1 = pressed)"), "step": P(1.0, "s", "Step duration")}, symbol="switch",
             links=(("1", "2"), ("3", "4")), sprite=_spr("button6", (10, 10)),
             model_note="Press timing follows the pattern during a run (e.g. 0110 with 1 s steps: pressed from 1 s to 3 s)."))
_reg(PartDef("buzzer", "Buzzer", "Switches and buzzers",
             "Active buzzer: sounds a 2.3 kHz tone while ≥2 V is applied. Passive (piezo): sounds the waveform you drive it with (e.g. Arduino tone()). "
             "The tone is played through the system speaker after a run.", "analog", "BZ", af_pins("buzzer-active", {"+": "+", "−": "-"}, (10, 60)),
             {"kind": P("active", "", "Type", ("active", "passive")), "volume": P(0.5, "", "Volume (0–1)")}, symbol="box", sprite=_spr("buzzer-active", (10, 60)),
             model_note="Electrical model: 150 Ω load. Sound is synthesised from the simulated drive waveform, not from an assumed tone."))

_reg(PartDef("speaker", "Speaker (8 Ω)", "Switches and buzzers",
             "Loudspeaker: plays through the computer speaker whatever waveform is across it (function generator, LM386 output, Arduino tone()). + terminal marked red.",
             "analog", "SP", af_pins("buzzer-piezo", {"+": "+", "−": "-"}, (10, 60)), {"volume": P(0.5, "", "Volume (0–1)"), "Z": P(8.0, "Ω", "Impedance")},
             symbol="box", sprite=_spr("buzzer-piezo", (10, 60)),
             model_note="Electrical model: a resistor of the given impedance. Audio = the simulated voltage across it (full scale ≈ 5 V), resampled to 22 kHz, at most 12 s; "
                        "use a transient run whose time step is well below 1/(2·highest frequency)."))
_reg(PartDef("motor", "DC motor (6 V)", "Switches and buzzers",
             "Small DC motor: the rotor spins in step with the simulated current and reverses when the polarity is reversed (+ terminal red).",
             "analog", "M", af_pins("dcmotor6v", {"+": "+", "−": "-"}, (10, 70)),
             {"R": P(10.0, "Ω", "Winding resistance"), "Vrated": P(6.0, "V", "Rated voltage"), "rpm": P(6000.0, "rpm", "Speed at rated voltage")},
             symbol="box", sprite=_spr("dcmotor6v", (10, 70)),
             model_note="Electrical model: winding resistance only (no back-EMF or inertia). Speed shown = rpm·V/Vrated, so the torque/speed trade-off is not modelled."))

# ----------------------------------------------------------------------------------------- semiconductors
_reg(PartDef("diode", "Diode", "Semiconductors", "Shockley diode (Is, n); stripe marks the cathode.", "analog", "D", af_pins("d1n4007", {"A": "A", "K": "K"}, (10, 10)),
             {"Is": P(1e-14, "A", "Saturation current"), "n": P(1.0, "", "Ideality"), "Rs": P(0.0, "Ω", "Series resistance"),
              "Imax": P(1.0, "A", "Max forward current")}, symbol="diode", sprite=_spr("d1n4007", (10, 10)),
             model_note="No junction capacitance, no temperature dependence."))
_reg(PartDef("zener", "Zener diode", "Semiconductors", "Diode with reverse-breakdown branch at Vz.", "analog", "D", af_pins("zener51", {"A": "A", "K": "K"}, (10, 10)),
             {"Is": P(1e-14, "A", "Saturation current"), "n": P(1.0, "", "Ideality"), "Vz": P(5.1, "V", "Breakdown voltage"),
              "Rs": P(0.0, "Ω", "Series resistance"), "Pz": P(0.5, "W", "Power rating")}, symbol="zener", sprite=_spr("zener51", (10, 10))))
_reg(PartDef("led", "LED", "Semiconductors", "5 mm LED (A = longer leg). Lights according to the simulated current.", "analog", "D",
             af_pins("led-red", {"A": "A", "K": "K"}, (30, 70)),
             {"Is": P(1e-18, "A", "Saturation current"), "n": P(2.0, "", "Ideality"), "Rs": P(0.0, "Ω", "Series resistance"),
              "color": P("red", "", "Colour", ("red", "green", "yellow", "blue")), "Imax": P(0.02, "A", "Max forward current")},
             symbol="led", sprite=_spr("led-red", (30, 70))))
_reg(PartDef("npn", "NPN transistor (BC547)", "Semiconductors", "Ebers-Moll NPN in a TO-92 package (flat face toward you: C, B, E from the left).", "analog", "Q",
             af_pins("bc547", {"C": "C", "B": "B", "E": "E"}, (10, 50)),
             {"Is": P(1e-14, "A", "Saturation current"), "bf": P(100.0, "", "Forward β"), "br": P(1.0, "", "Reverse β"), "Pd": P(0.625, "W", "Power rating")},
             symbol="npn", level="intermediate", sprite=_spr("bc547", (10, 50))))
_reg(PartDef("opamp", "Op-amp (LM741)", "Analog ICs", "Finite-gain op-amp with tanh output saturation. Offset-null and NC pins are unused.", "analog", "U",
             af_pins("lm741", {"1": "1", "−": "2", "+": "3", "V−": "4", "5": "5", "OUT": "6", "V+": "7", "8": "8"}, (0, 0)),
             {"A": P(1e5, "", "Open-loop gain"), "vsat": P(13.0, "V", "Output saturation (±)")}, symbol="opamp", level="intermediate",
             sprite=_spr("lm741", (0, 0)), optional=frozenset({"1", "5", "8", "V+", "V−"}),
             model_note="Supply pins are not required by the model (output saturates at ±vsat). No GBW/slew limit."))

# ----------------------------------------------------------------------------------------- sources and power
_reg(PartDef("ground", "Ground", "Sources and power", "0 V reference node.", "analog", "GND", (Pin("G", 0, 0),), {}, symbol="ground"))
_reg(PartDef("vdc", "Battery / DC source", "Sources and power", "Ideal DC battery (+ terminal at higher potential); the drawing follows the voltage: AA cell, Li-ion cell or 9 V block.", "analog", "V",
             (Pin("+", 0, -2), Pin("−", 0, 2)), {"V": P(5.0, "V", "Voltage"), "Rs": P(0.0, "Ω", "Series resistance")}, symbol="vsource"))
_reg(PartDef("vac", "Function generator (sine)", "Sources and power", "Bench function generator, sine output: offset + amplitude·sin(2πft+φ). Blue post = signal (+), black = return (−).", "analog", "V",
             (Pin("+", 6, -1), Pin("−", 6, 1)),
             {"amp": P(5.0, "V", "Amplitude (peak)"), "freq": P(1000.0, "Hz", "Frequency"), "offset": P(0.0, "V", "DC offset"), "phase": P(0.0, "°", "Phase")},
             symbol="box", box=(5, 3), label="FG"))
_reg(PartDef("vpulse", "Function generator (square)", "Sources and power", "Bench function generator, square / pulse output. Blue post = signal (+), black = return (−).", "analog", "V",
             (Pin("+", 6, -1), Pin("−", 6, 1)),
             {"v1": P(0.0, "V", "Low level"), "v2": P(5.0, "V", "High level"), "freq": P(1000.0, "Hz", "Frequency"), "duty": P(0.5, "", "Duty cycle"),
              "delay": P(0.0, "s", "Delay"), "edge": P(0.01, "", "Edge time (fraction of period)")}, symbol="box", box=(5, 3), label="FG"))
_reg(PartDef("idc", "DC current source", "Sources and power", "Current leaves the + pin into the circuit.", "analog", "I", (Pin("+", 0, -2), Pin("−", 0, 2)),
             {"I": P(0.001, "A", "Current")}, symbol="isource"))
_reg(PartDef("psu", "Bench power supply (CV/CC)", "Sources and power",
             "Adjustable DC supply with constant-voltage / constant-current limiting; the display shows V, mA and the CV/CC lamp.", "analog", "PS",
             (Pin("+", 6, -1), Pin("−", 6, 1)), {"V": P(5.0, "V", "Voltage setting"), "Ilim": P(0.5, "A", "Current limit"), "on": P(True, "", "Output on")},
             symbol="box", box=(5, 3), label="PSU", model_note="Current limiting is a steep (1 kΩ) foldback beyond the limit."))

# ----------------------------------------------------------------------------------------- instruments
_reg(PartDef("dmm", "Digital multimeter", "Instruments",
             "DT830-style multimeter: DC volts, AC volts (RMS), resistance (1 mA test current, unpowered circuits) and DC current (series). "
             "Red probe = V, black probe = COM.", "analog", "DMM", af_pins("multimeter", {"V": "RED", "COM": "BLK"}, (0, 0)),
             {"mode": P("DC volts", "", "Mode", ("DC volts", "AC volts", "Resistance", "DC current"))}, symbol="box", label="DMM", sprite=_spr("multimeter", (0, 0)),
             model_note="Ohms mode injects 1 mA: use it on an unpowered resistor network. AC volts needs a transient run."))
_reg(PartDef("scope", "Oscilloscope (2-channel)", "Instruments", "High-impedance probes referenced to the GND clip; the screen draws the simulated traces.", "analog", "OSC",
             (Pin("CH1", -6, -2), Pin("CH2", -6, 0), Pin("GND", -6, 2)), {}, symbol="box", box=(5, 4), label="SCOPE"))
_reg(PartDef("ammeter", "Panel ammeter", "Instruments", "Zero-volt series branch; reads current from + to −.", "analog", "A", (Pin("+", -3, 0), Pin("−", 3, 0)), {},
             symbol="ammeter"))
_reg(PartDef("voltmeter", "Panel voltmeter", "Instruments", "10 MΩ input resistance. Reads V(+) − V(−).", "analog", "M", (Pin("+", -3, 0), Pin("−", 3, 0)), {},
             symbol="voltmeter"))


# ----------------------------------------------------------------------------------------- digital logic
def _gate(t, name, label, nin=2):
    pins = ((Pin("A", -3, 0, "in"),) if nin == 1 else (Pin("A", -3, -1, "in"), Pin("B", -3, 1, "in")))
    _reg(PartDef(t, name, "Digital logic", f"{name} gate (zero-delay).", "digital", "U", pins + (Pin("Y", 3, 0, "out"),), {}, symbol="gate", box=(2, 2), label=label))


_gate("and", "AND", "&"); _gate("or", "OR", "≥1"); _gate("not", "NOT", "1", 1)
_gate("nand", "NAND", "&"); _gate("nor", "NOR", "≥1"); _gate("xor", "XOR", "=1"); _gate("xnor", "XNOR", "=1")
_reg(PartDef("dff", "D flip-flop", "Digital logic", "Rising-edge D flip-flop, async active-high reset.", "digital", "U",
             (Pin("D", -3, -1, "in"), Pin("CLK", -3, 1, "in"), Pin("R", 0, -3, "in"), Pin("Q", 3, -1, "out"), Pin("QN", 3, 1, "out")), {"init": P(0, "", "Initial Q")},
             symbol="box", box=(2, 2), label="D FF", level="intermediate"))
_reg(PartDef("jkff", "JK flip-flop", "Digital logic", "Rising-edge JK flip-flop, async active-high reset.", "digital", "U",
             (Pin("J", -3, -1, "in"), Pin("CLK", -3, 0, "in"), Pin("K", -3, 1, "in"), Pin("R", 0, -3, "in"), Pin("Q", 3, -1, "out"), Pin("QN", 3, 1, "out")),
             {"init": P(0, "", "Initial Q")}, symbol="box", box=(2, 2), label="JK FF", level="intermediate"))
_reg(PartDef("tff", "T flip-flop", "Digital logic", "Rising-edge T flip-flop, async active-high reset.", "digital", "U",
             (Pin("T", -3, -1, "in"), Pin("CLK", -3, 1, "in"), Pin("R", 0, -3, "in"), Pin("Q", 3, -1, "out"), Pin("QN", 3, 1, "out")), {"init": P(0, "", "Initial Q")},
             symbol="box", box=(2, 2), label="T FF", level="intermediate"))
_reg(PartDef("counter4", "4-bit binary counter", "Digital logic", "Synchronous up counter, async active-high reset.", "digital", "U",
             (Pin("CLK", -3, -1, "in"), Pin("R", -3, 1, "in"), Pin("Q0", 3, -3, "out"), Pin("Q1", 3, -1, "out"), Pin("Q2", 3, 1, "out"), Pin("Q3", 3, 3, "out")),
             {}, symbol="box", box=(2, 4), label="CTR4", level="intermediate"))
_reg(PartDef("shift4", "4-bit shift register", "Digital logic", "Serial-in shift register (Q0 = first stage).", "digital", "U",
             (Pin("D", -3, -1, "in"), Pin("CLK", -3, 1, "in"), Pin("Q0", 3, -3, "out"), Pin("Q1", 3, -1, "out"), Pin("Q2", 3, 1, "out"), Pin("Q3", 3, 3, "out")),
             {"init": P("0000", "", "Initial Q0..Q3")}, symbol="box", box=(2, 4), label="SHR4", level="intermediate"))
_reg(PartDef("mux2", "2:1 multiplexer", "Digital logic", "Y = S ? B : A.", "digital", "U",
             (Pin("A", -3, -1, "in"), Pin("B", -3, 1, "in"), Pin("S", 0, 3, "in"), Pin("Y", 3, 0, "out")), {}, symbol="box", box=(2, 2), label="MUX"))
_reg(PartDef("hadd", "Half adder", "Digital logic", "SUM = A⊕B, COUT = A·B.", "digital", "U",
             (Pin("A", -3, -1, "in"), Pin("B", -3, 1, "in"), Pin("S", 3, -1, "out"), Pin("C", 3, 1, "out")), {}, symbol="box", box=(2, 2), label="HA"))
_reg(PartDef("fadd", "Full adder", "Digital logic", "SUM = A⊕B⊕CIN, COUT = majority.", "digital", "U",
             (Pin("A", -3, -1, "in"), Pin("B", -3, 0, "in"), Pin("CI", -3, 1, "in"), Pin("S", 3, -1, "out"), Pin("CO", 3, 1, "out")), {}, symbol="box", box=(2, 2), label="FA"))
_reg(PartDef("clock", "Clock source", "Digital logic", "Square clock; starts low, 50 % duty.", "digital", "CLK", (Pin("OUT", 3, 0, "out"),),
             {"freq": P(1.0, "Hz", "Frequency")}, symbol="box", box=(2, 1), label="CLK"))
_reg(PartDef("lswitch", "Logic switch", "Digital logic", "Constant 0/1 input, or a bit pattern stepped once per `step` seconds.", "digital", "SW",
             (Pin("OUT", 3, 0, "out"),), {"value": P(0, "", "Level (0/1)"), "pattern": P("", "", "Pattern, e.g. 0011 (overrides level)"),
                                           "step": P(1.0, "s", "Step duration")}, symbol="box", box=(2, 1), label="SW"))
_reg(PartDef("lprobe", "Logic probe / LED", "Digital logic", "Shows the logic level (X if undriven).", "digital", "PR", (Pin("IN", -3, 0, "in"),), {},
             symbol="box", box=(2, 1), label="PROBE"))
_reg(PartDef("sevenseg", "7-segment display", "Digital logic", "Segments a–g and dp light when their input is logic 1 (common cathode).", "digital", "DS",
             tuple(Pin(n, -3, -4 + i, "in") for i, n in enumerate(("a", "b", "c", "d", "e", "f", "g", "dp"))), {}, symbol="box", box=(2, 5), label="7SEG"))

# ----------------------------------------------------------------------------------------- boards (ArduinoForge geometry and artwork)
from ..mcu.examples import BLINK as _BLINK  # noqa: E402

_uno_names = {p["id"]: p["id"] for p in _AF["uno"]["pins"]}
_reg(PartDef("arduino", "Arduino UNO R3", "Boards and breadboards",
             "Runs your C/C++ sketch on a virtual UNO. Wire D2–D13 to LEDs, buttons, buzzers…; 5V and GND are real rails; A0–A5 read the pin voltage (10-bit ADC).",
             "analog", "UNO", af_pins("uno", _uno_names, (0, 0)),
             {"code": P(_BLINK, "", "Sketch (C/C++)")}, symbol="box", label="UNO", level="intermediate", sprite=_spr("uno", (0, 0)), all_optional=True,
             model_note="Arduino-style C/C++ subset interpreter (not AVR machine code): no interrupts/libraries/pointers; int is 16-bit; only delay() advances time. "
                        "Pin modes are fixed after setup(). Outputs are 5 V behind 25 Ω."))

BB_ROW_Y = {"a": 60, "b": 70, "c": 80, "d": 90, "e": 100, "f": 130, "g": 140, "h": 150, "i": 160, "j": 170}


def breadboard_group(pin_name: str):
    """Electrical strip a hole belongs to: column halves (a–e / f–j) are connected; each of tp, tn, bp, bn is one continuous strip."""
    if pin_name[0] in "abcde" and pin_name[1:].isdigit():
        return "top" + pin_name[1:]
    if pin_name[0] in "fghij" and pin_name[1:].isdigit():
        return "bot" + pin_name[1:]
    return pin_name[:2]


_reg(PartDef("breadboard", "Breadboard (400 points)", "Boards and breadboards",
             "Solderless breadboard: holes a–e of a column are connected, f–j of a column are connected (the centre channel separates them); each of the four power "
             "rails is one strip. Parts connect simply by sitting in the holes; jumper wires attach to holes.", "board", "BB",
             af_pins("breadboard400", {p["id"]: p["id"] for p in _AF["breadboard400"]["pins"]}, (0, 0)), {}, symbol="breadboard", level="beginner",
             sprite=_spr("breadboard400", (0, 0)), all_optional=True,
             model_note="Passive: its strips are merged into the circuit nets. Contacts are ideal (no resistance or capacitance)."))


# ----------------------------------------------------------------------------------------- presets
def _led_is(vf, n=2.0, i=0.01):
    return i * _math.exp(-vf / (n * 0.025852))


REGISTRY["diode"].presets = {
    "1N4007 (rectifier)": {"Is": 14.11e-9, "n": 1.984, "Rs": 0.0339, "Imax": 1.0},
    "1N4148 (small-signal)": {"Is": 2.52e-9, "n": 1.752, "Rs": 0.568, "Imax": 0.2},
    "Schottky (1N5819-like, approx.)": {"Is": 1e-6, "n": 1.1, "Rs": 0.05, "Imax": 1.0},
    "Ideal-ish silicon": {"Is": 1e-14, "n": 1.0, "Rs": 0.0, "Imax": 1.0}}
REGISTRY["zener"].presets = {f"{v:g} V zener": {"Vz": v, "Pz": 0.5} for v in (3.3, 5.1, 6.8, 9.1, 12.0)}
REGISTRY["led"].presets = {f"{c.title()} (Vf≈{vf} V @ 10 mA)": {"color": c, "Is": _led_is(vf), "n": 2.0, "Imax": 0.02}
                           for c, vf in (("red", 1.9), ("green", 2.2), ("yellow", 2.1), ("blue", 3.0))}
REGISTRY["npn"].presets = {"BC547": {"Is": 7.05e-15, "bf": 375.0, "br": 1.0, "Pd": 0.5}, "2N3904": {"Is": 6.734e-15, "bf": 416.4, "br": 0.7374, "Pd": 0.625},
                           "2N2222": {"Is": 14.34e-15, "bf": 255.9, "br": 6.092, "Pd": 0.5}, "Generic β=100": {"Is": 1e-14, "bf": 100.0, "br": 1.0, "Pd": 0.625}}
REGISTRY["opamp"].presets = {"LM741 (typical)": {"A": 2e5, "vsat": 13.0}, "Ideal-ish": {"A": 1e6, "vsat": 15.0}, "Low-gain (A=1e3)": {"A": 1e3, "vsat": 13.0}}
REGISTRY["resistor"].presets = {f"{n} (E12 value)": {"R": v} for n, v in (("100 Ω", 100.0), ("220 Ω", 220.0), ("470 Ω", 470.0), ("1 kΩ", 1e3), ("4.7 kΩ", 4.7e3),
                                                                      ("10 kΩ", 1e4), ("100 kΩ", 1e5))}


def in_engine(defn: PartDef, engine: str) -> bool:
    """True if the part takes part in the given engine ('both' parts belong to analog and digital)."""
    return defn.engine == engine or defn.engine == "both"


def get(type_: str) -> PartDef:
    try:
        return REGISTRY[type_]
    except KeyError:
        raise KeyError(f"Unknown part type {type_!r}") from None


def default_params(type_: str) -> dict:
    return {k: v.default for k, v in get(type_).params.items()}


from . import icmodels as _icmodels  # noqa: E402,F401
from .. import catalogue as _catalogue  # noqa: E402,F401  (registers the IC / discrete catalogue)
