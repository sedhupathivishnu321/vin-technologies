"""Ready-made example circuits. Every example is a real drag-and-drop circuit: parts seated in breadboard holes and wired with jumpers."""
from __future__ import annotations
from dataclasses import dataclass, field

from .core import parts
from .core.model import Project
from .mcu import examples as sk
from .sim.base import Check

LIMIT_BB = "Breadboard contacts are ideal (no contact resistance or capacitance)."
LIMIT_MCU = ("Arduino-style C/C++ subset interpreter (not AVR machine code): no interrupts or libraries, int is 16-bit, only delay() advances time, "
             "pin modes are fixed after setup(). Outputs are 5 V behind 25 Ω.")

BUZZ_PASSIVE = """// Melody on a passive buzzer: tone(pin, frequency, duration)
const int BUZZER = 8;
int notes[8] = {262, 294, 330, 349, 392, 440, 494, 523};

void setup() {
  pinMode(BUZZER, OUTPUT);
}

void loop() {
  for (int i = 0; i < 8; i++) {
    tone(BUZZER, notes[i], 200);
    delay(250);
  }
  delay(1000);
}
"""

BUZZ_ACTIVE = """// Beep an active buzzer: 200 ms on, 300 ms off
const int BUZZER = 8;

void setup() {
  pinMode(BUZZER, OUTPUT);
}

void loop() {
  digitalWrite(BUZZER, HIGH);
  delay(200);
  digitalWrite(BUZZER, LOW);
  delay(300);
}
"""

PWM_LED = """// PWM dimmer: LED on pin 9 at 25 % duty (analogWrite 64 of 255)
void setup() {
  pinMode(9, OUTPUT);
  analogWrite(9, 64);
}

void loop() {
  delay(100);
}
"""

DVM_POT = """// Digital voltmeter: read the potentiometer wiper on A0 and print volts
void setup() {
  Serial.begin(9600);
}

void loop() {
  int raw = analogRead(A0);
  Serial.print("A0 = ");
  Serial.print(raw);
  Serial.print("  V = ");
  Serial.println(raw * 5.0 / 1023.0);
  delay(500);
}
"""


@dataclass
class Example:
    key: str
    group: str
    title: str
    build: object
    sim: dict
    objective: str
    theory: str = ""
    steps: list = field(default_factory=list)
    questions: list = field(default_factory=list)
    limits: str = LIMIT_BB
    check: object = None


EXAMPLES: dict[str, Example] = {}
GROUPS = ["Basic circuits", "Arduino + LEDs", "Arduino + sound", "Arduino + sensors", "ICs and chips"]


class Bench:
    """Builds a project on a breadboard: parts are 'seated' by naming the hole of each pin; jumpers join holes / pins by name."""

    def __init__(self, name, uno=False, bx=36, by=3, code=None, **uno_params):
        self.p = Project(name)
        self.uno = self.p.add_component("arduino", 2, 2, params=dict(code=code, **uno_params)) if uno else None
        self.bb = self.p.add_component("breadboard", bx, by)

    def hole(self, name):
        d = self.bb.defn.pin(name)
        return self.bb.x + d.dx, self.bb.y + d.dy

    def seat(self, type_, holes: dict, **params):
        """Place a part so that its pins sit exactly in the named holes ({pin: hole})."""
        d = parts.get(type_)
        (p0, h0) = next(iter(holes.items()))
        hx, hy = self.hole(h0)
        pin0 = d.pin(p0)
        c = self.p.add_component(type_, hx - pin0.dx, hy - pin0.dy, params=params)
        for pn, hn in holes.items():
            px, py = self.hole(hn)
            pd = d.pin(pn)
            assert (c.x + pd.dx, c.y + pd.dy) == (px, py), f"{type_}.{pn} does not land on {hn}"
        return c

    def place(self, type_, x, y, **params):
        return self.p.add_component(type_, x, y, params=params)

    def wire(self, a, b):
        def end(s):
            if s.startswith("BB."):
                return (self.bb.id, s[3:])
            ref, pin = s.split(".", 1)
            return (self.p.by_ref(ref).id, pin)
        self.p.add_wire(end(a), end(b))

    def jumper(self, a, b, color=""):
        self.wire(a, b)
        if color:
            self.p.wires[-1].color = color


def ex(key, group, title, sim, objective, theory="", steps=(), questions=(), limits=LIMIT_BB):
    def deco(fn):
        build, check = fn()
        EXAMPLES[key] = Example(key, group, title, build, dict(sim), objective, theory, list(steps), list(questions), limits, check)
        return fn
    return deco


def _c(name, ok, detail=""):
    return Check(name, bool(ok), detail)


def _row(res, ref):
    return next((r for r in res.table if r.get("ref") == ref), None)


def _led_row(b, uno_pin, col, label="", row_led="a"):
    """Arduino pin -> 220 Ω resistor (row e, cols col..col+4) -> LED (row a, A on col+4) -> GND rail via a jumper on the LED cathode column."""
    r = b.seat("resistor", {"1": f"e{col}", "2": f"e{col + 4}"}, R=220.0)
    d = b.seat("led", {"A": f"{row_led}{col + 4}", "K": f"{row_led}{col + 3}"})
    b.jumper(uno_pin, f"BB.e{col}", "#f2c200")
    b.jumper(f"BB.b{col + 3}", "BB.tn%d" % (col + 3), "#2b2b2b")
    return r, d


def _gnd_rail(b):
    b.jumper("UNO1.GND", "BB.tn1", "#2b2b2b")


def _scope(b, ch1, ch2=None, x=48, y=32):
    """Oscilloscope below the breadboard: CH1 / CH2 probe the given holes, GND clip on the ground rail."""
    b.place("scope", x, y)
    b.jumper("OSC1.CH1", ch1, "#e0b100")
    if ch2:
        b.jumper("OSC1.CH2", ch2, "#1d78d6")
    b.jumper("OSC1.GND", "BB.tn24", "#2b2b2b")


# ------------------------------------------------------------------------------------------------ Basic circuits
@ex("led_battery", "Basic circuits", "LED + resistor from a battery", {"analysis": "op"},
    "Light an LED from a 6 V battery with a current-limiting resistor and check the current.",
    "I = (Vsupply − Vf) / R. A red LED drops about 1.9 V at 10 mA, so a 330 Ω resistor from 6 V passes about 12 mA.",
    ["Press ▶ Start Simulation: the LED glows.", "Click the resistor and change R (try 1 kΩ, then 100 Ω) and run again.", "Pull the LED out of its holes (drag it) to open the circuit."],
    ["What happens to the current if you halve R?"])
def _led_battery():
    def build():
        b = Bench("LED + resistor")
        bat = b.place("vdc", 8, 8, V=6.0)
        g = b.place("ground", 8, 14)
        r = b.seat("resistor", {"1": "e8", "2": "e12"}, R=330.0)
        b.seat("led", {"A": "a12", "K": "a11"})
        b.jumper("V1.+", "BB.tp1", "#d62828")
        b.jumper("V1.−", "BB.tn1", "#2b2b2b")
        b.jumper("GND1.G", "BB.tn2", "#2b2b2b")
        b.jumper("BB.tp8", "BB.a8", "#d62828")
        b.jumper("BB.b11", "BB.tn11", "#2b2b2b")
        return b.p

    def check(prj, res):
        r, d = _row(res, "R1"), _row(res, "D1")
        if not r or not d:
            return [_c("Results found", False)]
        i, vf = r["I"], d["V"]
        return [_c("LED current ≈ (6 V − Vf)/330 Ω", abs(i - (6 - vf) / 330) < 0.01 * i, f"{i * 1e3:.2f} mA"),
                _c("LED forward voltage 1.7–2.1 V", 1.7 < vf < 2.1, f"{vf:.2f} V")]
    return build, check


@ex("divider_dmm", "Basic circuits", "Voltage divider + multimeter", {"analysis": "op"},
    "Build a 9 V divider of 1 kΩ and 2 kΩ and measure the middle node with the multimeter.",
    "Vout = Vin · R2/(R1+R2) = 9 · 2/3 = 6 V. The meter has a very high input resistance, so it hardly loads the divider.",
    ["Press ▶ Start Simulation: the multimeter shows the voltage between its V and COM probes.", "Change R2 to 1 kΩ: the reading drops to 4.5 V."],
    ["Why does a low-resistance meter read lower?"])
def _divider():
    def build():
        b = Bench("Divider + DMM")
        b.place("vdc", 8, 6, V=9.0)
        b.place("ground", 8, 12)
        b.seat("resistor", {"1": "e6", "2": "e10"}, R=1000.0)
        b.seat("resistor", {"1": "a10", "2": "a14"}, R=2000.0)
        b.jumper("V1.+", "BB.tp1", "#d62828"); b.jumper("V1.−", "BB.tn1", "#2b2b2b"); b.jumper("GND1.G", "BB.tn2", "#2b2b2b")
        b.jumper("BB.tp6", "BB.a6", "#d62828"); b.jumper("BB.b14", "BB.tn14", "#2b2b2b")
        b.place("dmm", 12, 26)
        b.jumper("DMM1.V", "BB.d10", "#d62828"); b.jumper("DMM1.COM", "BB.tn20", "#2b2b2b")
        return b.p

    def check(prj, res):
        r = res.instruments.get("DMM1")
        if not r:
            return [_c("Multimeter reading present", False)]
        return [_c("Reading ≈ 6.000 V", abs(r["value"] - 6.0) < 0.05, f"{r['value']:.3f} V")]
    return build, check


@ex("rc_charge", "Basic circuits", "RC charging (waveform)", {"analysis": "transient", "tstop": 0.05, "points": 2000, "uic": True},
    "Charge a 100 µF capacitor through 220 Ω from a 5 V battery and watch the exponential rise on the Waveforms tab.",
    "τ = R·C = 220 Ω · 100 µF = 22 ms. After 1 τ the capacitor is at 63 %; after 5 τ it is at 99 %.",
    ["Press ▶ Start Simulation and open the Waveforms tab.", "Double R: the curve takes twice as long."],
    ["Where on the curve is the capacitor at t = τ?"])
def _rc():
    def build():
        b = Bench("RC charging")
        b.place("vdc", 8, 6, V=5.0)
        b.place("ground", 8, 12)
        b.seat("resistor", {"1": "e8", "2": "e12"}, R=220.0)
        b.seat("capacitor", {"+": "a12", "−": "a14"}, C=100e-6)
        b.jumper("V1.+", "BB.tp1", "#d62828"); b.jumper("V1.−", "BB.tn1", "#2b2b2b"); b.jumper("GND1.G", "BB.tn2", "#2b2b2b")
        b.jumper("BB.tp8", "BB.a8", "#d62828"); b.jumper("BB.b14", "BB.tn14", "#2b2b2b")
        _scope(b, "BB.c12", "BB.c8")
        return b.p

    def check(prj, res):
        row = _row(res, "C1")
        sig = [k for k in res.signals if "C1" in k]
        return [_c("Waveforms recorded", bool(res.signals), f"{len(res.signals)} signals")]
    return build, check


# ------------------------------------------------------------------------------------------------ Arduino + LEDs
@ex("blink", "Arduino + LEDs", "Blink", {"analysis": "transient", "tstop": 3.0, "points": 3000},
    "Blink an LED on pin 13 through a 220 Ω resistor.",
    "digitalWrite(13, HIGH) puts 5 V on the pin (through its 25 Ω output resistance). With 220 Ω and a red LED the current is about 12 mA.",
    ["Press ▶ Start Simulation: the LED blinks once a second on the canvas.", "Open the Sketch editor tab and change the delay() values."],
    ["How would you blink at 5 Hz?"], LIMIT_BB + " " + LIMIT_MCU)
def _blink():
    def build():
        b = Bench("Blink", uno=True, code=sk.BLINK)
        _led_row(b, "UNO1.D13", 6)
        _gnd_rail(b)
        _scope(b, "BB.c6", "BB.c10")
        return b.p

    def check(prj, res):
        d = _row(res, "D1")
        sig = res.signals.get("I(D1)")
        ok = sig is not None and sig.y.max() > 5e-3 and sig.y.min() < 1e-4
        return [_c("LED current switches between ≈0 and ≈12 mA", ok)]
    return build, check


@ex("button", "Arduino + LEDs", "Push button controls an LED", {"analysis": "transient", "tstop": 4.5, "points": 4500},
    "Read a push button on pin 2 with digitalRead() and light an LED on pin 8, with a software debounce.",
    "The button pulls pin 2 up to 5 V through the Arduino 5V pin when pressed; a 10 kΩ pull-down resistor keeps it at 0 V otherwise.",
    ["Click the button and set its press pattern (default 0110, 1 s steps).", "Press ▶ Start Simulation: the LED follows the pressed intervals."],
    ["Why do we debounce?"], LIMIT_BB + " " + LIMIT_MCU)
def _button():
    def build():
        b = Bench("Button + LED", uno=True, code=sk.BUTTON)
        _led_row(b, "UNO1.D8", 6)
        b.seat("pushbutton", {"1": "e18", "2": "e20", "3": "f18", "4": "f20"}, pattern="0110", step=1.0)
        b.seat("resistor", {"1": "a20", "2": "a24"}, R=10000.0)
        b.jumper("UNO1.5V", "BB.j18", "#d62828")                   # 5 V -> the bottom pair of button pins
        b.jumper("UNO1.D2", "BB.c20", "#2a9d3a")
        b.jumper("BB.b24", "BB.tn24", "#2b2b2b")
        _gnd_rail(b)
        _scope(b, "BB.d20", "BB.c10")
        return b.p

    def check(prj, res):
        sig = res.signals.get("I(D1)")
        if sig is None:
            return [_c("LED current recorded", False)]
        import numpy as np
        at = lambda t: float(np.interp(t, sig.x, sig.y))
        return [_c("LED off before the press (0.5 s)", at(0.5) < 1e-4), _c("LED on while pressed (1.5 s, 2.5 s)", at(1.5) > 5e-3 and at(2.5) > 5e-3),
                _c("LED off after release (3.5 s)", at(3.5) < 1e-4)]
    return build, check


@ex("traffic", "Arduino + LEDs", "Traffic light", {"analysis": "transient", "tstop": 6.0, "points": 6000},
    "Three LEDs on pins 2, 3 and 4 run a red–green–yellow sequence.",
    "Each LED has its own 220 Ω resistor. The sketch calls light(r, y, g) to switch the three pins together.",
    ["Press ▶ Start Simulation and watch the three LEDs.", "Change the delay() times in the sketch."],
    ["How long is one full cycle?"], LIMIT_BB + " " + LIMIT_MCU)
def _traffic():
    def build():
        b = Bench("Traffic light", uno=True, code=sk.TRAFFIC)
        _led_row(b, "UNO1.D2", 5)
        _led_row(b, "UNO1.D3", 12)
        _led_row(b, "UNO1.D4", 19)
        b.p.by_ref("D1").params["color"] = "red"; b.p.by_ref("D2").params["color"] = "yellow"; b.p.by_ref("D3").params["color"] = "green"
        _gnd_rail(b)
        _scope(b, "BB.c5", "BB.c12")
        return b.p

    def check(prj, res):
        s = [res.signals.get(f"I(D{i})") for i in (1, 2, 3)]
        return [_c("All three LEDs light at some point", all(x is not None and x.y.max() > 5e-3 for x in s))]
    return build, check


@ex("pwm_led", "Arduino + LEDs", "PWM dimmer", {"analysis": "transient", "tstop": 0.1, "points": 5000},
    "Dim an LED with analogWrite(): 25 % duty at 490 Hz on pin 9.",
    "The LED is switched on for 25 % of every 2 ms period, so its average current is a quarter of the full value.",
    ["Press ▶ Start Simulation and look at the LED current on the Waveforms tab.", "Change 64 to 192 for 75 %."],
    ["What is the average current at 25 % duty?"], LIMIT_BB + " " + LIMIT_MCU)
def _pwm():
    def build():
        b = Bench("PWM dimmer", uno=True, code=PWM_LED)
        _led_row(b, "UNO1.D9", 6)
        _gnd_rail(b)
        _scope(b, "BB.c6", "BB.c10")
        return b.p

    def check(prj, res):
        sig = res.signals.get("I(D1)")
        return [_c("PWM current pulses present", sig is not None and sig.y.max() > 5e-3)]
    return build, check


# ------------------------------------------------------------------------------------------------ Arduino + sound
@ex("buzzer_active", "Arduino + sound", "Beeping active buzzer", {"analysis": "transient", "tstop": 3.0, "points": 6000},
    "An active buzzer on pin 8 beeps 200 ms every half second — you hear it through the computer speaker.",
    "An active buzzer has its own oscillator: it sounds a fixed ≈2.3 kHz tone whenever the supply across it is high.",
    ["Press ▶ Start Simulation (sound must be on: speaker button in the toolbar).", "Change the delay() values to change the rhythm."],
    ["Why can't an active buzzer play different notes?"], LIMIT_BB + " " + LIMIT_MCU)
def _buz_a():
    def build():
        b = Bench("Active buzzer", uno=True, code=BUZZ_ACTIVE)
        b.seat("buzzer", {"+": "e10", "−": "e13"}, kind="active")
        b.jumper("UNO1.D8", "BB.a10", "#f2c200")
        b.jumper("BB.a13", "BB.tn13", "#2b2b2b")
        _gnd_rail(b)
        _scope(b, "BB.c10")
        return b.p

    def check(prj, res):
        bz = res.info.get("buzzers") or []
        return [_c("Buzzer drive recorded", bool(bz))]
    return build, check


@ex("buzzer_melody", "Arduino + sound", "Passive buzzer melody", {"analysis": "transient", "tstop": 3.5, "points": 20000},
    "Play a C-major scale on a passive buzzer with tone(). The notes come out of the computer speaker.",
    "tone(pin, f) toggles the pin at f Hz. A passive buzzer has no oscillator, so it sounds exactly the waveform you drive it with.",
    ["Press ▶ Start Simulation (sound on).", "Change the notes[] array to play a different tune."],
    ["Which note has a frequency of 440 Hz?"], LIMIT_BB + " " + LIMIT_MCU)
def _buz_p():
    def build():
        b = Bench("Passive buzzer melody", uno=True, code=BUZZ_PASSIVE)
        b.seat("buzzer", {"+": "e10", "−": "e13"}, kind="passive")
        b.jumper("UNO1.D8", "BB.a10", "#f2c200")
        b.jumper("BB.a13", "BB.tn13", "#2b2b2b")
        _gnd_rail(b)
        _scope(b, "BB.c10")
        return b.p

    def check(prj, res):
        from . import audio
        bz = res.info.get("buzzers") or []
        if not bz:
            return [_c("Buzzer drive recorded", False)]
        s = audio.synth_buzzer(bz[0])
        return [_c("Audio contains a tone", bool(s.size and abs(s).max() > 0.05))]
    return build, check


# ------------------------------------------------------------------------------------------------ Arduino + sensors
@ex("pot_dvm", "Arduino + sensors", "Potentiometer voltmeter", {"analysis": "transient", "tstop": 2.0, "points": 2000},
    "Read a potentiometer with analogRead(A0) and print the voltage on the Serial monitor.",
    "The 10-bit ADC gives 0–1023 for 0–5 V. With the wiper at 50 % the reading is about 512 (2.5 V).",
    ["Press ▶ Start Simulation and open the Serial tab.", "Click the potentiometer and change its wiper position, then run again."],
    ["What reading do you expect with the wiper at the 5 V end?"], LIMIT_BB + " " + LIMIT_MCU)
def _pot():
    def build():
        b = Bench("Potentiometer voltmeter", uno=True, code=DVM_POT)
        b.seat("pot", {"1": "e10", "W": "e11", "2": "e12"}, R=10000.0, pos=0.5)
        b.jumper("UNO1.5V", "BB.a10", "#d62828")
        b.jumper("BB.a12", "BB.tn12", "#2b2b2b")
        b.jumper("UNO1.A0", "BB.b11", "#2a9d3a")
        _gnd_rail(b)
        return b.p

    def check(prj, res):
        txt = res.info.get("serial_text", "")
        return [_c("Serial output present", "A0 =" in txt), _c("Reading near 512 once settled", any(f"A0 = {n}" in txt for n in range(505, 520)), txt.replace(chr(10), " | ")[:60])]
    return build, check


# ------------------------------------------------------------------------------------------------ ICs and chips
RED, BLK, YEL, BLU = "#d62828", "#2b2b2b", "#f2c200", "#1d78d6"
LIMIT_IC = ("Behavioural IC models (see KNOWN_LIMITATIONS): no propagation delay, slew rate or bandwidth limits; breadboard contacts are ideal. "
            "Part numbers and pinouts are not independently datasheet-checked.")


def _power(b, v=5.0, x=8, y=8):
    """Battery + ground part wired to the breadboard rails: tp = +V, tn/bn = 0 V (bp is joined to tp, bn to tn)."""
    b.place("vdc", x, y, V=v)
    b.place("ground", x, y + 6)
    b.jumper("V1.+", "BB.tp1", RED); b.jumper("V1.−", "BB.tn1", BLK); b.jumper("GND1.G", "BB.tn2", BLK)
    b.jumper("BB.tp2", "BB.bp2", RED); b.jumper("BB.tn3", "BB.bn3", BLK)


@ex("ne555_blinker", "ICs and chips", "NE555 astable LED flasher", {"analysis": "transient", "tstop": 3.0, "points": 12000, "uic": True},
    "A 555 timer flashes an LED about 1.5 times a second. R1, R2 and C set the speed.",
    "Astable 555: f = 1.44 / ((R1 + 2·R2)·C). With R1 = 1 kΩ, R2 = 47 kΩ and C = 10 µF: f ≈ 1.5 Hz, duty cycle (R1+R2)/(R1+2R2) ≈ 51 %. "
    "The capacitor charges to 2/3 VCC through R1+R2 and discharges to 1/3 VCC through R2 into the DIS pin.",
    ["Press ▶ Start Simulation: the LED on the canvas flashes.", "Click the 10 µF capacitor and change it to 1 µF: the LED flashes ten times faster.",
     "Open Waveforms and compare the capacitor voltage with the output."],
    ["What happens to the duty cycle if R1 is made much smaller than R2?"], LIMIT_BB + " " + LIMIT_IC)
def _ne555():
    def build():
        b = Bench("NE555 flasher")
        _power(b, 5.0)
        b.seat("ne555", {"GND": "f10", "TRIG": "f11", "OUT": "f12", "RESET": "f13", "CTRL": "e13", "THR": "e12", "DIS": "e11", "VCC": "e10"})
        b.jumper("BB.a10", "BB.tp10", RED); b.jumper("BB.j10", "BB.bn10", BLK); b.jumper("BB.j13", "BB.bp13", RED)
        b.seat("resistor", {"1": "a16", "2": "a20"}, R=1e3)                       # R1: VCC -> DIS
        b.jumper("BB.b16", "BB.tp16", RED); b.jumper("BB.b20", "BB.b11", YEL)
        b.seat("resistor", {"1": "a22", "2": "a26"}, R=47e3)                      # R2: DIS -> THR
        b.jumper("BB.b22", "BB.c11", YEL); b.jumper("BB.b26", "BB.c12", YEL)
        b.jumper("BB.g11", "BB.d12", BLU)                                           # TRIG tied to THR
        b.seat("capacitor", {"+": "h18", "−": "h20"}, C=10e-6)                    # timing capacitor
        b.jumper("BB.g18", "BB.d12", BLU); b.jumper("BB.j20", "BB.bn20", BLK)
        b.jumper("BB.g12", "BB.g24", "#2a9d3a")                                     # OUT -> LED branch
        b.seat("resistor", {"1": "i24", "2": "i28"}, R=330.0)
        b.seat("led", {"A": "g28", "K": "g27"})
        b.jumper("BB.j27", "BB.bn24", BLK)
        _scope(b, "BB.h12", "BB.i18")
        return b.p

    def check(prj, res):
        led = res.signals.get("I(D1)")
        if led is None:
            return [_c("LED current recorded", False)]
        on = led.y > 2e-3
        rises = led.x[1:][on[1:] & ~on[:-1]]
        edges = len(rises)
        per = float((rises[-1] - rises[0]) / (len(rises) - 1)) if edges > 2 else 0.0
        f_expected = 1.44 / ((1e3 + 2 * 47e3) * 10e-6)
        return [_c("LED flashes at least 3 times in 3 s", edges >= 3, f"{edges} flashes"),
                _c("Frequency ≈ 1.44 / ((R1 + 2·R2)·C) within 8 %", per > 0 and abs(1 / per - f_expected) < 0.08 * f_expected,
                   f"{(1 / per if per else 0):.2f} Hz vs {f_expected:.2f} Hz")]
    return build, check


@ex("nand_gate", "ICs and chips", "74HC00 NAND gate with switches", {"analysis": "op"},
    "Two toggle switches feed a NAND gate; an LED shows the output. Flip the switches (Properties → Closed) and run again to fill the truth table.",
    "Y = NOT (A AND B). The output is low only when both inputs are high. Pull-down resistors keep an open switch at logic 0; "
    "unused gate inputs are best tied to a fixed level in a real circuit.",
    ["Press ▶ Start Simulation: A = 1 (switch closed), B = 0 (open), so Y = 1 and the LED is lit.", "Click SW2 and tick Closed, run again: both inputs high, Y = 0, LED off.",
     "Try the other two combinations and write down the truth table."],
    ["Which single gate inputs combination switches the LED off?"], LIMIT_BB + " " + LIMIT_IC)
def _nand():
    def build():
        b = Bench("NAND gate")
        _power(b, 5.0)
        b.seat("ic74hc00", {"1A": "f5", "1B": "f6", "1Y": "f7", "2A": "f8", "2B": "f9", "2Y": "f10", "GND": "f11",
                            "3Y": "e11", "3A": "e10", "3B": "e9", "4Y": "e8", "4A": "e7", "4B": "e6", "VCC": "e5"})
        b.jumper("BB.a5", "BB.tp5", RED); b.jumper("BB.j11", "BB.bn11", BLK)
        # input A: SW1 from +V, 10 k pull-down
        b.seat("switch", {"1": "a15", "2": "a17"}, closed=True)
        b.jumper("BB.b15", "BB.tp15", RED); b.jumper("BB.b17", "BB.g5", YEL)
        b.seat("resistor", {"1": "a19", "2": "a23"}, R=10e3)
        b.jumper("BB.b19", "BB.c17", YEL); b.jumper("BB.b23", "BB.tn23", BLK)
        # input B
        b.seat("switch", {"1": "i15", "2": "i17"}, closed=False)
        b.jumper("BB.j15", "BB.bp15", RED); b.jumper("BB.h17", "BB.g6", YEL)
        b.seat("resistor", {"1": "i19", "2": "i23"}, R=10e3)
        b.jumper("BB.h19", "BB.g17", YEL); b.jumper("BB.h23", "BB.bn23", BLK)
        # output LED
        b.jumper("BB.h7", "BB.h25", "#2a9d3a")
        b.seat("resistor", {"1": "i25", "2": "i29"}, R=330.0)
        b.seat("led", {"A": "g29", "K": "g28"})
        b.jumper("BB.j28", "BB.bn25", BLK)
        return b.p

    def check(prj, res):
        d = _row(res, "D1")
        return [_c("A = 1, B = 0  →  Y = 1: LED lit (> 5 mA)", d is not None and d["I"] > 5e-3, f"{(d['I'] * 1e3 if d else 0):.1f} mA")]
    return build, check


@ex("reg7805", "ICs and chips", "7805 voltage regulator", {"analysis": "op"},
    "Turn a 9 V battery into a steady 5 V rail and read it with the multimeter.",
    "A 78xx regulator keeps its output at 5 V as long as the input is at least about 2 V higher (dropout). The 220 Ω load draws about 23 mA.",
    ["Press ▶ Start Simulation: the multimeter reads 5.00 V.", "Click the battery and set it to 6 V: the output follows the input down (dropout).",
     "Set it to 15 V: the output stays at 5 V."],
    ["Why does a linear regulator get hot when Vin is much larger than Vout?"], LIMIT_BB + " " + LIMIT_IC)
def _reg():
    def build():
        b = Bench("7805 regulator")
        b.place("vdc", 8, 8, V=9.0); b.place("ground", 8, 14)
        b.jumper("V1.−", "BB.tn1", BLK); b.jumper("GND1.G", "BB.tn2", BLK)
        b.seat("7805", {"IN": "a10", "GND": "a11", "OUT": "a12"})
        b.jumper("V1.+", "BB.b10", RED); b.jumper("BB.b11", "BB.tn11", BLK)
        b.seat("resistor", {"1": "c12", "2": "c16"}, R=220.0)
        b.jumper("BB.d16", "BB.tn16", BLK)
        b.place("dmm", 12, 26)
        b.jumper("DMM1.V", "BB.e12", RED); b.jumper("DMM1.COM", "BB.tn20", BLK)
        return b.p

    def check(prj, res):
        r = res.instruments.get("DMM1")
        if not r:
            return [_c("Multimeter reading present", False)]
        return [_c("Output = 5.00 V ± 0.05 V", abs(r["value"] - 5.0) < 0.05, f"{r['value']:.3f} V")]
    return build, check


@ex("lm358_amp", "ICs and chips", "LM358 non-inverting amplifier", {"analysis": "op"},
    "Amplify a potentiometer voltage by 2 with an op-amp and read the result. Turn the pot up to see the output clip below the supply rail.",
    "Non-inverting gain = 1 + R2/R1 = 2. The LM358 output can swing only to about VCC − 1.5 V, so with a 5 V supply it clips at about 3.5 V.",
    ["Press ▶ Start Simulation: with the pot at 20 % (1.0 V) the meter reads 2.00 V.", "Click the potentiometer and set Wiper position to 0.5 (2.5 V in): the output clips near 3.5 V instead of 5 V.",
     "Change R2 to 20 kΩ to get a gain of 3."],
    ["Why is the output not 5.0 V when the gain says it should be?"], LIMIT_BB + " " + LIMIT_IC)
def _lm358():
    def build():
        b = Bench("LM358 amplifier")
        _power(b, 5.0)
        b.seat("lm358", {"OUT1": "f10", "IN1N": "f11", "IN1P": "f12", "GND": "f13", "IN2P": "e13", "IN2N": "e12", "OUT2": "e11", "VCC": "e10"})
        b.jumper("BB.a10", "BB.tp10", RED); b.jumper("BB.j13", "BB.bn13", BLK)
        b.jumper("BB.d11", "BB.d12", YEL); b.jumper("BB.c13", "BB.tn13", BLK)                  # park the unused op-amp: follower of 0 V
        b.seat("resistor", {"1": "j10", "2": "j14"}, R=10e3)                                    # R2 feedback: OUT1 -> IN1N
        b.jumper("BB.i14", "BB.i11", YEL)
        b.seat("resistor", {"1": "h11", "2": "h15"}, R=10e3)                                    # R1: IN1N -> ground
        b.jumper("BB.g15", "BB.bn15", BLK)
        b.seat("pot", {"1": "a20", "W": "a21", "2": "a22"}, pos=0.2)
        b.jumper("BB.b20", "BB.tn20", BLK); b.jumper("BB.b22", "BB.tp22", RED); b.jumper("BB.b21", "BB.g12", YEL)
        b.place("dmm", 12, 26)
        b.jumper("DMM1.V", "BB.i10", RED); b.jumper("DMM1.COM", "BB.bn18", BLK)
        return b.p

    def check(prj, res):
        r = res.instruments.get("DMM1")
        if not r:
            return [_c("Multimeter reading present", False)]
        return [_c("Output = 2 × 1.00 V = 2.00 V", abs(r["value"] - 2.0) < 0.03, f"{r['value']:.3f} V")]
    return build, check


@ex("ne555_tone", "ICs and chips", "NE555 tone generator + speaker", {"analysis": "transient", "tstop": 0.4, "points": 16000, "uic": True},
    "A 555 oscillating at about 900 Hz drives a loudspeaker through a coupling capacitor: you hear the tone through the computer speaker after the run.",
    "f = 1.44 / ((R1 + 2·R2)·C) = 1.44 / ((1 kΩ + 15 kΩ) · 100 nF) = 900 Hz. The 10 µF capacitor blocks the DC level so only the audio swing reaches the 8 Ω speaker.",
    ["Press ▶ Start Simulation: after the run you hear the tone (M mutes).", "Change R2 to 15 kΩ: the pitch drops to about 500 Hz.", "Swap the speaker for an LED + resistor and slow the oscillator to see the flashes instead."],
    limits=LIMIT_BB + " " + LIMIT_IC + " Audio is the simulated voltage across the speaker resampled to 22 kHz (max 12 s).")
def _tone():
    def build():
        b = Bench("555 tone")
        _power(b, 5.0)
        b.seat("ne555", {"GND": "f10", "TRIG": "f11", "OUT": "f12", "RESET": "f13", "CTRL": "e13", "THR": "e12", "DIS": "e11", "VCC": "e10"})
        b.jumper("BB.a10", "BB.tp10", RED); b.jumper("BB.j10", "BB.bn10", BLK); b.jumper("BB.j13", "BB.bp13", RED)
        b.seat("resistor", {"1": "a16", "2": "a20"}, R=1e3)
        b.jumper("BB.b16", "BB.tp16", RED); b.jumper("BB.b20", "BB.b11", YEL)
        b.seat("resistor", {"1": "a22", "2": "a26"}, R=7.5e3)
        b.jumper("BB.b22", "BB.c11", YEL); b.jumper("BB.b26", "BB.c12", YEL)
        b.jumper("BB.g11", "BB.d12", BLU)
        b.seat("capacitor_ceramic", {"+": "h18", "−": "h19"}, C=100e-9)
        b.jumper("BB.g18", "BB.d12", BLU); b.jumper("BB.j19", "BB.bn19", BLK)
        b.jumper("BB.g12", "BB.g22", "#2a9d3a")
        b.seat("capacitor", {"+": "i22", "−": "i24"}, C=10e-6)
        b.seat("speaker", {"+": "g24", "−": "g27"})
        b.jumper("BB.j27", "BB.bn24", BLK)
        _scope(b, "BB.h12", "BB.j24")
        return b.p

    def check(prj, res):
        from . import audio
        bz = res.info.get("buzzers") or []
        if not bz:
            return [_c("Speaker output recorded", False)]
        f = audio.dominant_frequency(audio.mix(bz))
        return [_c("Tone ≈ 1.44 / ((R1 + 2·R2)·C) = 900 Hz within 8 %", abs(f - 900) < 72, f"{f:.0f} Hz")]
    return build, check


BY_KEY = EXAMPLES


def grouped():
    out = {g: [] for g in GROUPS}
    for e in EXAMPLES.values():
        out[e.group].append(e)
    return out


from . import labs  # noqa: E402,F401  (lab-wise experiments register themselves)
