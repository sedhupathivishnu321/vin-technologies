"""Lab-wise experiments (registered into ecelab.examples at import time)."""
from .. import examples as _ex

for _g in ("Basic Electrical Lab", "Electronic Devices Lab", "Analog Circuits Lab", "Digital Systems Lab", "Microcontroller Lab", "Logic Gates from Components"):
    if _g not in _ex.GROUPS:
        _ex.GROUPS.append(_g)

from . import basic, devices, analog_lab, digital_lab, mcu_lab, logic_lab  # noqa: E402,F401

from ..net import examples as _nx  # noqa: E402

if "Computer Networks Lab" not in _nx.GROUPS:
    _nx.GROUPS.append("Computer Networks Lab")
from . import net_lab  # noqa: E402,F401
