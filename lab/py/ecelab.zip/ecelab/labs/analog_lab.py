"""Analog Circuits Laboratory: op-amp circuits, filters, transistor amplifiers, 555 timer, rectifiers, converters."""
from __future__ import annotations
import math
import numpy as np

from .core import Lab, lab, _c, run_analog, pin_voltage

G = "Analog Circuits Lab"


def tvec(res):
    return next(iter(res.signals.values())).x


def amp(y):
    return float((np.max(y) - np.min(y)) / 2)


def op_gain_ac(res, num, den):
    return np.abs(pin_voltage(res, num)) / np.maximum(np.abs(pin_voltage(res, den)), 1e-30)


def freqs(res):
    return np.asarray(res.info["f"])


# ---------------------------------------------------------------------------------------------------------------- op-amp amplifiers
@lab("ac_inverting", G, "Inverting amplifier (op-amp)", {"analysis": "op"},
     "Build a −10 amplifier with an op-amp and verify Vout = −(Rf/Ri)·Vin.",
     "The virtual short keeps the inverting input at 0 V, so Iin = Vin/Ri flows through Rf: Vout = −(Rf/Ri)·Vin = −10 × 0.5 V = −5 V. Input resistance equals Ri.",
     ["Run and read the output voltage.", "Change Rf to 20 kΩ: the gain doubles.", "Raise Vin to 2 V: the output saturates near −13 V."], ["Why is the inverting input called a virtual ground?"])
def _inv():
    def build(vin=0.5):
        L = Lab("Inverting amplifier")
        v = L.add("vdc", V=vin); ri = L.add("resistor", R=1000.0); rf = L.add("resistor", R=10000.0); u = L.add("opamp")
        L.chain(f"{v}.+", f"{ri}.1", f"{ri}.2", f"{u}.−"); L.wire(f"{u}.−", f"{rf}.1"); L.wire(f"{rf}.2", f"{u}.OUT"); L.wire(f"{u}.+", f"{v}.−")
        L.gnd(f"{v}.−")
        return L.finish()

    def check(prj, res):
        vo = pin_voltage(res, "U1.OUT")
        sat = pin_voltage(run_analog(build(2.0), analysis="op"), "U1.OUT")
        return [_c("Vout = −Rf/Ri · Vin = −5 V (±1 %)", abs(vo + 5.0) < 0.05, f"{vo:.3f} V"), _c("2 V input saturates near −13 V", -13.5 < sat < -12.0, f"{sat:.2f} V")]
    return build, check


@lab("ac_noninverting", G, "Non-inverting amplifier (op-amp)", {"analysis": "op"},
     "Build a ×11 amplifier and verify Vout = (1 + Rf/Rg)·Vin.",
     "The feedback divider Rg–Rf makes the inverting input follow Vin, so Vout = (1 + Rf/Rg)·Vin = 11 × 0.5 V = 5.5 V. Input resistance is very high.",
     ["Run and read the output.", "Short Rf (R = 1 Ω): the circuit becomes a voltage follower with gain 1."], ["What is the gain of a voltage follower?"])
def _noninv():
    def build():
        L = Lab("Non-inverting amplifier")
        v = L.add("vdc", V=0.5); rg = L.add("resistor", R=1000.0); rf = L.add("resistor", R=10000.0); u = L.add("opamp")
        L.chain(f"{v}.+", f"{u}.+"); L.wire(f"{u}.−", f"{rg}.1", f"{rf}.1"); L.wire(f"{rf}.2", f"{u}.OUT"); L.wire(f"{rg}.2", f"{v}.−")
        L.gnd(f"{v}.−")
        return L.finish()

    def check(prj, res):
        vo = pin_voltage(res, "U1.OUT")
        return [_c("Vout = (1 + Rf/Rg)·Vin = 5.5 V (±1 %)", abs(vo - 5.5) < 0.055, f"{vo:.3f} V")]
    return build, check


@lab("ac_summing", G, "Summing amplifier", {"analysis": "op"},
     "Add three input voltages with an inverting summer: Vout = −Rf·(V1/R1 + V2/R2 + V3/R3).",
     "All inputs feed the virtual-ground node, so the currents add: Vout = −10 k·(1 V/10 k + 2 V/10 k + 0.5 V/5 k) = −4 V.",
     ["Run and read Vout.", "Change one input and check the change in Vout equals −(Rf/R)·ΔV."], ["How would you give input 2 twice the weight?"])
def _sum():
    def build():
        L = Lab("Summing amplifier")
        v = [L.add("vdc", V=x) for x in (1.0, 2.0, 0.5)]; r = [L.add("resistor", R=x) for x in (10000.0, 10000.0, 5000.0)]; rf = L.add("resistor", R=10000.0); u = L.add("opamp")
        for vi, ri in zip(v, r):
            L.chain(f"{vi}.+", f"{ri}.1"); L.wire(f"{ri}.2", f"{u}.−")
        L.wire(f"{u}.−", f"{rf}.1"); L.wire(f"{rf}.2", f"{u}.OUT"); L.wire(f"{u}.+", f"{v[0]}.−")
        L.gnd(f"{v[0]}.−", f"{v[1]}.−", f"{v[2]}.−")
        return L.finish()

    def check(prj, res):
        vo = pin_voltage(res, "U1.OUT")
        return [_c("Vout = −(1 + 2 + 1) = −4 V (±1 %)", abs(vo + 4.0) < 0.04, f"{vo:.3f} V")]
    return build, check


@lab("ac_difference", G, "Subtractor (difference amplifier)", {"analysis": "op"},
     "Subtract two voltages: Vout = (Rf/R1)·(V2 − V1).",
     "With matched resistors R1 = R3 = 10 kΩ and Rf = R4 = 20 kΩ the output is 2·(V2 − V1) = 2·(2 V − 1 V) = 2 V, and a common-mode signal is rejected.",
     ["Run and read Vout.", "Add the same offset to both inputs: Vout does not change."], ["What limits the common-mode rejection in practice?"])
def _diff():
    def build(v1=1.0, v2=2.0):
        L = Lab("Difference amplifier")
        a = L.add("vdc", V=v1); b = L.add("vdc", V=v2); r1 = L.add("resistor", R=10000.0); rf = L.add("resistor", R=20000.0); r3 = L.add("resistor", R=10000.0); r4 = L.add("resistor", R=20000.0); u = L.add("opamp")
        L.chain(f"{a}.+", f"{r1}.1", f"{r1}.2", f"{u}.−"); L.wire(f"{u}.−", f"{rf}.1"); L.wire(f"{rf}.2", f"{u}.OUT")
        L.chain(f"{b}.+", f"{r3}.1", f"{r3}.2", f"{u}.+"); L.wire(f"{u}.+", f"{r4}.1"); L.wire(f"{r4}.2", f"{a}.−", f"{b}.−")
        L.gnd(f"{a}.−")
        return L.finish()

    def check(prj, res):
        vo = pin_voltage(res, "U1.OUT"); cm = pin_voltage(run_analog(build(3.0, 4.0), analysis="op"), "U1.OUT")
        return [_c("Vout = 2·(V2 − V1) = 2 V", abs(vo - 2.0) < 0.02, f"{vo:.3f} V"), _c("Common-mode shift of +2 V does not change Vout", abs(cm - vo) < 0.01, f"{cm:.3f} V")]
    return build, check


@lab("ac_inamp", G, "Instrumentation amplifier (three op-amps)", {"analysis": "op"},
     "Amplify a small differential voltage with a three-op-amp instrumentation amplifier and reject the common-mode level.",
     "Gain = (1 + 2R/Rg)·(R3/R2) = (1 + 2·10 k/1 k)·1 = 21. A 100 mV difference on a 2 V common-mode level gives 2.1 V while a pure common-mode input gives ≈ 0 V.",
     ["Run and read Vout.", "Change Rg to 2 kΩ: the gain falls to 11."], ["Why is the input resistance of an in-amp so high?"])
def _ina():
    def build(vd=0.1, vcm=2.0):
        L = Lab("Instrumentation amplifier")
        a = L.add("vdc", V=vcm + vd / 2); b = L.add("vdc", V=vcm - vd / 2)
        u1, u2, u3 = L.add("opamp"), L.add("opamp"), L.add("opamp")
        r1 = L.add("resistor", R=10000.0); r2 = L.add("resistor", R=10000.0); rg = L.add("resistor", R=1000.0)
        ra, rb, rc, rd = [L.add("resistor", R=10000.0) for _ in range(4)]
        L.chain(f"{a}.+", f"{u2}.+", f"{b}.+", f"{u1}.+")
        L.wire(f"{u1}.−", f"{r1}.1", f"{rg}.1"); L.wire(f"{r1}.2", f"{u1}.OUT", f"{ra}.1"); L.wire(f"{u2}.−", f"{r2}.1", f"{rg}.2"); L.wire(f"{r2}.2", f"{u2}.OUT", f"{rc}.1")
        L.wire(f"{ra}.2", f"{u3}.−", f"{rb}.1"); L.wire(f"{rb}.2", f"{u3}.OUT"); L.wire(f"{rc}.2", f"{u3}.+", f"{rd}.1")
        L.wire(f"{rd}.2", f"{a}.−", f"{b}.−")
        L.gnd(f"{a}.−")
        return L.finish()

    def check(prj, res):
        vo = pin_voltage(res, "U3.OUT"); cm = pin_voltage(run_analog(build(0.0, 2.0), analysis="op"), "U3.OUT")
        return [_c("Differential gain 21: 0.1 V → 2.1 V (±1 %)", abs(vo - 2.1) < 0.025, f"{vo:.3f} V"), _c("Pure common-mode 2 V rejected (|Vout| < 5 mV)", abs(cm) < 0.005, f"{cm * 1e3:.2f} mV")]
    return build, check


# ---------------------------------------------------------------------------------------------------------------- integrator / differentiator / comparators
@lab("ac_integrator", G, "Op-amp integrator", {"analysis": "transient", "tstop": 0.008, "points": 8000, "uic": True},
     "Integrate a ±1 V square wave into a triangle: Vout = −(1/RC)∫Vin dt.",
     "With R = 10 kΩ and C = 10 nF, 1/RC = 10 000 s⁻¹: during a 0.5 ms half-period a 1 V input ramps the output by 5 V. A 1 MΩ resistor across C limits the DC gain so the output does not drift.",
     ["Run and compare input (square) and output (triangle).", "Double the frequency: the triangle amplitude halves."], ["Why is the output inverted?"])
def _integ():
    def build():
        L = Lab("Integrator")
        v = L.add("vpulse", v1=-1.0, v2=1.0, freq=1000.0, duty=0.5, edge=0.002); r = L.add("resistor", R=10000.0); c = L.add("capacitor_ceramic", C=10e-9); rf = L.add("resistor", R=1e6); u = L.add("opamp")
        L.chain(f"{v}.+", f"{r}.1", f"{r}.2", f"{u}.−"); L.wire(f"{u}.−", f"{c}.+", f"{rf}.1"); L.wire(f"{c}.−", f"{rf}.2", f"{u}.OUT"); L.wire(f"{u}.+", f"{v}.−")
        L.gnd(f"{v}.−")
        L.scope(f"{v}.+", f"{u}.OUT")
        return L.finish()

    def check(prj, res):
        vo = pin_voltage(res, "U1.OUT"); t = tvec(res); m = t > 0.004
        pp = float(np.ptp(vo[m])); vi = pin_voltage(res, "R1.1")[m]
        slope = np.gradient(vo[m], t[m])
        up = slope[vi > 0.9].mean() if np.any(vi > 0.9) else 0.0
        return [_c("Triangle p-p ≈ 5 V (4.2–5.6)", 4.2 < pp < 5.6, f"{pp:.2f} V"), _c("Slope during +1 V input ≈ −10 V/ms", abs(up + 1e4) < 1500, f"{up:.0f} V/s")]
    return build, check


@lab("ac_differentiator", G, "Op-amp differentiator", {"analysis": "transient", "tstop": 0.006, "points": 6000, "uic": True},
     "Differentiate a 1 kHz sine: the output is a cosine of amplitude Rf·C·ω·Vm.",
     "Vout = −Rf·C·dVin/dt. With Rf = 1 kΩ, C = 100 nF and Vm = 1 V at 1 kHz: amplitude = 1 k · 100 n · 2π·1000 = 0.628 V. A 100 Ω series resistor limits the high-frequency gain.",
     ["Run and compare the waveforms: output leads the (inverted) input by 90°."], ["Why is a pure differentiator noisy?"])
def _diffr():
    def build():
        L = Lab("Differentiator")
        v = L.add("vac", amp=1.0, freq=1000.0); rs = L.add("resistor", R=100.0); c = L.add("capacitor_ceramic", C=100e-9); rf = L.add("resistor", R=1000.0); u = L.add("opamp")
        L.chain(f"{v}.+", f"{rs}.1", f"{rs}.2", f"{c}.+", f"{c}.−", f"{u}.−"); L.wire(f"{u}.−", f"{rf}.1"); L.wire(f"{rf}.2", f"{u}.OUT"); L.wire(f"{u}.+", f"{v}.−")
        L.gnd(f"{v}.−")
        L.scope(f"{v}.+", f"{u}.OUT")
        return L.finish()

    def check(prj, res):
        vo = pin_voltage(res, "U1.OUT"); t = tvec(res); m = t > 0.002
        return [_c("Amplitude ≈ Rf·C·ω·Vm = 0.63 V (0.55–0.65)", 0.55 < amp(vo[m]) < 0.65, f"{amp(vo[m]):.3f} V")]
    return build, check


@lab("ac_zcd", G, "Zero-crossing detector", {"analysis": "transient", "tstop": 0.004, "points": 4000, "uic": True},
     "Turn a sine into a square wave with an open-loop op-amp comparator that switches at 0 V.",
     "With no feedback the gain is huge, so the output sits at +Vsat when Vin > 0 and at −Vsat when Vin < 0.",
     ["Run and compare the sine with the square output.", "Move the reference input from 0 V to 1 V: the switching point moves."], ["What happens with noise near the crossing?"])
def _zcd():
    def build():
        L = Lab("Zero-crossing detector")
        v = L.add("vac", amp=2.0, freq=1000.0); u = L.add("opamp")
        L.chain(f"{v}.+", f"{u}.+"); L.wire(f"{u}.−", f"{v}.−")
        L.gnd(f"{v}.−")
        L.scope(f"{v}.+", f"{u}.OUT")
        return L.finish()

    def check(prj, res):
        vo = pin_voltage(res, "U1.OUT"); vi = pin_voltage(res, "U1.+"); far = np.abs(vi) > 0.1
        return [_c("Output saturates near ±13 V", vo.max() > 12 and vo.min() < -12, f"{vo.min():.1f} … {vo.max():.1f} V"), _c("Sign of output follows sign of input", bool(np.all(np.sign(vo[far]) == np.sign(vi[far]))))]
    return build, check


@lab("ac_schmitt", G, "Schmitt trigger (hysteresis)", {"analysis": "transient", "tstop": 0.03, "points": 6000, "uic": True},
     "Add positive feedback to a comparator so it switches at two different thresholds ±Vth.",
     "Feedback divider R2 = 9 kΩ (output → +) and R1 = 1 kΩ (+ → ground) puts the threshold at Vth = ±Vsat·R1/(R1+R2) = ±13 · 0.1 = ±1.3 V. The input must cross +1.3 V to switch low and −1.3 V to switch high.",
     ["Run and read where the output switches on the input waveform.", "Change R2 to 4 kΩ: the thresholds widen to ±2.6 V."], ["Why does hysteresis help with noisy signals?"])
def _schmitt():
    def build():
        L = Lab("Schmitt trigger")
        v = L.add("vac", amp=5.0, freq=100.0); r1 = L.add("resistor", R=1000.0); r2 = L.add("resistor", R=9000.0); u = L.add("opamp")
        L.chain(f"{v}.+", f"{u}.−"); L.wire(f"{u}.+", f"{r1}.1", f"{r2}.1"); L.wire(f"{r2}.2", f"{u}.OUT"); L.wire(f"{r1}.2", f"{v}.−")
        L.gnd(f"{v}.−")
        L.scope(f"{v}.+", f"{u}.OUT")
        return L.finish()

    def check(prj, res):
        vo = pin_voltage(res, "U1.OUT"); vi = pin_voltage(res, "U1.−")
        flips = np.where(np.abs(np.diff(np.sign(vo))) > 1)[0]
        hi = [vi[k] for k in flips if vo[k + 1] < 0]; lo = [vi[k] for k in flips if vo[k + 1] > 0]
        return [_c("Switches at least 4 times", len(flips) >= 4, f"{len(flips)} transitions"), _c("Falling threshold ≈ +1.3 V (1.0–1.6)", bool(hi) and all(1.0 < x < 1.6 for x in hi), ", ".join(f"{x:.2f}" for x in hi)),
                _c("Rising threshold ≈ −1.3 V (−1.6…−1.0)", bool(lo) and all(-1.6 < x < -1.0 for x in lo), ", ".join(f"{x:.2f}" for x in lo))]
    return build, check


@lab("ac_precision_rectifier", G, "Precision half-wave rectifier", {"analysis": "transient", "tstop": 0.004, "points": 4000, "uic": True},
     "Rectify a small 1 V signal without losing the 0.7 V diode drop by putting the diode in the op-amp feedback loop.",
     "The op-amp drives the diode just hard enough that the output follows the input when it is positive; the effective diode drop is divided by the open-loop gain. A plain diode rectifier would lose 0.7 V of a 1 V peak.",
     ["Run and compare with the plain half-wave rectifier experiment.", "Reduce the input to 0.3 V: it still rectifies."], ["What happens to the op-amp output when the input is negative?"])
def _prec():
    def build():
        L = Lab("Precision rectifier")
        v = L.add("vac", amp=1.0, freq=1000.0); u = L.add("opamp", A=1000.0); d = L.add("diode"); r = L.add("resistor", R=10000.0)
        L.chain(f"{v}.+", f"{u}.+", f"{u}.OUT", f"{d}.A"); L.wire(f"{d}.K", f"{u}.−", f"{r}.1"); L.wire(f"{r}.2", f"{v}.−")
        L.gnd(f"{v}.−")
        L.scope(f"{v}.+", f"{r}.1")
        return L.finish()

    def check(prj, res):
        vo = pin_voltage(res, "R1.1")
        return [_c("Peak output ≈ 1.00 V (no diode drop; ≥ 0.97)", vo.max() > 0.97, f"{vo.max():.3f} V"), _c("Negative half blocked (min > −10 mV)", vo.min() > -0.01, f"{vo.min():.4f} V")]
    return build, check


@lab("ac_peak_detector", G, "Peak detector", {"analysis": "transient", "tstop": 0.006, "points": 6000, "uic": True},
     "Hold the peak of a 3 V sine on a capacitor with an op-amp, diode and capacitor.",
     "The op-amp charges C through the diode whenever the input exceeds the held voltage; the diode blocks discharge. Because the diode is inside the feedback loop the held value equals the true peak (3.0 V).",
     ["Run and watch the output climb to the peak and stay.", "Lower the input amplitude: the output holds the old peak (slowly leaking through R)."], ["What limits the hold time?"])
def _peak():
    def build():
        L = Lab("Peak detector")
        v = L.add("vac", amp=3.0, freq=1000.0); u = L.add("opamp", A=1000.0); d = L.add("diode"); c = L.add("capacitor_ceramic", C=1e-6); r = L.add("resistor", R=1e6)
        L.chain(f"{v}.+", f"{u}.+", f"{u}.OUT", f"{d}.A"); L.wire(f"{d}.K", f"{u}.−", f"{c}.+", f"{r}.1"); L.wire(f"{c}.−", f"{r}.2", f"{v}.−")
        L.gnd(f"{v}.−")
        L.scope(f"{v}.+", f"{c}.+")
        return L.finish()

    def check(prj, res):
        vo = pin_voltage(res, "C1.+")
        return [_c("Held voltage ≈ 3.0 V peak (2.9–3.05)", 2.9 < vo[-1] < 3.05, f"{vo[-1]:.3f} V")]
    return build, check


# ---------------------------------------------------------------------------------------------------------------- passive and active filters
def _rc(kind):
    L = Lab(f"RC {kind}")
    v = L.add("vac", amp=1.0, freq=1000.0); r = L.add("resistor", R=1000.0); c = L.add("capacitor_ceramic", C=100e-9)
    if kind == "low-pass":
        L.chain(f"{v}.+", f"{r}.1"); L.wire(f"{r}.2", f"{c}.+"); L.wire(f"{c}.−", f"{v}.−")
    else:
        L.chain(f"{v}.+", f"{c}.+"); L.wire(f"{c}.−", f"{r}.1"); L.wire(f"{r}.2", f"{v}.−")
    L.gnd(f"{v}.−")
    return L.finish()


@lab("ac_rc_lowpass", G, "RC low-pass filter (frequency response)", {"analysis": "ac", "fmin": 10.0, "fmax": 100000.0, "fpoints": 300},
     "Measure the −3 dB frequency and the roll-off of a first-order low-pass filter.",
     "fc = 1/(2πRC) = 1/(2π · 1 kΩ · 100 nF) = 1592 Hz. At fc the gain is 0.707 (−3 dB) and the phase −45°; beyond fc the gain falls 20 dB per decade.",
     ["Run and read the gain at 1.6 kHz.", "Change C to 10 nF: fc becomes 15.9 kHz."], ["What is the gain at 10·fc?"])
def _lp():
    def build():
        return _rc("low-pass")

    def check(prj, res):
        f = freqs(res); h = np.abs(pin_voltage(res, "C1.+")); k = np.argmin(abs(f - 1592)); k10 = np.argmin(abs(f - 15920))
        return [_c("|H(fc)| = 0.707 (±3 %)", abs(h[k] - 0.7071) < 0.022, f"{h[k]:.3f}"), _c("Gain at 10·fc ≈ 0.0995 (−20 dB/decade)", abs(h[k10] - 0.0995) < 0.005, f"{h[k10]:.4f}"), _c("Passband gain 1", abs(h[0] - 1) < 0.01)]
    return build, check


@lab("ac_rc_highpass", G, "RC high-pass filter (frequency response)", {"analysis": "ac", "fmin": 10.0, "fmax": 100000.0, "fpoints": 300},
     "Measure the −3 dB frequency of a first-order high-pass filter.",
     "fc = 1/(2πRC) = 1592 Hz. Below fc the gain rises at 20 dB per decade; far above it the gain is 1.",
     ["Run and read the gain at 160 Hz and at 16 kHz."], ["Where would you use a high-pass filter?"])
def _hp():
    def build():
        return _rc("high-pass")

    def check(prj, res):
        f = freqs(res); h = np.abs(pin_voltage(res, "R1.1")); k = np.argmin(abs(f - 1592)); k1 = np.argmin(abs(f - 159.2))
        return [_c("|H(fc)| = 0.707 (±3 %)", abs(h[k] - 0.7071) < 0.022, f"{h[k]:.3f}"), _c("Gain at fc/10 ≈ 0.0995", abs(h[k1] - 0.0995) < 0.005, f"{h[k1]:.4f}"), _c("Passband gain → 1", abs(h[-1] - 1) < 0.01)]
    return build, check


@lab("ac_active_lpf", G, "Active low-pass filter (op-amp)", {"analysis": "ac", "fmin": 10.0, "fmax": 100000.0, "fpoints": 300},
     "A first-order active low-pass filter gives gain −Rf/Ri below fc = 1/(2πRf·Cf) and works from a low-impedance output.",
     "H(s) = −(Rf/Ri)/(1 + sRfCf). With Ri = Rf = 10 kΩ and Cf = 10 nF: DC gain −1 and fc = 1592 Hz.",
     ["Run: gain 1 in the passband, 0.707 at 1.6 kHz.", "Change Rf to 20 kΩ: gain 2 and fc halves."], ["What is the advantage over the passive RC filter?"])
def _alp():
    def build():
        L = Lab("Active low-pass")
        v = L.add("vac", amp=1.0, freq=1000.0); ri = L.add("resistor", R=10000.0); rf = L.add("resistor", R=10000.0); cf = L.add("capacitor_ceramic", C=10e-9); u = L.add("opamp")
        L.chain(f"{v}.+", f"{ri}.1", f"{ri}.2", f"{u}.−"); L.wire(f"{u}.−", f"{rf}.1", f"{cf}.+"); L.wire(f"{rf}.2", f"{cf}.−", f"{u}.OUT"); L.wire(f"{u}.+", f"{v}.−")
        L.gnd(f"{v}.−")
        return L.finish()

    def check(prj, res):
        f = freqs(res); h = np.abs(pin_voltage(res, "U1.OUT")); k = np.argmin(abs(f - 1592))
        return [_c("DC gain 1 (|H| ≈ 1.0)", abs(h[0] - 1.0) < 0.02, f"{h[0]:.3f}"), _c("|H(fc)| = 0.707 (±4 %)", abs(h[k] - 0.7071) < 0.03, f"{h[k]:.3f}")]
    return build, check


@lab("ac_rc_phase", G, "RC phase-shift network (oscillator feedback)", {"analysis": "ac", "fmin": 100.0, "fmax": 5000.0, "fpoints": 400},
     "Find the frequency where a three-section RC ladder shifts the phase by 180° and note its attenuation.",
     "For the three-stage ladder f = 1/(2π√6·RC) = 650 Hz (R = 10 kΩ, C = 10 nF) and |H| = 1/29. An amplifier with gain 29 and inversion would therefore sustain oscillation (RC phase-shift oscillator).",
     ["Run and read the phase near 650 Hz in the frequency response."], ["What minimum amplifier gain is needed to oscillate?"])
def _ph():
    def build():
        L = Lab("RC phase shift")
        v = L.add("vac", amp=1.0, freq=650.0); r = [L.add("resistor", R=10000.0) for _ in range(3)]; c = [L.add("capacitor_ceramic", C=10e-9) for _ in range(3)]
        L.chain(f"{v}.+", f"{c[0]}.+", f"{c[0]}.−", f"{c[1]}.+", f"{c[1]}.−", f"{c[2]}.+")
        L.wire(f"{c[0]}.−", f"{r[0]}.1"); L.wire(f"{c[1]}.−", f"{r[1]}.1"); L.wire(f"{c[2]}.−", f"{r[2]}.1")
        L.wire(f"{r[0]}.2", f"{r[1]}.2", f"{r[2]}.2", f"{v}.−")
        L.gnd(f"{v}.−")
        return L.finish()

    def check(prj, res):
        f = freqs(res); h = pin_voltage(res, "R3.1") / pin_voltage(res, "V1.+"); k = np.argmin(abs(f - 650))
        ph = abs(np.degrees(np.angle(h[k])))
        return [_c("|H| at 650 Hz ≈ 1/29 = 0.0345 (±8 %)", abs(abs(h[k]) - 1 / 29) < 0.003, f"{abs(h[k]):.4f}"), _c("Phase ≈ ±180° at 650 Hz (±8°)", abs(ph - 180.0) < 8.0, f"{ph:.1f}°")]
    return build, check


# ---------------------------------------------------------------------------------------------------------------- transistor amplifiers
@lab("ac_ce_amp", G, "Common-emitter amplifier", {"analysis": "transient", "tstop": 0.006, "points": 12000, "uic": False},
     "Amplify a 10 mV, 1 kHz signal with a voltage-divider-biased common-emitter stage and measure the gain and phase inversion.",
     "Ic ≈ 1.45 mA gives gm = Ic/VT ≈ 56 mS. With the emitter bypassed, Av ≈ −gm·(Rc ∥ RL) = −56 mS · 1.8 kΩ ≈ −100. The output is inverted (180°).",
     ["Run and compare the input and output waveforms in the Waveforms tab.", "Remove the bypass capacitor (set Ce to 1 pF): the gain drops to about −Rc/Re = −2."], ["Why does the bypass capacitor raise the gain?"])
def _ce():
    def build():
        L = Lab("Common-emitter amplifier")
        vcc = L.add("vdc", V=12.0); vs = L.add("vac", amp=0.01, freq=1000.0); q = L.add("npn")
        r1 = L.add("resistor", R=47000.0); r2 = L.add("resistor", R=10000.0); rc = L.add("resistor", R=2200.0); re = L.add("resistor", R=1000.0); rl = L.add("resistor", R=10000.0)
        cin = L.add("capacitor", C=10e-6); ce = L.add("capacitor", C=100e-6); cout = L.add("capacitor", C=10e-6)
        L.wire(f"{vcc}.+", f"{r1}.1", f"{rc}.1"); L.wire(f"{r1}.2", f"{r2}.1", f"{q}.B", f"{cin}.−"); L.chain(f"{vs}.+", f"{cin}.+"); L.wire(f"{rc}.2", f"{q}.C", f"{cout}.+")
        L.wire(f"{q}.E", f"{re}.1", f"{ce}.+"); L.chain(f"{cout}.−", f"{rl}.1")
        L.wire(f"{r2}.2", f"{re}.2", f"{ce}.−", f"{rl}.2", f"{vcc}.−", f"{vs}.−")
        L.gnd(f"{vcc}.−")
        L.scope(f"{vs}.+", f"{rl}.1")
        return L.finish()

    def check(prj, res):
        vo = pin_voltage(res, "R5.1"); vi = pin_voltage(res, "V2.+"); t = tvec(res); m = t > 0.003
        gain = amp(vo[m]) / amp(vi[m]); corr = float(np.corrcoef(vo[m] - vo[m].mean(), vi[m] - vi[m].mean())[0, 1])
        return [_c("|Av| ≈ gm·(Rc∥RL) ≈ 100 (±20 %)", 80 < gain < 120, f"{gain:.1f}"), _c("Output inverted (correlation < −0.95)", corr < -0.95, f"{corr:.3f}"), _c("Collector bias ≈ 8.8 V", 7.8 < pin_voltage(res, "R3.2")[m].mean() < 9.4)]
    return build, check


@lab("ac_emitter_follower", G, "Emitter follower (common collector)", {"analysis": "transient", "tstop": 0.006, "points": 6000, "uic": False},
     "Buffer a 1 V sine with an emitter follower: voltage gain just below 1, in phase, low output resistance.",
     "Av = gm·RE/(1 + gm·RE) ≈ 0.99 and the DC level shifts down by VBE ≈ 0.65 V. The input resistance is high (≈ β·RE) and the output resistance is only re ≈ 1/gm.",
     ["Run and compare input and output.", "Load the output with 100 Ω and see how little the gain changes."], ["Where is an emitter follower used?"])
def _ef():
    def build():
        L = Lab("Emitter follower")
        vcc = L.add("vdc", V=12.0); vs = L.add("vac", amp=1.0, freq=1000.0); q = L.add("npn")
        r1 = L.add("resistor", R=10000.0); r2 = L.add("resistor", R=10000.0); re = L.add("resistor", R=2200.0); cin = L.add("capacitor", C=10e-6); cout = L.add("capacitor", C=10e-6); rl = L.add("resistor", R=10000.0)
        L.wire(f"{vcc}.+", f"{r1}.1", f"{q}.C"); L.wire(f"{r1}.2", f"{r2}.1", f"{q}.B", f"{cin}.−"); L.chain(f"{vs}.+", f"{cin}.+"); L.wire(f"{q}.E", f"{re}.1", f"{cout}.+"); L.chain(f"{cout}.−", f"{rl}.1")
        L.wire(f"{r2}.2", f"{re}.2", f"{rl}.2", f"{vcc}.−", f"{vs}.−")
        L.gnd(f"{vcc}.−")
        L.scope(f"{vs}.+", f"{rl}.1")
        return L.finish()

    def check(prj, res):
        vo = pin_voltage(res, "R4.1"); vi = pin_voltage(res, "V2.+"); t = tvec(res); m = t > 0.003
        gain = amp(vo[m]) / amp(vi[m]); corr = float(np.corrcoef(vo[m] - vo[m].mean(), vi[m] - vi[m].mean())[0, 1])
        return [_c("Gain 0.9–1.0", 0.9 < gain < 1.0, f"{gain:.3f}"), _c("In phase (correlation > 0.99)", corr > 0.99, f"{corr:.4f}"), _c("Emitter DC = Vb − VBE ≈ 5.3 V", 4.9 < pin_voltage(res, "R3.1")[m].mean() < 5.7)]
    return build, check


@lab("ac_class_b", G, "Class-B push-pull output stage (crossover distortion)", {"analysis": "transient", "tstop": 0.004, "points": 8000, "uic": True},
     "Drive a 1 kΩ load with a complementary emitter follower and see the dead zone around zero (crossover distortion).",
     "The NPN conducts only above +0.65 V and the PNP only below −0.65 V, so inputs between ±0.65 V produce no output. Class-AB bias (two diode drops) removes the dead zone.",
     ["Run and compare input and output near the zero crossing.", "Reduce the amplitude to 0.5 V: the output vanishes."], ["How do two bias diodes remove the distortion?"])
def _clb():
    def build():
        L = Lab("Class-B stage")
        vp = L.add("vdc", V=12.0); vn = L.add("vdc", V=12.0); vs = L.add("vac", amp=5.0, freq=1000.0); qn = L.add("npn"); qp = L.add("2n3906"); rl = L.add("resistor", R=1000.0)
        L.wire(f"{vp}.+", f"{qn}.C"); L.wire(f"{vn}.−", f"{qp}.C"); L.wire(f"{vs}.+", f"{qn}.B", f"{qp}.B"); L.wire(f"{qn}.E", f"{qp}.E", f"{rl}.1")
        L.wire(f"{vp}.−", f"{vn}.+", f"{vs}.−", f"{rl}.2")
        L.gnd(f"{vp}.−")
        L.scope(f"{vs}.+", f"{rl}.1")
        return L.finish()

    def check(prj, res):
        vo = pin_voltage(res, "R1.1"); vi = pin_voltage(res, "V3.+")
        dead = np.abs(vi) < 0.5
        return [_c("Dead zone: |Vout| < 20 mV while |Vin| < 0.5 V", bool(dead.any()) and float(np.abs(vo[dead]).max()) < 0.02, f"{np.abs(vo[dead]).max() * 1e3:.1f} mV"),
                _c("Peak output ≈ 5 V − 0.65 V (4.1–4.6)", 4.1 < vo.max() < 4.6, f"{vo.max():.2f} V"), _c("Symmetric swing", abs(vo.max() + vo.min()) < 0.3)]
    return build, check


# ---------------------------------------------------------------------------------------------------------------- 555 and converters
@lab("ac_555_mono", G, "555 monostable (one-shot)", {"analysis": "transient", "tstop": 0.3, "points": 12000, "uic": True},
     "A short low pulse on TRIG makes the 555 output go high for T = 1.1·R·C.",
     "The timing capacitor charges through R toward VCC and the output returns low when it reaches 2/3 VCC: T = 1.1·R·C = 1.1 · 10 kΩ · 10 µF = 110 ms.",
     ["Run and measure the output pulse width on the Waveforms tab.", "Change C to 22 µF: the pulse becomes 242 ms."], ["What happens if a second trigger arrives during the pulse?"])
def _mono():
    def build():
        L = Lab("555 monostable")
        vcc = L.add("vdc", V=5.0); u = L.add("ne555"); r = L.add("resistor", R=10000.0); c = L.add("capacitor", C=10e-6); rt = L.add("resistor", R=10000.0)
        trig = L.add("vpulse", v1=5.0, v2=0.0, freq=2.0, duty=0.02, delay=0.02, edge=0.01)
        L.wire(f"{vcc}.+", f"{u}.VCC", f"{u}.RESET", f"{r}.1", f"{rt}.1"); L.wire(f"{r}.2", f"{u}.THR", f"{u}.DIS", f"{c}.+"); L.wire(f"{rt}.2", f"{u}.TRIG", f"{trig}.+")
        L.wire(f"{vcc}.−", f"{u}.GND", f"{c}.−", f"{trig}.−")
        L.gnd(f"{vcc}.−")
        L.scope(f"{trig}.+", f"{u}.OUT")
        return L.finish()

    def check(prj, res):
        vo = pin_voltage(res, "U1.OUT"); t = tvec(res); hi = vo > 2.5
        edges = np.where(np.diff(hi.astype(int)) != 0)[0]
        w = (t[edges[1]] - t[edges[0]]) if len(edges) >= 2 else 0.0
        return [_c("One pulse of T = 1.1·R·C = 110 ms (±10 %)", abs(w - 0.11) < 0.011, f"{w * 1e3:.1f} ms"), _c("Output is low again afterwards", not hi[-1])]
    return build, check


@lab("ac_r2r_dac", G, "R-2R ladder DAC (4-bit)", {"analysis": "op"},
     "Convert a 4-bit digital code to an analog voltage with an R-2R resistor ladder: Vout = Vref · code / 16.",
     "Each bit contributes Vref·2^i/16 at the output node because of the ladder's binary attenuation. For code 1010 (decimal 10) and Vref = 5 V: Vout = 5 · 10/16 = 3.125 V.",
     ["Run with D3 = 1, D2 = 0, D1 = 1, D0 = 0.", "Change the four bit batteries between 0 V and 5 V and compute the expected output."], ["How many resistor values are needed for an N-bit R-2R DAC?"])
def _dac():
    def build(code=0b1010):
        L = Lab("R-2R DAC")
        bits = [L.add("vdc", V=5.0 if (code >> i) & 1 else 0.0) for i in range(4)]
        two = [L.add("resistor", R=20000.0) for _ in range(4)]; one = [L.add("resistor", R=10000.0) for _ in range(3)]; term = L.add("resistor", R=20000.0)
        for i in range(4):
            L.chain(f"{bits[i]}.+", f"{two[i]}.1")
        for i in range(3):
            L.chain(f"{two[i]}.2", f"{one[i]}.1", f"{one[i]}.2", f"{two[i + 1]}.2")
        L.wire(f"{two[0]}.2", f"{term}.1"); L.wire(f"{term}.2", *[f"{b}.−" for b in bits])
        L.gnd(f"{bits[0]}.−")
        return L.finish()

    def vout(code):
        return pin_voltage(run_analog(build(code), analysis="op"), "R4.2")

    def check(prj, res):
        out = {c: vout(c) for c in (0b1010, 0b0101, 0b1111, 0b0001)}
        return [_c(f"Code {c:04b}: Vout = 5·{c}/16 = {5 * c / 16:.3f} V", abs(v - 5 * c / 16) < 0.01, f"{v:.3f} V") for c, v in out.items()]
    return build, check
