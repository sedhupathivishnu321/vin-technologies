"""Basic Electrical Engineering Laboratory: Ohm, Kirchhoff, network theorems, transients, resonance, AC power."""
from __future__ import annotations
import math
import numpy as np

from .core import Lab, lab, _c, run, vt, run_analog, pin_voltage

G = "Basic Electrical Lab"


def tvec(res):
    return next(iter(res.signals.values())).x


def rms(y):
    return float(np.sqrt(np.mean(np.square(y))))


# ---------------------------------------------------------------------------------------------------------------- Ohm's law
@lab("bee_ohm", G, "Ohm's law", {"analysis": "op"},
     "Measure the current in a resistor at a fixed voltage and confirm V = I·R.",
     "Ohm's law: I = V / R. A 10 V source across 2.2 kΩ drives 4.545 mA; doubling R halves the current.",
     ["Press ▶ Start Simulation and read the ammeter and voltmeter.", "Change R1 to 4.4 kΩ: the current halves.", "Change the battery to 5 V: the current halves again."],
     ["What is the power dissipated in R1?"])
def _ohm():
    def build(V=10.0, R=2200.0):
        L = Lab("Ohm's law")
        v = L.add("vdc", V=V); r = L.add("resistor", R=R); a = L.add("ammeter"); m = L.add("voltmeter")
        L.chain(f"{v}.+", f"{a}.+"); L.wire(f"{a}.−", f"{r}.1", f"{m}.+"); L.wire(f"{r}.2", f"{m}.−", f"{v}.−")
        L.gnd(f"{v}.−")
        return L.finish()

    def check(prj, res):
        i = res.m("I(R1)"); v = pin_voltage(res, "R1.1")
        return [_c("I = V/R = 4.545 mA", abs(i - 10 / 2200) < 1e-6, f"{i * 1e3:.4f} mA"), _c("Voltage across R1 = 10 V", abs(v - 10) < 1e-3, f"{v:.4f} V")]
    return build, check


@lab("bee_equiv", G, "Equivalent resistance (series + parallel)", {"analysis": "op"},
     "Find the equivalent resistance of R1 in series with (R2 ∥ R3) from the source current.",
     "Req = R1 + R2·R3/(R2+R3) = 1 kΩ + 2 kΩ ∥ 2 kΩ = 2 kΩ, so a 10 V source supplies 5 mA.",
     ["Run and compare the source current with 10 V / Req.", "Change R3 to 1 kΩ and recompute Req."], ["Which resistor dissipates most power?"])
def _equiv():
    def build():
        L = Lab("Equivalent resistance")
        v = L.add("vdc", V=10.0); r1 = L.add("resistor", R=1000.0); r2 = L.add("resistor", R=2000.0); r3 = L.add("resistor", R=2000.0)
        L.chain(f"{v}.+", f"{r1}.1"); L.wire(f"{r1}.2", f"{r2}.1", f"{r3}.1"); L.wire(f"{r2}.2", f"{r3}.2", f"{v}.−")
        L.gnd(f"{v}.−")
        return L.finish()

    def check(prj, res):
        i = res.m("I(R1)")
        return [_c("Source current = 10 V / 2 kΩ = 5 mA", abs(i - 5e-3) < 1e-6, f"{i * 1e3:.4f} mA"), _c("Req = V/I = 2 kΩ", abs(10 / i - 2000) < 1, f"{10 / i:.1f} Ω")]
    return build, check


@lab("bee_lamps", G, "Lamp circuits in series and in parallel", {"analysis": "op"},
     "Compare three identical lamps (100 Ω) in series and in parallel on a 12 V supply.",
     "Series: the same current I = V/3R = 40 mA flows through all lamps, each gets V/3. Parallel: each lamp gets the full 12 V and draws 120 mA, so the supply delivers 360 mA.",
     ["Run and compare the brightness (LED current) of both groups.", "Remove one lamp: in the series group everything goes dark, in the parallel group the others stay lit."],
     ["Why are house lamps wired in parallel?"])
def _lamps():
    def build():
        L = Lab("Lamps in series and parallel")
        v = L.add("vdc", V=12.0)
        s = [L.add("resistor", R=100.0) for _ in range(3)]
        p = [L.add("resistor", R=100.0) for _ in range(3)]
        L.chain(f"{v}.+", f"{s[0]}.1", f"{s[0]}.2", f"{s[1]}.1", f"{s[1]}.2", f"{s[2]}.1"); L.chain(f"{s[2]}.2", f"{v}.−")
        L.wire(f"{v}.+", *[f"{x}.1" for x in p]); L.wire(f"{v}.−", *[f"{x}.2" for x in p])
        L.gnd(f"{v}.−")
        return L.finish()

    def check(prj, res):
        return [_c("Series current 40 mA", abs(res.m("I(R1)") - 0.04) < 1e-5, f"{res.m('I(R1)') * 1e3:.3f} mA"),
                _c("Each parallel lamp 120 mA", abs(res.m("I(R4)") - 0.12) < 1e-4, f"{res.m('I(R4)') * 1e3:.3f} mA"),
                _c("Voltage across a series lamp 4 V", abs(pin_voltage(res, "R1.1") - pin_voltage(res, "R1.2") - 4) < 1e-3)]
    return build, check


# ---------------------------------------------------------------------------------------------------------------- Kirchhoff
@lab("bee_kcl", G, "Kirchhoff's current law", {"analysis": "op"},
     "Verify that the currents into a node sum to zero.",
     "KCL: Σ I(in) = Σ I(out). The 12 V source feeds R1 into a node that splits through R2 and R3 to ground: I1 = I2 + I3.",
     ["Run and read the three branch currents.", "Change R3: I1 and I3 change, but I1 = I2 + I3 always holds."], ["What happens to I2 when R3 changes?"])
def _kcl():
    def build():
        L = Lab("KCL")
        v = L.add("vdc", V=12.0); r1 = L.add("resistor", R=100.0); r2 = L.add("resistor", R=220.0); r3 = L.add("resistor", R=330.0)
        L.chain(f"{v}.+", f"{r1}.1"); L.wire(f"{r1}.2", f"{r2}.1", f"{r3}.1"); L.wire(f"{r2}.2", f"{r3}.2", f"{v}.−")
        L.gnd(f"{v}.−")
        return L.finish()

    def check(prj, res):
        i1, i2, i3 = res.m("I(R1)"), res.m("I(R2)"), res.m("I(R3)")
        return [_c("I1 = I2 + I3", abs(i1 - i2 - i3) < 1e-9, f"{i1 * 1e3:.3f} = {i2 * 1e3:.3f} + {i3 * 1e3:.3f} mA")]
    return build, check


@lab("bee_kvl", G, "Kirchhoff's voltage law", {"analysis": "op"},
     "Verify that the voltage drops around a loop add up to the source voltage.",
     "KVL: Σ V = 0 around any closed loop. 12 V = I·(1 k + 2.2 k + 4.7 k) with I = 1.519 mA.",
     ["Run and add the three drops.", "Reverse the battery: all drops change sign."], ["Which resistor takes most of the voltage?"])
def _kvl():
    def build():
        L = Lab("KVL")
        v = L.add("vdc", V=12.0); r = [L.add("resistor", R=x) for x in (1000.0, 2200.0, 4700.0)]
        L.chain(f"{v}.+", f"{r[0]}.1", f"{r[0]}.2", f"{r[1]}.1", f"{r[1]}.2", f"{r[2]}.1"); L.chain(f"{r[2]}.2", f"{v}.−")
        L.gnd(f"{v}.−")
        return L.finish()

    def check(prj, res):
        drops = [pin_voltage(res, f"R{k}.1") - pin_voltage(res, f"R{k}.2") for k in (1, 2, 3)]
        return [_c("V1 + V2 + V3 = 12 V", abs(sum(drops) - 12) < 1e-6, " + ".join(f"{d:.3f}" for d in drops) + f" = {sum(drops):.3f} V"),
                _c("Drops proportional to R", abs(drops[2] / drops[0] - 4.7) < 1e-3)]
    return build, check


# ---------------------------------------------------------------------------------------------------------------- network theorems
def _two_source(V1=10.0, V2=5.0):
    L = Lab("Superposition")
    a = L.add("vdc", V=V1); b = L.add("vdc", V=V2); r1 = L.add("resistor", R=1000.0); r2 = L.add("resistor", R=2000.0); r3 = L.add("resistor", R=1000.0)
    L.chain(f"{a}.+", f"{r1}.1"); L.chain(f"{b}.+", f"{r2}.1"); L.wire(f"{r1}.2", f"{r2}.2", f"{r3}.1"); L.wire(f"{r3}.2", f"{a}.−", f"{b}.−")
    L.gnd(f"{a}.−")
    return L.finish()


@lab("bee_superposition", G, "Superposition theorem", {"analysis": "op"},
     "Show that the node voltage with both sources equals the sum of the voltages caused by each source alone.",
     "In a linear circuit V = V(source 1 alone) + V(source 2 alone). Here the node X between R1, R2 and R3 is solved three times: both sources, then each with the other set to 0 V.",
     ["Run: note V(X) with both sources.", "Set the 5 V source to 0 V, run, note V(X). Then restore it and set the 10 V source to 0 V.", "Add the two partial answers."], ["Why does superposition fail for power?"])
def _sup():
    def build(V1=10.0, V2=5.0):
        return _two_source(V1, V2)

    def check(prj, res):
        both = pin_voltage(res, "R3.1")
        a = pin_voltage(run_analog(build(10.0, 0.0), analysis="op"), "R3.1"); b = pin_voltage(run_analog(build(0.0, 5.0), analysis="op"), "R3.1")
        return [_c("V(both) = V(1 alone) + V(2 alone)", abs(both - a - b) < 1e-9, f"{both:.4f} = {a:.4f} + {b:.4f} V")]
    return build, check


def _thev(RL=1000.0):
    L = Lab("Thevenin")
    v = L.add("vdc", V=12.0); r1 = L.add("resistor", R=1000.0); r2 = L.add("resistor", R=2000.0); r3 = L.add("resistor", R=500.0); rl = L.add("resistor", R=RL)
    L.chain(f"{v}.+", f"{r1}.1"); L.wire(f"{r1}.2", f"{r2}.1", f"{r3}.1"); L.wire(f"{r2}.2", f"{v}.−", f"{rl}.2"); L.chain(f"{r3}.2", f"{rl}.1")
    L.gnd(f"{v}.−")
    return L.finish()


def _thev_equiv(RL=1000.0, norton=False):
    vth, rth = 8.0, 1000 * 2000 / 3000 + 500.0
    L = Lab("Thevenin equivalent")
    if norton:
        i = L.add("idc", I=vth / rth); rn = L.add("resistor", R=rth); rl = L.add("resistor", R=RL)
        L.wire(f"{i}.+", f"{rn}.1", f"{rl}.1"); L.wire(f"{i}.−", f"{rn}.2", f"{rl}.2")
    else:
        v = L.add("vdc", V=vth); rt = L.add("resistor", R=rth); rl = L.add("resistor", R=RL)
        L.chain(f"{v}.+", f"{rt}.1", f"{rt}.2", f"{rl}.1"); L.wire(f"{rl}.2", f"{v}.−")
    L.gnd(f"{rl}.2")
    return L.finish()


@lab("bee_thevenin", G, "Thevenin's theorem", {"analysis": "op"},
     "Replace a network by Vth in series with Rth and show the load sees the same voltage.",
     "Looking back from the load: Vth = 12 V · 2k/(1k+2k) = 8 V and Rth = (1k ∥ 2k) + 500 Ω = 1.1667 kΩ. The load voltage is Vth·RL/(Rth+RL) = 3.692 V.",
     ["Run and note the load voltage across R4.", "Change R4 and check VL = 8·RL/(1166.7+RL)."], ["Why is Rth found with the source shorted?"])
def _thev_ex():
    def build():
        return _thev()

    def check(prj, res):
        v = pin_voltage(res, "R4.1"); eq = pin_voltage(run_analog(_thev_equiv(), analysis="op"), "R2.1")
        return [_c("Load voltage = Vth·RL/(Rth+RL) = 3.692 V", abs(v - 8 * 1000 / (1166.667 + 1000)) < 1e-3, f"{v:.4f} V"), _c("Thevenin equivalent gives the same load voltage", abs(v - eq) < 1e-6, f"{eq:.4f} V")]
    return build, check


@lab("bee_norton", G, "Norton's theorem", {"analysis": "op"},
     "Replace the same network by IN in parallel with Rth and compare the load current.",
     "IN = Vth/Rth = 8 V / 1.1667 kΩ = 6.857 mA. The load takes IN·Rth/(Rth+RL).",
     ["Run and read the load current of R4.", "Compare with the Thevenin experiment."], ["How are Thevenin and Norton equivalents related?"])
def _norton():
    def build():
        return _thev_equiv(norton=True)

    def check(prj, res):
        i = res.m("I(R2)"); ref = run_analog(_thev(), analysis="op").m("I(R4)")
        return [_c("Load current = IN·Rth/(Rth+RL) = 3.692 mA", abs(i - 8 / (1166.667 + 1000)) < 1e-6, f"{i * 1e3:.4f} mA"), _c("Equals the original network's load current", abs(i - ref) < 1e-7, f"{ref * 1e3:.4f} mA")]
    return build, check


@lab("bee_mpt", G, "Maximum power transfer", {"analysis": "op"},
     "Show that a source delivers maximum power to the load when RL equals the source resistance.",
     "P = V²·RL/(Rs+RL)². It peaks at RL = Rs: here 10 V behind 100 Ω gives 250 mW into 100 Ω, but only 222 mW at 50 Ω or 200 Ω.",
     ["Run with RL = 100 Ω and read the power.", "Try RL = 50, 200 and 400 Ω: all give less power."], ["What is the efficiency at maximum power transfer?"])
def _mpt():
    def build(RL=100.0):
        L = Lab("Maximum power transfer")
        v = L.add("vdc", V=10.0); rs = L.add("resistor", R=100.0); rl = L.add("resistor", R=RL)
        L.chain(f"{v}.+", f"{rs}.1", f"{rs}.2", f"{rl}.1"); L.wire(f"{rl}.2", f"{v}.−")
        L.gnd(f"{v}.−")
        return L.finish()

    def power(RL):
        r = run_analog(build(RL), analysis="op"); return r.m("I(R2)") ** 2 * RL

    def check(prj, res):
        p = res.m("I(R2)") ** 2 * 100.0
        return [_c("P(RL = Rs) = 250 mW", abs(p - 0.25) < 1e-4, f"{p * 1e3:.2f} mW"), _c("Less power at 50 Ω, 200 Ω and 400 Ω", all(power(x) < p for x in (50.0, 200.0, 400.0)),
                f"{power(50.0) * 1e3:.0f}, {power(200.0) * 1e3:.0f}, {power(400.0) * 1e3:.0f} mW")]
    return build, check


@lab("bee_wheatstone", G, "Wheatstone bridge", {"analysis": "op"},
     "Balance a bridge: the meter reads zero when R1/R2 = R3/Rx.",
     "Balance condition R1/R2 = R3/R4. With 1 kΩ, 1 kΩ and 2.2 kΩ the unknown R4 = 2.2 kΩ gives 0 V; detuning R4 to 2.4 kΩ gives about 0.1 V from a 5 V supply.",
     ["Run: the voltmeter reads 0 V (balanced).", "Change R4 to 2.4 kΩ and observe the unbalance voltage."], ["How would you use this to measure an unknown resistor?"])
def _wheat():
    def build(R4=2200.0):
        L = Lab("Wheatstone bridge")
        v = L.add("vdc", V=5.0); r1 = L.add("resistor", R=1000.0); r2 = L.add("resistor", R=1000.0); r3 = L.add("resistor", R=2200.0); r4 = L.add("resistor", R=R4); m = L.add("voltmeter")
        L.chain(f"{v}.+", f"{r1}.1"); L.wire(f"{v}.+", f"{r3}.1"); L.wire(f"{r1}.2", f"{r2}.1", f"{m}.+"); L.wire(f"{r3}.2", f"{r4}.1", f"{m}.−"); L.wire(f"{r2}.2", f"{r4}.2", f"{v}.−")
        L.gnd(f"{v}.−")
        return L.finish()

    def check(prj, res):
        vb = pin_voltage(res, "R1.2") - pin_voltage(res, "R3.2")
        un = run_analog(build(2400.0), analysis="op"); vu = pin_voltage(un, "R1.2") - pin_voltage(un, "R3.2")
        return [_c("Balanced: bridge voltage 0 V", abs(vb) < 1e-6, f"{vb * 1e3:.4f} mV"), _c("R4 = 2.4 kΩ: bridge voltage 5·(0.5 − 2.4/4.6)", abs(vu - 5 * (0.5 - 2.4 / 4.6)) < 1e-4, f"{vu * 1e3:.2f} mV")]
    return build, check


# ---------------------------------------------------------------------------------------------------------------- transients
@lab("bee_rl", G, "RL circuit time constant", {"analysis": "transient", "tstop": 6e-3, "points": 3000, "uic": True},
     "Observe the exponential rise of inductor current and read the time constant τ = L/R.",
     "i(t) = (V/R)(1 − e^(−t/τ)), τ = L/R = 100 mH / 100 Ω = 1 ms. After one τ the current is 63.2 % of its final value V/R = 100 mA.",
     ["Run and open the Waveforms tab: I(L1) rises to 100 mA.", "Double L: τ doubles."], ["What is the inductor voltage just after the switch-on?"])
def _rl():
    def build():
        L = Lab("RL transient")
        v = L.add("vpulse", v1=0.0, v2=10.0, freq=50.0, duty=0.5, edge=0.0002); r = L.add("resistor", R=100.0); l = L.add("inductor", L=0.1)
        L.chain(f"{v}.+", f"{r}.1", f"{r}.2", f"{l}.1"); L.wire(f"{l}.2", f"{v}.−")
        L.gnd(f"{v}.−")
        L.scope(f"{v}.+", f"{l}.1")
        return L.finish()

    def check(prj, res):
        s = res.signals["I(L1)"]; k = np.searchsorted(s.x, 1.0e-3 + 1e-5 * 0 + 0.5e-6)
        k1 = np.searchsorted(s.x, 1e-3 + 1e-5)
        final = s.y[np.searchsorted(s.x, 8e-3 / 2 * 1.0)] if False else 0.1
        return [_c("I(τ) ≈ 63 % of 100 mA", abs(s.y[k1] - 0.0632) < 0.004, f"{s.y[k1] * 1e3:.1f} mA"), _c("Final current → V/R = 100 mA", abs(np.max(s.y) - 0.1) < 0.002, f"{np.max(s.y) * 1e3:.1f} mA")]
    return build, check


# ---------------------------------------------------------------------------------------------------------------- AC: resonance and power
def _ac_f(res):
    return np.asarray(res.info["f"])


@lab("bee_series_rlc", G, "Series RLC resonance", {"analysis": "ac", "fmin": 100.0, "fmax": 5000.0, "fpoints": 400},
     "Sweep the frequency and find the series resonance, where the current peaks at V/R.",
     "f0 = 1/(2π√(LC)) = 503 Hz for 10 mH and 10 µF. At resonance XL = XC, Z = R and I = V/R; the quality factor Q = ωL/R = 3.16.",
     ["Run and open the Waveforms tab (frequency response).", "Change R to 1 Ω: the peak gets taller and narrower (higher Q)."], ["What is the bandwidth for Q = 3.16?"])
def _rlc():
    def build():
        L = Lab("Series RLC")
        v = L.add("vac", amp=1.0, freq=500.0); l = L.add("inductor", L=10e-3); c = L.add("capacitor_ceramic", C=10e-6); r = L.add("resistor", R=10.0)
        L.chain(f"{v}.+", f"{l}.1", f"{l}.2", f"{c}.+"); L.chain(f"{c}.−", f"{r}.1"); L.wire(f"{r}.2", f"{v}.−")
        L.gnd(f"{v}.−")
        return L.finish()

    def check(prj, res):
        f = _ac_f(res); i = np.abs(pin_voltage(res, "R1.1")) / 10.0
        f0 = f[np.argmax(i)]
        return [_c("Peak at f0 = 1/(2π√LC) = 503 Hz (±3 %)", abs(f0 - 503.3) < 15, f"{f0:.0f} Hz"), _c("Peak current = V/R = 100 mA", abs(i.max() - 0.1) < 0.005, f"{i.max() * 1e3:.1f} mA")]
    return build, check


@lab("bee_parallel_rlc", G, "Parallel RLC resonance", {"analysis": "ac", "fmin": 100.0, "fmax": 5000.0, "fpoints": 400},
     "Find the anti-resonance of a parallel L–C tank: the impedance (and the voltage across it) is maximum.",
     "A parallel LC with a 10 kΩ loss resistor resonates at f0 = 1/(2π√(LC)) = 503 Hz where the tank impedance is largest; the source current is smallest.",
     ["Run and read the tank voltage versus frequency.", "Reduce the parallel resistor to 1 kΩ: the peak flattens."], ["Compare with series resonance: where is the current minimum?"])
def _prlc():
    def build():
        L = Lab("Parallel RLC")
        v = L.add("vac", amp=1.0, freq=500.0); rs = L.add("resistor", R=1000.0); l = L.add("inductor", L=10e-3); c = L.add("capacitor_ceramic", C=10e-6); rp = L.add("resistor", R=10000.0)
        L.chain(f"{v}.+", f"{rs}.1", f"{rs}.2", f"{l}.1"); L.wire(f"{l}.1", f"{c}.+", f"{rp}.1"); L.wire(f"{l}.2", f"{c}.−", f"{rp}.2", f"{v}.−")
        L.gnd(f"{v}.−")
        return L.finish()

    def check(prj, res):
        f = _ac_f(res); v = np.abs(pin_voltage(res, "L1.1")); f0 = f[np.argmax(v)]
        return [_c("Peak at 503 Hz (±3 %)", abs(f0 - 503.3) < 15, f"{f0:.0f} Hz"), _c("Peak voltage = 10k/(1k+10k) = 0.909 V", abs(v.max() - 0.909) < 0.01, f"{v.max():.3f} V")]
    return build, check


def _rl_load(C=None):
    L = Lab("AC power")
    v = L.add("vac", amp=10.0, freq=50.0); r = L.add("resistor", R=100.0); l = L.add("inductor", L=0.3)
    L.chain(f"{v}.+", f"{r}.1", f"{r}.2", f"{l}.1"); L.wire(f"{l}.2", f"{v}.−")
    if C:
        c = L.add("capacitor_ceramic", C=C); L.wire(f"{v}.+", f"{c}.+"); L.wire(f"{v}.−", f"{c}.−")
    L.gnd(f"{v}.−")
    L.scope(f"{v}.+", f"{l}.1")
    return L.finish()


def _ac_stats(res, vsrc="V1"):
    t = tvec(res); m = t > t[-1] - 0.04
    v = pin_voltage(res, f"{vsrc}.+")[m]
    i = -res.signals[f"I({vsrc})"].y[m]                      # a source delivering power has negative branch current
    return rms(v), rms(i), float(np.mean(v * i))


@lab("bee_ac_power", G, "AC power and power factor", {"analysis": "transient", "tstop": 0.14, "points": 5600, "uic": True},
     "Measure the RMS voltage and current, real power and power factor of an R–L load on 50 Hz mains-style supply.",
     "|Z| = √(R² + (ωL)²) = 137.4 Ω, I_rms = V_rms/|Z| = 51.5 mA, P = I²R, PF = cos φ = R/|Z| = 0.728 (lagging).",
     ["Run and compare the voltage and current waveforms: the current lags.", "Change L to 0: the power factor becomes 1."], ["Why do utilities charge for reactive power?"])
def _acp():
    def build():
        return _rl_load()

    def check(prj, res):
        v, i, p = _ac_stats(res)
        z = math.hypot(100.0, 2 * math.pi * 50 * 0.3); pf = p / (v * i)
        return [_c("I_rms = 51.5 mA", abs(i - (10 / math.sqrt(2)) / z) < 0.0015, f"{i * 1e3:.2f} mA"), _c("Power factor = R/|Z| = 0.728", abs(pf - 100.0 / z) < 0.02, f"{pf:.3f}"),
                _c("P = I²R", abs(p - i * i * 100.0) < 0.0015, f"{p * 1e3:.1f} mW")]
    return build, check


@lab("bee_pf_correction", G, "Power-factor correction", {"analysis": "transient", "tstop": 0.14, "points": 5600, "uic": True},
     "Add a parallel capacitor to an inductive load to raise the power factor and cut the supply current.",
     "The load admittance is G − jB; a capacitor C = XL/(ω(R²+XL²)) = 15.9 µF cancels the susceptance so the source sees only the conductance: the supply current falls to PF × its old value while the load power is unchanged.",
     ["Run: the supply current is lower than in the previous experiment.", "Remove the capacitor (set C to 0.1 µF) and compare."], ["What happens if the capacitor is too large?"])
def _pfc():
    def build(C=15.9e-6):
        return _rl_load(C)

    def check(prj, res):
        v, i, p = _ac_stats(res); v0, i0, p0 = _ac_stats(run_analog(_rl_load(), analysis="transient", tstop=0.14, points=5600, uic=True))
        return [_c("Supply current drops to ≈ 0.73 × (PF)", abs(i / i0 - 0.728) < 0.03, f"{i * 1e3:.1f} mA vs {i0 * 1e3:.1f} mA"), _c("Real power unchanged", abs(p - p0) / p0 < 0.03, f"{p * 1e3:.1f} vs {p0 * 1e3:.1f} mW"),
                _c("Power factor ≈ 1", p / (v * i) > 0.97, f"{p / (v * i):.3f}")]
    return build, check
