"""Framework for the lab-wise experiments: a tiny netlist-style builder plus an automatic left-to-right schematic layout.

Every experiment is a real drag-and-drop circuit (parts + wires, no breadboard): wires can be moved, parts dragged, values edited, and the
circuit re-run. `check` functions compare the simulated result with the textbook formula, so each experiment states what the right answer is.
"""
from __future__ import annotations
from collections import deque

from ..core import parts
from ..core.model import Project
from ..examples import ex, _c, EXAMPLES, GROUPS                       # noqa: F401  (re-exported for the experiment modules)
from ..sim.analog import run_analog, pin_voltage                      # noqa: F401
from ..sim.digital import run_digital                                  # noqa: F401

LIMIT_LAB = "Ideal wires; component models as listed in the catalogue (no parasitics, no temperature drift). Built without a breadboard so the schematic stays readable."
SOURCES = {"vdc", "vac", "vpulse", "idc", "psu", "clock", "lswitch", "arduino"}


class Lab:
    """Collects parts and wires by name, then lays them out. `add` returns the reference (e.g. 'R1'); pins are written 'R1.2'."""

    def __init__(self, name):
        self.p = Project(name)
        self._gnd = []                                    # (pin, ground ref)

    def add(self, type_, **params):
        return self.p.add_component(type_, 0, 0, params=params).ref

    def wire(self, *pins):
        """Join every pin to the first one."""
        for q in pins[1:]:
            self.p.connect(pins[0], q)

    def chain(self, *pins):
        """Join pins in pairs: (p0, p1), (p2, p3), ... so a series path reads  src.+, R1.1,  R1.2, R2.1,  R2.2, load.1."""
        assert len(pins) % 2 == 0, pins
        for a, b in zip(pins[::2], pins[1::2]):
            self.p.connect(a, b)

    def gnd(self, *pins):
        for pin in pins:
            g = self.add("ground")
            self.p.connect(pin, f"{g}.G")
            self._gnd.append((pin, g))

    def scope(self, ch1, ch2=None):
        """Add an oscilloscope probing the given pins; its GND clip goes to the first ground node."""
        osc = self.add("scope")
        self.wire(f"{osc}.CH1", ch1)
        if ch2:
            self.wire(f"{osc}.CH2", ch2)
        self.wire(f"{osc}.GND", self._gnd[0][0])
        return osc

    def finish(self):
        layout(self.p, self._gnd)
        return self.p


def _extent(d):
    xs = [p.dx for p in d.pins]; ys = [p.dy for p in d.pins]
    if getattr(d, "sprite", None):
        _, ox, oy, w, h = d.sprite
        xs += [-ox / 10, (w - ox) / 10]; ys += [-oy / 10, (h - oy) / 10]
    elif d.symbol in ("box", "gate"):
        xs += [-d.box[0], d.box[0]]; ys += [-d.box[1], d.box[1]]
    else:
        xs += [-1.2, 1.2]; ys += [-1.2, 1.2]
    return min(xs), max(xs), min(ys), max(ys)


def layout(p: Project, gnd_links):
    gref = {g for _, g in gnd_links}
    comps = [c for c in p.components.values() if c.ref not in gref]
    by_ref = {c.ref: c for c in comps}
    adj = {c.ref: set() for c in comps}
    for w in p.wires:
        a, b = p.components[w.a[0]].ref, p.components[w.b[0]].ref
        if a in adj and b in adj and a != b:
            adj[a].add(b); adj[b].add(a)
    layer = {}
    q = deque()
    for c in comps:
        if c.type in SOURCES:
            layer[c.ref] = 0; q.append(c.ref)
    if not q and comps:
        layer[comps[0].ref] = 0; q.append(comps[0].ref)
    while True:
        while q:
            r = q.popleft()
            for n in sorted(adj[r]):
                if n not in layer:
                    layer[n] = layer[r] + 1; q.append(n)
        rest = [c.ref for c in comps if c.ref not in layer]
        if not rest:
            break
        layer[rest[0]] = 0; q.append(rest[0])
    cols = {}
    for c in comps:
        cols.setdefault(layer[c.ref], []).append(c.ref)
    ext = {c.ref: _extent(c.defn) for c in comps}
    row_of = {}
    x_cursor = 0.0
    col_x = {}
    prev_w = 0.0
    for k in sorted(cols):
        refs = cols[k]
        bary = {r: (sum(row_of[n] for n in adj[r] if n in row_of) / max(1, sum(1 for n in adj[r] if n in row_of)) if any(n in row_of for n in adj[r]) else 1e9) for r in refs}
        refs.sort(key=lambda r: (bary[r], r))
        w = max(ext[r][1] - ext[r][0] for r in refs)
        x_cursor += (prev_w + w) / 2 + (9 if k else 0)
        col_x[k] = x_cursor; prev_w = w
        y = 0.0
        pos = {}
        heights = [ext[r][3] - ext[r][2] for r in refs]
        total = sum(heights) + 6 * (len(refs) - 1)
        y = -total / 2
        for r, h in zip(refs, heights):
            pos[r] = y + h / 2; y += h + 6
        for i, r in enumerate(refs):
            row_of[r] = pos[r]
            c = by_ref[r]
            x0, x1, y0, y1 = ext[r]
            c.x = int(round(col_x[k] - (x0 + x1) / 2)) + 6
            c.y = int(round(pos[r] - (y0 + y1) / 2)) + 40
    for pin, g in gnd_links:
        ref, pn = pin.split(".", 1)
        c = by_ref[ref]
        ox, oy = c.pin_offset(pn)
        gc = p.by_ref(g)
        gc.x, gc.y = c.x + ox, c.y + oy + 3
    # keep the whole drawing on positive coordinates
    xs = [c.x for c in p.components.values()]; ys = [c.y for c in p.components.values()]
    dx, dy = 8 - min(xs), 6 - min(ys)
    for c in p.components.values():
        c.x += dx; c.y += dy


def full(prj):
    """Re-run the project with the full-information analog entry point (node voltages by pin name) for the check functions."""
    return run_analog(prj, **prj.sim)


def lab(key, group, title, sim, objective, theory="", steps=(), questions=(), mode="analog"):
    """Register an experiment: the decorated function returns (build, check). mode='analog' hands `check` a full analog result."""
    def deco(fn):
        build, check = fn()

        def chk(prj, res):
            return check(prj, full(prj) if mode == "analog" else res)
        ex(key, group, title, sim, objective, theory, steps, questions, limits=LIMIT_LAB)(lambda: (build, chk))
        return fn
    return deco


def vt(res, pin):
    """Node voltage at 'R1.2' (array for transient / sweep, scalar for op)."""
    return pin_voltage(res, pin)


def run(p, **settings):
    return run_analog(p, **settings)
