"""Electronic Devices Laboratory: diodes, rectifiers and filters, regulators, BJT / FET / thyristor characteristics, photo devices."""
from __future__ import annotations
import numpy as np

from .core import Lab, lab, _c, run_analog, pin_voltage

G = "Electronic Devices Lab"


def tvec(res):
    return next(iter(res.signals.values())).x


def settled(res, frac=0.5):
    t = tvec(res)
    return t > t[0] + (t[-1] - t[0]) * frac


def sweep(res):
    return np.asarray(res.info["sweep"])


# ---------------------------------------------------------------------------------------------------------------- V-I characteristics
@lab("ed_diode_iv", G, "PN junction diode V-I characteristics", {"analysis": "dc_sweep", "sweep_ref": "V1", "sweep_start": -5.0, "sweep_stop": 5.0, "sweep_points": 201},
     "Sweep the supply from −5 V to +5 V and read the diode current: it blocks in reverse and conducts above about 0.6 V.",
     "Shockley equation I = Is(e^(V/nVt) − 1). In forward bias the voltage across a silicon diode stays near 0.65–0.75 V; the 1 kΩ resistor limits the current to (Vs − Vd)/R ≈ 4.3 mA at 5 V.",
     ["Run and open the Waveforms tab: plot I(D1) against the swept voltage V1.", "Find the knee: current becomes visible near 0.6 V.", "Read the reverse leakage at −5 V."],
     ["Why does the voltage across the diode barely change between 1 mA and 4 mA?"])
def _diode_iv():
    def build():
        L = Lab("Diode V-I")
        v = L.add("vdc", V=5.0); r = L.add("resistor", R=1000.0); d = L.add("diode")
        L.chain(f"{v}.+", f"{r}.1", f"{r}.2", f"{d}.A"); L.wire(f"{d}.K", f"{v}.−")
        L.gnd(f"{v}.−")
        return L.finish()

    def check(prj, res):
        vs = sweep(res); vr1, vr2 = pin_voltage(res, "R1.1"), pin_voltage(res, "R1.2")
        i = (vr1 - vr2) / 1000.0; vd = vr2
        k5 = np.argmin(abs(vs - 5.0)); km = np.argmin(abs(vs + 5.0))
        return [_c("Forward at 5 V: Vd between 0.6 and 0.8 V", 0.6 < vd[k5] < 0.8, f"{vd[k5]:.3f} V"), _c("Forward current ≈ (5 − Vd)/1 kΩ", abs(i[k5] - (5 - vd[k5]) / 1000) < 1e-5, f"{i[k5] * 1e3:.2f} mA"),
                _c("Reverse leakage below 1 µA at −5 V", abs(i[km]) < 1e-6, f"{i[km] * 1e9:.2f} nA"), _c("Current at 0.3 V supply is negligible (< 1 µA)", abs(i[np.argmin(abs(vs - 0.3))]) < 1e-6)]
    return build, check


@lab("ed_zener_iv", G, "Zener diode characteristics", {"analysis": "dc_sweep", "sweep_ref": "V1", "sweep_start": -12.0, "sweep_stop": 12.0, "sweep_points": 241},
     "Sweep the supply through ±12 V: the Zener conducts forward like a diode and breaks down in reverse at Vz.",
     "A Zener diode held in reverse breakdown keeps its voltage near Vz (5.1 V) while the current changes widely. The series resistor sets that current: (Vs − Vz)/R.",
     ["Run and plot the diode voltage against V1.", "Locate the breakdown: the diode voltage stops rising at about 5.1 V."], ["Which temperature coefficient do Zeners near 5–6 V have?"])
def _zener_iv():
    def build():
        L = Lab("Zener V-I")
        v = L.add("vdc", V=5.0); r = L.add("resistor", R=330.0); z = L.add("zener")
        L.chain(f"{v}.+", f"{r}.1", f"{r}.2", f"{z}.K"); L.wire(f"{z}.A", f"{v}.−")
        L.gnd(f"{v}.−")
        return L.finish()

    def check(prj, res):
        vs = sweep(res); vz = pin_voltage(res, "R1.2"); vzp = float(prj.components[next(c.id for c in prj.components.values() if c.type == "zener")].params.get("Vz", 5.1))
        k12 = np.argmin(abs(vs - 12.0)); k4 = np.argmin(abs(vs - 4.0)); km = np.argmin(abs(vs + 5.0))
        return [_c("Reverse breakdown: V(Z) at 12 V ≈ Vz", abs(vz[k12] - vzp) < 0.3, f"{vz[k12]:.2f} V (Vz {vzp:g} V)"), _c("Below Vz the Zener blocks: V(Z) ≈ supply at 4 V", abs(vz[k4] - 4.0) < 0.05, f"{vz[k4]:.2f} V"),
                _c("Forward bias drops ≈ −0.7 V", -0.85 < vz[km] < -0.55, f"{vz[km]:.2f} V")]
    return build, check


@lab("ed_led_iv", G, "LED V-I characteristics", {"analysis": "dc_sweep", "sweep_ref": "V1", "sweep_start": 0.0, "sweep_stop": 6.0, "sweep_points": 121},
     "Sweep the supply from 0 to 6 V and see the LED turn on at its forward voltage.",
     "A red LED conducts above about 1.6–1.8 V and then holds ~1.9 V while the current grows; light output follows the current.",
     ["Run and plot the LED current against the supply voltage.", "Replace the LED colour with green or blue in the Inspector and compare the knee."], ["Why is a series resistor always needed?"])
def _led_iv():
    def build():
        L = Lab("LED V-I")
        v = L.add("vdc", V=5.0); r = L.add("resistor", R=330.0); d = L.add("led")
        L.chain(f"{v}.+", f"{r}.1", f"{r}.2", f"{d}.A"); L.wire(f"{d}.K", f"{v}.−")
        L.gnd(f"{v}.−")
        return L.finish()

    def check(prj, res):
        vs = sweep(res); vd = pin_voltage(res, "R1.2"); i = (pin_voltage(res, "R1.1") - vd) / 330.0
        k = np.argmin(abs(vs - 6.0)); k1 = np.argmin(abs(vs - 1.0))
        return [_c("Forward voltage at 6 V supply 1.7–2.1 V", 1.7 < vd[k] < 2.1, f"{vd[k]:.2f} V"), _c("Current ≈ (6 − Vf)/330 ≈ 12 mA", 0.010 < i[k] < 0.014, f"{i[k] * 1e3:.1f} mA"), _c("Dark at 1 V (I < 10 µA)", i[k1] < 1e-5)]
    return build, check


# ---------------------------------------------------------------------------------------------------------------- rectifiers, clippers, clampers
@lab("ed_halfwave", G, "Half-wave rectifier", {"analysis": "transient", "tstop": 0.06, "points": 3000, "uic": True},
     "Rectify a 10 V peak, 50 Hz sine with one diode and measure the DC (average) output.",
     "Only the positive half-cycles pass: V_peak(out) = Vm − Vd ≈ 9.3 V and V_dc ≈ Vm/π ≈ 3.0 V (a bit less because of the diode drop). Ripple frequency = 50 Hz.",
     ["Run and compare input and output in the Waveforms tab.", "Place a 100 µF capacitor across the load to see the filtered DC."], ["What is the peak inverse voltage across the diode?"])
def _hw():
    def build():
        L = Lab("Half-wave rectifier")
        v = L.add("vac", amp=10.0, freq=50.0); d = L.add("diode"); r = L.add("resistor", R=1000.0)
        L.chain(f"{v}.+", f"{d}.A", f"{d}.K", f"{r}.1"); L.wire(f"{r}.2", f"{v}.−")
        L.gnd(f"{v}.−")
        L.scope(f"{v}.+", f"{r}.1")
        return L.finish()

    def check(prj, res):
        vo = pin_voltage(res, "R1.1"); m = settled(res, 0.0)
        return [_c("Peak output = Vm − Vd (9.2–9.5 V)", 9.2 < vo.max() < 9.5, f"{vo.max():.2f} V"), _c("Negative half-cycle blocked (min ≥ −10 mV)", vo.min() > -0.01, f"{vo.min():.4f} V"),
                _c("DC average ≈ Vm/π = 3.0 V (2.7–3.1)", 2.7 < np.mean(vo[m]) < 3.1, f"{np.mean(vo[m]):.2f} V")]
    return build, check


@lab("ed_bridge_filter", G, "Full-wave bridge rectifier with capacitor filter (ripple factor)", {"analysis": "transient", "tstop": 0.4, "points": 8000, "uic": True},
     "Rectify with a four-diode bridge, smooth with a 470 µF capacitor and measure the ripple.",
     "Output ≈ Vm − 2Vd = 10.6 V. Peak-to-peak ripple ≈ I/(2·f·C) = 10.6 mA/(100 Hz · 470 µF) = 0.23 V, ripple factor γ = Vr(rms)/Vdc ≈ Vpp/(2√3·Vdc) ≈ 0.6 %.",
     ["Run and zoom the output: a sawtooth ripple at 100 Hz.", "Halve C to 220 µF: the ripple doubles.", "Remove the capacitor: the output falls to 0 between peaks."], ["Why is the ripple frequency twice the mains frequency?"])
def _bridge():
    def build():
        L = Lab("Bridge rectifier + filter")
        v = L.add("vac", amp=12.0, freq=50.0); d = [L.add("diode") for _ in range(4)]; c = L.add("capacitor", C=470e-6); r = L.add("resistor", R=1000.0)
        L.wire(f"{v}.+", f"{d[0]}.A", f"{d[1]}.K"); L.wire(f"{v}.−", f"{d[2]}.A", f"{d[3]}.K")
        L.wire(f"{d[0]}.K", f"{d[2]}.K", f"{c}.+", f"{r}.1"); L.wire(f"{d[1]}.A", f"{d[3]}.A", f"{c}.−", f"{r}.2")
        L.gnd(f"{d[1]}.A")
        L.scope(f"{r}.1", f"{v}.+")
        return L.finish()

    def check(prj, res):
        vo = pin_voltage(res, "R1.1") - pin_voltage(res, "R1.2"); t = tvec(res); m = t > 0.25
        vdc = np.mean(vo[m]); vpp = np.ptp(vo[m])
        return [_c("Mean output ≈ Vm − 2Vd − ripple/2 (10.2–10.7 V)", 10.2 < vdc < 10.7, f"{vdc:.2f} V"), _c("Ripple ≈ I/(2fC) = 0.23 V p-p (0.15–0.32)", 0.15 < vpp < 0.32, f"{vpp:.3f} V"),
                _c("Ripple factor below 1.5 %", vpp / (2 * np.sqrt(3) * vdc) < 0.015, f"{100 * vpp / (2 * np.sqrt(3) * vdc):.2f} %")]
    return build, check


@lab("ed_clipper", G, "Diode clipper", {"analysis": "transient", "tstop": 0.004, "points": 2000, "uic": True},
     "Clip the positive peaks of a 5 V sine at one diode drop with a shunt diode.",
     "The diode to ground conducts when the input exceeds about 0.7 V, so the output cannot rise above Vd ≈ 0.7 V; the negative half-cycle passes unchanged.",
     ["Run and compare the waveforms.", "Reverse the diode: the negative peaks are clipped instead."], ["How would you clip at 5.7 V instead?"])
def _clip():
    def build():
        L = Lab("Diode clipper")
        v = L.add("vac", amp=5.0, freq=1000.0); r = L.add("resistor", R=1000.0); d = L.add("diode")
        L.chain(f"{v}.+", f"{r}.1", f"{r}.2", f"{d}.A"); L.wire(f"{d}.K", f"{v}.−")
        L.gnd(f"{v}.−")
        L.scope(f"{v}.+", f"{d}.A")
        return L.finish()

    def check(prj, res):
        vo = pin_voltage(res, "R1.2")
        return [_c("Positive peaks clipped at ≈ 0.7 V", 0.6 < vo.max() < 0.85, f"{vo.max():.3f} V"), _c("Negative peak passes (≈ −5 V)", vo.min() < -4.9, f"{vo.min():.2f} V")]
    return build, check


@lab("ed_clamper", G, "Diode clamper (DC restorer)", {"analysis": "transient", "tstop": 0.12, "points": 6000, "uic": True},
     "Shift a 5 V sine upward so that its negative peaks sit at about −0.7 V.",
     "The capacitor charges through the diode to Vm − Vd on the first negative peak and then adds that DC level to the input: the output swings from −0.7 V to 2Vm − 0.7 V = 9.3 V.",
     ["Run and compare the waveforms.", "Reverse the diode: the clamp goes to the positive side."], ["Why is a large RC needed compared with the period?"])
def _clamp():
    def build():
        L = Lab("Diode clamper")
        v = L.add("vac", amp=5.0, freq=50.0); c = L.add("capacitor", C=100e-6); d = L.add("diode"); r = L.add("resistor", R=10000.0)
        L.chain(f"{v}.+", f"{c}.−", f"{c}.+", f"{d}.K"); L.wire(f"{d}.K", f"{r}.1"); L.wire(f"{d}.A", f"{r}.2", f"{v}.−")
        L.gnd(f"{v}.−")
        L.scope(f"{v}.+", f"{d}.K")
        return L.finish()

    def check(prj, res):
        vo = pin_voltage(res, "D1.K"); t = tvec(res); m = t > 0.04
        return [_c("Lowest level clamped at ≈ −0.7 V", -0.95 < vo[m].min() < -0.45, f"{vo[m].min():.2f} V"), _c("Highest level ≈ 2Vm − 0.7 = 9.3 V (9–9.6)", 9.0 < vo[m].max() < 9.6, f"{vo[m].max():.2f} V")]
    return build, check


@lab("ed_diode_logic", G, "Diode AND / OR gates", {"analysis": "op"},
     "Build a diode AND gate and a diode OR gate from two inputs and check all four input combinations.",
     "Diode OR: output = highest input − Vd. Diode AND (pull-up resistor): output = lowest input + Vd. Levels are therefore 0.7 V and 4.3 V instead of 0 and 5 V.",
     ["Change the input batteries between 0 V and 5 V and run each combination."], ["Why can these gates not be cascaded many times?"])
def _dl():
    def build(a=5.0, b=0.0):
        L = Lab("Diode logic")
        va = L.add("vdc", V=a); vb = L.add("vdc", V=b); vcc = L.add("vdc", V=5.0)
        da = L.add("diode"); db = L.add("diode"); r = L.add("resistor", R=4700.0)
        L.wire(f"{va}.+", f"{da}.K"); L.wire(f"{vb}.+", f"{db}.K"); L.wire(f"{da}.A", f"{db}.A", f"{r}.1"); L.chain(f"{vcc}.+", f"{r}.2")
        L.gnd(f"{va}.−", f"{vb}.−", f"{vcc}.−")
        return L.finish()

    def out(a, b):
        return pin_voltage(run_analog(build(a, b), analysis="op"), "R1.1")

    def check(prj, res):
        lo, hi = out(0.0, 0.0), out(5.0, 5.0)
        return [_c("AND: 0·0 and 0·5 give a low (< 0.9 V)", out(0.0, 0.0) < 0.9 and out(0.0, 5.0) < 0.9 and out(5.0, 0.0) < 0.9, f"{lo:.2f} V"), _c("AND: 1·1 gives a high (> 4.5 V)", hi > 4.5, f"{hi:.2f} V")]
    return build, check


# ---------------------------------------------------------------------------------------------------------------- regulation
def _zreg(vin=12.0, rl=1000.0):
    L = Lab("Zener regulator")
    v = L.add("vdc", V=vin); rs = L.add("resistor", R=220.0); z = L.add("zener"); rl_ = L.add("resistor", R=rl)
    L.chain(f"{v}.+", f"{rs}.1", f"{rs}.2", f"{z}.K"); L.wire(f"{z}.K", f"{rl_}.1"); L.wire(f"{z}.A", f"{rl_}.2", f"{v}.−")
    L.gnd(f"{v}.−")
    return L.finish()


@lab("ed_zener_reg", G, "Zener shunt regulator: line and load regulation", {"analysis": "op"},
     "Hold a 5.1 V output while the input and the load change, and measure line and load regulation.",
     "The Zener takes the excess current: Iz = (Vin − Vz)/Rs − Vz/RL. Line regulation = ΔVout/ΔVin; load regulation = ΔVout/ΔIload. Both are small while Iz stays above a few mA.",
     ["Run and read the output voltage.", "Change the input from 10 V to 14 V and note the small change.", "Change the load to 470 Ω."], ["What limits the regulator when the load current rises?"])
def _zr():
    def build():
        return _zreg()

    def vo(vin, rl):
        return pin_voltage(run_analog(_zreg(vin, rl), analysis="op"), "R2.1")

    def check(prj, res):
        v = pin_voltage(res, "R2.1"); a, b = vo(10.0, 1000.0), vo(14.0, 1000.0); c = vo(12.0, 470.0)
        return [_c("Output ≈ Vz (4.8–5.4 V)", 4.8 < v < 5.4, f"{v:.3f} V"), _c("Line regulation: 10 → 14 V input moves Vout < 0.2 V", abs(b - a) < 0.2, f"{(b - a) * 1e3:.0f} mV"),
                _c("Load regulation: 1 kΩ → 470 Ω moves Vout < 0.2 V", abs(c - v) < 0.2, f"{(c - v) * 1e3:.0f} mV")]
    return build, check


# ---------------------------------------------------------------------------------------------------------------- transistors
@lab("ed_bjt_output", G, "BJT output characteristics (common emitter)", {"analysis": "dc_sweep", "sweep_ref": "V1", "sweep_start": 0.0, "sweep_stop": 10.0, "sweep_points": 101},
     "Hold the base current at 20 µA and sweep the collector supply: Ic rises in saturation and then flattens at β·Ib.",
     "In the active region Ic = β·Ib = 100 × 20 µA = 2 mA nearly independent of Vce. At low Vce the transistor saturates and Ic falls.",
     ["Run and plot Ic against the swept supply.", "Change the base current source to 40 µA: the plateau doubles."], ["How would you measure β from this curve?"])
def _bjt_out():
    def build(Ib=20e-6):
        L = Lab("BJT output characteristics")
        v = L.add("vdc", V=5.0); rc = L.add("resistor", R=470.0); q = L.add("npn"); ib = L.add("idc", I=Ib)
        L.chain(f"{v}.+", f"{rc}.1", f"{rc}.2", f"{q}.C"); L.wire(f"{q}.E", f"{v}.−", f"{ib}.−"); L.chain(f"{ib}.+", f"{q}.B")
        L.gnd(f"{v}.−")
        return L.finish()

    def check(prj, res):
        vs = sweep(res); ic = (pin_voltage(res, "R1.1") - pin_voltage(res, "R1.2")) / 470.0
        k1 = np.argmin(abs(vs - 0.5)); k10 = np.argmin(abs(vs - 10.0)); k5 = np.argmin(abs(vs - 5.0))
        return [_c("Plateau Ic ≈ β·Ib = 2 mA (±15 %)", abs(ic[k10] - 2e-3) < 3e-4, f"{ic[k10] * 1e3:.2f} mA"), _c("Flat in the active region (5 V → 10 V changes < 5 %)", abs(ic[k10] - ic[k5]) < 0.05 * ic[k10]),
                _c("Saturation: Ic much lower at Vcc = 0.5 V", ic[k1] < 0.5 * ic[k10], f"{ic[k1] * 1e3:.2f} mA")]
    return build, check


def _bias(kind="divider", bf=100.0):
    L = Lab("BJT bias")
    vcc = L.add("vdc", V=12.0); q = L.add("npn", bf=bf); rc = L.add("resistor", R=2200.0)
    L.chain(f"{vcc}.+", f"{rc}.1", f"{rc}.2", f"{q}.C")
    if kind == "divider":
        r1 = L.add("resistor", R=47000.0); r2 = L.add("resistor", R=10000.0); re = L.add("resistor", R=1000.0)
        L.chain(f"{vcc}.+", f"{r1}.1", f"{r1}.2", f"{q}.B"); L.wire(f"{q}.B", f"{r2}.1"); L.chain(f"{q}.E", f"{re}.1"); L.wire(f"{r2}.2", f"{re}.2", f"{vcc}.−")
    else:
        rb = L.add("resistor", R=560000.0)
        L.chain(f"{vcc}.+", f"{rb}.1", f"{rb}.2", f"{q}.B"); L.wire(f"{q}.E", f"{vcc}.−")
    L.gnd(f"{vcc}.−")
    return L.finish()


@lab("ed_bjt_bias", G, "Transistor biasing: fixed bias vs voltage-divider bias", {"analysis": "op"},
     "Set the Q-point with a voltage-divider (emitter-stabilised) bias and see why it is more stable than fixed bias.",
     "Divider bias: Vb = 12·10/57 = 2.1 V, Ve = Vb − 0.65 = 1.45 V, Ic ≈ Ie = 1.45 mA, Vce = 12 − Ic(Rc+Re) = 7.4 V. Ic hardly depends on β. Fixed bias gives Ic = β·Ib, which is proportional to β.",
     ["Run and read the Q-point.", "Change the transistor's β from 100 to 300 in the Inspector: Ic barely moves.", "Build the fixed-bias variant (Rb 560 kΩ) and repeat."], ["Why does the emitter resistor stabilise Ic?"])
def _bb():
    def build():
        return _bias("divider")

    def ic(kind, bf):
        r = run_analog(_bias(kind, bf), analysis="op")
        return (pin_voltage(r, "R1.1") - pin_voltage(r, "R1.2")) / 2200.0

    def check(prj, res):
        i = (pin_voltage(res, "R1.1") - pin_voltage(res, "R1.2")) / 2200.0; vce = pin_voltage(res, "R1.2") - pin_voltage(res, "R4.1")
        d1, d2 = ic("divider", 100.0), ic("divider", 300.0); f1, f2 = ic("fixed", 100.0), ic("fixed", 300.0)
        return [_c("Ic ≈ 1.4 mA (1.2–1.6)", 1.2e-3 < i < 1.6e-3, f"{i * 1e3:.2f} mA"), _c("Vce ≈ 7.4 V (6.5–8.2)", 6.5 < vce < 8.2, f"{vce:.2f} V"),
                _c("Divider bias: β 100 → 300 changes Ic by < 12 %", abs(d2 - d1) / d1 < 0.12, f"{d1 * 1e3:.2f} → {d2 * 1e3:.2f} mA"), _c("Fixed bias: Ic grows ≥ 2× with β (it saturates)", f2 > 2 * f1 * 0.9 or f2 > 4e-3, f"{f1 * 1e3:.2f} → {f2 * 1e3:.2f} mA")]
    return build, check


@lab("ed_bjt_switch", G, "BJT as a switch", {"analysis": "op"},
     "Drive an LED from a 5 V logic level through an NPN switch; compare ON (saturation) and OFF (cut-off).",
     "With 5 V on a 4.7 kΩ base resistor Ib = 0.9 mA, enough to saturate the transistor (Vce(sat) ≈ 0.1–0.2 V) so the LED carries (5 − 1.9 − 0.15)/330 ≈ 9 mA. With 0 V in, the transistor is cut off and the LED is dark.",
     ["Run with 5 V input: the LED glows.", "Set the input battery to 0 V and run again."], ["Why do we say the transistor is 'saturated'?"])
def _bsw():
    def build(vin=5.0):
        L = Lab("BJT switch")
        vcc = L.add("vdc", V=5.0); vi = L.add("vdc", V=vin); rb = L.add("resistor", R=4700.0); q = L.add("npn"); rl = L.add("resistor", R=330.0); d = L.add("led")
        L.chain(f"{vi}.+", f"{rb}.1", f"{rb}.2", f"{q}.B"); L.chain(f"{vcc}.+", f"{rl}.1", f"{rl}.2", f"{d}.A", f"{d}.K", f"{q}.C"); L.wire(f"{q}.E", f"{vcc}.−", f"{vi}.−")
        L.gnd(f"{vcc}.−")
        return L.finish()

    def check(prj, res):
        i = res.m("I(R2)"); vce = pin_voltage(res, "D1.K")
        off = run_analog(build(0.0), analysis="op")
        return [_c("ON: LED current 8–10 mA", 0.008 < i < 0.0105, f"{i * 1e3:.2f} mA"), _c("ON: Vce(sat) < 0.3 V", vce < 0.3, f"{vce:.3f} V"), _c("OFF: LED current < 1 µA", abs(off.m("I(R2)")) < 1e-6, f"{off.m('I(R2)') * 1e9:.2f} nA")]
    return build, check


@lab("ed_mosfet", G, "MOSFET transfer characteristic", {"analysis": "dc_sweep", "sweep_ref": "V2", "sweep_start": 0.0, "sweep_stop": 5.0, "sweep_points": 101},
     "Sweep the gate voltage of a 2N7000 and observe the threshold: no drain current until Vgs exceeds Vto.",
     "An enhancement MOSFET stays off below the threshold voltage Vto (about 2 V) and conducts above it with Id ≈ β/2·(Vgs − Vto)² in saturation.",
     ["Run and plot the drain current against the gate voltage V2.", "Find where Id first exceeds 1 mA."], ["What is the difference between enhancement and depletion devices?"])
def _mos():
    def build():
        L = Lab("MOSFET transfer")
        vdd = L.add("vdc", V=5.0); vg = L.add("vdc", V=2.5); rd = L.add("resistor", R=100.0); q = L.add("2n7000")
        L.chain(f"{vdd}.+", f"{rd}.1", f"{rd}.2", f"{q}.D"); L.chain(f"{vg}.+", f"{q}.G"); L.wire(f"{q}.S", f"{vdd}.−", f"{vg}.−")
        L.gnd(f"{vdd}.−")
        return L.finish()

    def check(prj, res):
        vg = sweep(res); i = (pin_voltage(res, "R1.1") - pin_voltage(res, "R1.2")) / 100.0
        k1 = np.argmin(abs(vg - 1.0)); k5 = np.argmin(abs(vg - 5.0)); on = vg[np.argmax(i > 1e-3)]
        return [_c("Off below threshold (Id < 1 µA at Vgs = 1 V)", i[k1] < 1e-6, f"{i[k1] * 1e9:.1f} nA"), _c("On at Vgs = 5 V (> 20 mA)", i[k5] > 0.02, f"{i[k5] * 1e3:.1f} mA"),
                _c("Drain current rises monotonically", bool(np.all(np.diff(i) > -1e-9))), _c("1 mA reached between 2 and 3.2 V", 2.0 < on < 3.2, f"{on:.2f} V")]
    return build, check


@lab("ed_jfet", G, "JFET transfer characteristic", {"analysis": "dc_sweep", "sweep_ref": "V2", "sweep_start": -2.0, "sweep_stop": 0.0, "sweep_points": 81},
     "Sweep the gate-source voltage of a J201 from −2 V to 0 V: Id falls from Idss to zero at pinch-off.",
     "A depletion-mode JFET conducts at Vgs = 0 (Idss) and is pinched off at Vgs = Vto (about −0.8 V). In saturation Id = Idss(1 − Vgs/Vto)².",
     ["Run and plot Id against V2.", "Find the pinch-off voltage where Id → 0."], ["Why does a JFET have a very high input resistance?"])
def _jfet():
    def build():
        L = Lab("JFET transfer")
        vdd = L.add("vdc", V=10.0); vg = L.add("vdc", V=-1.0); rd = L.add("resistor", R=1000.0); q = L.add("j201")
        L.chain(f"{vdd}.+", f"{rd}.1", f"{rd}.2", f"{q}.D"); L.chain(f"{vg}.+", f"{q}.G"); L.wire(f"{q}.S", f"{vdd}.−", f"{vg}.−")
        L.gnd(f"{vdd}.−")
        return L.finish()

    def check(prj, res):
        vg = sweep(res); i = (pin_voltage(res, "R1.1") - pin_voltage(res, "R1.2")) / 1000.0
        return [_c("Conducts at Vgs = 0 (Idss > 0.2 mA)", i[-1] > 2e-4, f"{i[-1] * 1e3:.2f} mA"), _c("Pinched off at −2 V (Id < 1 µA)", i[0] < 1e-6, f"{i[0] * 1e9:.1f} nA"),
                _c("Id increases monotonically with Vgs", bool(np.all(np.diff(i) > -1e-9)))]
    return build, check


@lab("ed_scr", G, "SCR (thyristor) latching", {"analysis": "transient", "tstop": 0.03, "points": 3000, "uic": True},
     "Trigger an SCR with a short gate pulse and see it stay on after the gate returns to zero.",
     "Once the anode current exceeds the latching/holding current, the SCR stays conducting until the anode current drops below the holding current. A 1 ms pulse at t = 3 ms switches on 120 mA of load current for the rest of the run.",
     ["Run and compare the gate pulse with the load current.", "Reduce the supply to 1 V: the SCR cannot latch."], ["How is a SCR turned off in a DC circuit?"])
def _scr():
    def build():
        L = Lab("SCR latching")
        v = L.add("vdc", V=12.0); rl = L.add("resistor", R=100.0); q = L.add("2n5064"); g = L.add("vpulse", v1=0.0, v2=5.0, freq=40.0, duty=0.04, delay=0.003, edge=0.01); rg = L.add("resistor", R=220.0)
        L.chain(f"{v}.+", f"{rl}.1", f"{rl}.2", f"{q}.A"); L.chain(f"{g}.+", f"{rg}.1", f"{rg}.2", f"{q}.G"); L.wire(f"{q}.K", f"{v}.−", f"{g}.−")
        L.gnd(f"{v}.−")
        L.scope(f"{g}.+", f"{rl}.2")
        return L.finish()

    def check(prj, res):
        t = tvec(res); i = (pin_voltage(res, "R1.1") - pin_voltage(res, "R1.2")) / 100.0
        k0 = np.searchsorted(t, 0.002); k1 = np.searchsorted(t, 0.015)
        return [_c("Off before the gate pulse", abs(i[k0]) < 1e-3, f"{i[k0] * 1e3:.2f} mA"), _c("On and latched after the pulse (≈ 110–120 mA at 15 ms)", 0.09 < i[k1] < 0.125, f"{i[k1] * 1e3:.1f} mA")]
    return build, check


# ---------------------------------------------------------------------------------------------------------------- photo devices
@lab("ed_ldr", G, "LDR response to light", {"analysis": "op"},
     "Use a light-dependent resistor in a divider: more light → lower resistance → higher output voltage.",
     "R(LDR) falls roughly as lux^−γ. In a divider with a 10 kΩ resistor the output rises from a few tenths of a volt in the dark to several volts in bright light.",
     ["Change the LDR 'lux' parameter (1, 10, 100, 1000) in the Inspector and run each time."], ["Why is an LDR slow compared with a photodiode?"])
def _ldr():
    def build(lux=100.0):
        L = Lab("LDR divider")
        v = L.add("vdc", V=5.0); r = L.add("resistor", R=10000.0); l = L.add("ldr", lux=lux)
        L.chain(f"{v}.+", f"{l}.A", f"{l}.B", f"{r}.1"); L.wire(f"{r}.2", f"{v}.−")
        L.gnd(f"{v}.−")
        return L.finish()

    def check(prj, res):
        vs = [pin_voltage(run_analog(build(x), analysis="op"), "R1.1") for x in (1.0, 10.0, 100.0, 1000.0)]
        return [_c("Output rises with light level", all(b > a for a, b in zip(vs, vs[1:])), " < ".join(f"{x:.2f} V" for x in vs)), _c("Bright light gives more than 3.5 V", vs[-1] > 3.5)]
    return build, check


@lab("ed_photodiode", G, "Photodiode under illumination", {"analysis": "op"},
     "Reverse-bias a BPW34 photodiode: the photocurrent is proportional to the irradiance.",
     "In reverse bias the photodiode passes I = S·E (sensitivity × irradiance) plus a tiny dark current. With 10 kΩ in series the output voltage is I·R.",
     ["Change the irradiance E (mW/cm²) in the Inspector: 1, 2, 5 and run."], ["Why is photodiode current more linear than LDR resistance?"])
def _pd():
    def build(E=1.0):
        L = Lab("Photodiode")
        v = L.add("vdc", V=5.0); r = L.add("resistor", R=10000.0); d = L.add("bpw34", E=E)
        L.chain(f"{v}.+", f"{d}.K", f"{d}.A", f"{r}.1"); L.wire(f"{r}.2", f"{v}.−")
        L.gnd(f"{v}.−")
        return L.finish()

    def vo(e):
        return pin_voltage(run_analog(build(e), analysis="op"), "R1.1")

    def check(prj, res):
        a, b, c = vo(1.0), vo(2.0), vo(5.0)
        return [_c("Photocurrent proportional to E (2× light → 2× voltage)", abs(b / a - 2.0) < 0.05, f"{a * 1e3:.1f} → {b * 1e3:.1f} mV"), _c("5× light → 5× voltage", abs(c / a - 5.0) < 0.1, f"{c * 1e3:.1f} mV")]
    return build, check
