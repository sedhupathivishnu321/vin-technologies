"""Digital System Design Laboratory: gates, universal gates, adders, multiplexer, decoder, flip-flops, counters, shift registers, sequence detection.

Inputs are logic switches that step through a bit pattern once per second; outputs are logic probes. Clocked circuits use a 1 Hz clock (rising edges at 0.5 s, 1.5 s, ...),
so the output after edge k is read at k + 0.75 s.
"""
from __future__ import annotations
import itertools

import numpy as np

from .core import Lab, lab, _c

G = "Digital Systems Lab"


def val(res, name, t):
    s = res.signals[name]
    k = int(np.searchsorted(s.x, t + 1e-9, side="right")) - 1
    return int(round(float(s.y[max(k, 0)])))


def vec(res, names, t):
    return [val(res, n, t) for n in names]


def patterns(n_bits):
    """Bit patterns for n_bits switches stepping through all 2^n combinations (MSB switch changes slowest)."""
    rows = list(itertools.product((0, 1), repeat=n_bits))
    return ["".join(str(r[i]) for r in rows) for i in range(n_bits)], rows


def switches(L, pats, step=1.0):
    return [L.add("lswitch", pattern=p, step=step) for p in pats]


def probes(L, *pins):
    out = []
    for pin in pins:
        p = L.add("lprobe"); L.wire(pin, f"{p}.IN"); out.append(p)
    return out


def _table(res, ins, outs, rows, expect, label):
    bad = []
    for k, bits in enumerate(rows):
        got = vec(res, outs, k + 0.5); want = expect(bits)
        if got != want:
            bad.append(f"{bits}→{got} (want {want})")
    return _c(label, not bad, "; ".join(bad[:3]) or f"all {len(rows)} rows correct")


# ---------------------------------------------------------------------------------------------------------------- gates
@lab("dg_gates", G, "Truth tables of the basic gates", {"analysis": "digital", "tstop": 4.0}, "Apply all four input combinations to AND, OR, NAND, NOR, XOR and XNOR gates and read their truth tables on the probes.",
     "AND = A·B, OR = A+B, NAND = (A·B)', NOR = (A+B)', XOR = A⊕B (1 when the inputs differ), XNOR = (A⊕B)'.",
     ["Run: the switches step through 00, 01, 10, 11 once per second; read each probe.", "Change a switch's pattern to repeat a combination."], ["Which gate outputs 1 only when both inputs are 1?"], mode="raw")
def _gates():
    def build():
        L = Lab("Gate truth tables")
        pats, _ = patterns(2); a, b = switches(L, pats)
        for t in ("and", "or", "nand", "nor", "xor", "xnor"):
            g = L.add(t); L.chain(f"{a}.OUT", f"{g}.A", f"{b}.OUT", f"{g}.B"); probes(L, f"{g}.Y")
        return L.finish()

    def check(prj, res):
        _, rows = patterns(2)
        fns = [lambda a, b: a & b, lambda a, b: a | b, lambda a, b: 1 - (a & b), lambda a, b: 1 - (a | b), lambda a, b: a ^ b, lambda a, b: 1 - (a ^ b)]
        return [_table(res, None, [f"PR{i + 1}"], rows, lambda bits, f=f: [f(*bits)], n) for i, (f, n) in enumerate(zip(fns, ("AND", "OR", "NAND", "NOR", "XOR", "XNOR")))]
    return build, check


def _universal(kind):
    L = Lab(f"{kind.upper()} universal")
    pats, _ = patterns(2); a, b = switches(L, pats)
    g = lambda: L.add(kind)
    n1 = g(); L.chain(f"{a}.OUT", f"{n1}.A", f"{a}.OUT", f"{n1}.B")                         # NOT A
    n2 = g(); L.chain(f"{b}.OUT", f"{n2}.A", f"{b}.OUT", f"{n2}.B")                         # NOT B
    m = g(); L.chain(f"{a}.OUT", f"{m}.A", f"{b}.OUT", f"{m}.B")                            # NAND(A,B) / NOR(A,B)
    x = g(); L.chain(f"{m}.Y", f"{x}.A", f"{m}.Y", f"{x}.B")                                # AND via NAND, OR via NOR
    y = g(); L.chain(f"{n1}.Y", f"{y}.A", f"{n2}.Y", f"{y}.B")                              # OR via NAND, AND via NOR
    probes(L, f"{n1}.Y", f"{x}.Y", f"{y}.Y")
    return L.finish()


@lab("dg_nand_universal", G, "NAND as a universal gate", {"analysis": "digital", "tstop": 4.0}, "Build NOT, AND and OR from NAND gates only and verify their truth tables.",
     "NOT A = NAND(A, A). AND = NOT(NAND(A, B)). OR = NAND(NOT A, NOT B) by De Morgan. Every Boolean function can be built from NAND gates alone.",
     ["Run and read the three probes (NOT A, A·B, A+B)."], ["Why are NAND gates cheap to build in CMOS?"], mode="raw")
def _nand_u():
    def build():
        return _universal("nand")

    def check(prj, res):
        _, rows = patterns(2)
        return [_table(res, None, ["PR1", "PR2", "PR3"], rows, lambda b: [1 - b[0], b[0] & b[1], b[0] | b[1]], "NOT A, A·B and A+B from NAND gates")]
    return build, check


@lab("dg_nor_universal", G, "NOR as a universal gate", {"analysis": "digital", "tstop": 4.0}, "Build NOT, OR and AND from NOR gates only and verify their truth tables.",
     "NOT A = NOR(A, A). OR = NOT(NOR(A, B)). AND = NOR(NOT A, NOT B).",
     ["Run and read the three probes (NOT A, A+B, A·B)."], ["What is the dual of NAND universality?"], mode="raw")
def _nor_u():
    def build():
        return _universal("nor")

    def check(prj, res):
        _, rows = patterns(2)
        return [_table(res, None, ["PR1", "PR2", "PR3"], rows, lambda b: [1 - b[0], b[0] | b[1], b[0] & b[1]], "NOT A, A+B and A·B from NOR gates")]
    return build, check


@lab("dg_parity", G, "4-bit even-parity generator", {"analysis": "digital", "tstop": 16.0}, "Generate an even-parity bit with an XOR tree: the parity output makes the total number of 1s even.",
     "P = D3 ⊕ D2 ⊕ D1 ⊕ D0. The data plus parity always contain an even number of ones, so a single-bit error is detectable.",
     ["Run through all 16 data words and read P."], ["How does the receiver check parity?"], mode="raw")
def _par():
    def build():
        L = Lab("Parity generator")
        pats, _ = patterns(4); d = switches(L, pats)
        x1 = L.add("xor"); x2 = L.add("xor"); x3 = L.add("xor")
        L.chain(f"{d[0]}.OUT", f"{x1}.A", f"{d[1]}.OUT", f"{x1}.B", f"{d[2]}.OUT", f"{x2}.A", f"{d[3]}.OUT", f"{x2}.B", f"{x1}.Y", f"{x3}.A", f"{x2}.Y", f"{x3}.B")
        probes(L, f"{x3}.Y")
        return L.finish()

    def check(prj, res):
        _, rows = patterns(4)
        return [_table(res, None, ["PR1"], rows, lambda b: [sum(b) % 2], "P = XOR of the four data bits (even parity)")]
    return build, check


@lab("dg_gray", G, "Binary to Gray code converter", {"analysis": "digital", "tstop": 8.0}, "Convert a 3-bit binary number to Gray code with two XOR gates.",
     "G2 = B2, G1 = B2 ⊕ B1, G0 = B1 ⊕ B0. Consecutive Gray codes differ in exactly one bit.",
     ["Run through 000 … 111 and note that only one Gray bit changes per step."], ["Where is Gray code used?"], mode="raw")
def _gray():
    def build():
        L = Lab("Binary to Gray")
        pats, _ = patterns(3); b = switches(L, pats)
        x1 = L.add("xor"); x0 = L.add("xor")
        L.chain(f"{b[0]}.OUT", f"{x1}.A", f"{b[1]}.OUT", f"{x1}.B", f"{b[1]}.OUT", f"{x0}.A", f"{b[2]}.OUT", f"{x0}.B")
        probes(L, f"{b[0]}.OUT", f"{x1}.Y", f"{x0}.Y")
        return L.finish()

    def check(prj, res):
        _, rows = patterns(3)
        ok = _table(res, None, ["PR1", "PR2", "PR3"], rows, lambda r: [r[0], r[0] ^ r[1], r[1] ^ r[2]], "Gray code = B ⊕ (B >> 1)")
        seq = [tuple(vec(res, ["PR1", "PR2", "PR3"], k + 0.5)) for k in range(8)]
        one = all(sum(x != y for x, y in zip(seq[k], seq[k + 1])) == 1 for k in range(7))
        return [ok, _c("Only one bit changes between neighbouring codes", one)]
    return build, check


@lab("dg_comparator", G, "2-bit magnitude comparator", {"analysis": "digital", "tstop": 16.0}, "Compare two 2-bit numbers with gates and read A>B, A=B and A<B.",
     "A=B when both bit pairs are equal (XNOR · XNOR). A>B when A1·B1' or (A1 ≡ B1)·A0·B0'. A<B is the mirror image.",
     ["Run through all 16 input pairs and watch the three outputs."], ["How is it extended to 4 or 8 bits?"], mode="raw")
def _cmp():
    def build():
        L = Lab("2-bit comparator")
        pats, _ = patterns(4); a1, a0, b1, b0 = switches(L, pats)
        e1 = L.add("xnor"); e0 = L.add("xnor"); eq = L.add("and")
        L.chain(f"{a1}.OUT", f"{e1}.A", f"{b1}.OUT", f"{e1}.B", f"{a0}.OUT", f"{e0}.A", f"{b0}.OUT", f"{e0}.B", f"{e1}.Y", f"{eq}.A", f"{e0}.Y", f"{eq}.B")
        nb1 = L.add("not"); nb0 = L.add("not"); na1 = L.add("not"); na0 = L.add("not")
        L.chain(f"{b1}.OUT", f"{nb1}.A", f"{b0}.OUT", f"{nb0}.A", f"{a1}.OUT", f"{na1}.A", f"{a0}.OUT", f"{na0}.A")
        g1 = L.add("and"); g0a = L.add("and"); g0 = L.add("and"); gt = L.add("or")
        L.chain(f"{a1}.OUT", f"{g1}.A", f"{nb1}.Y", f"{g1}.B", f"{a0}.OUT", f"{g0a}.A", f"{nb0}.Y", f"{g0a}.B", f"{e1}.Y", f"{g0}.A", f"{g0a}.Y", f"{g0}.B", f"{g1}.Y", f"{gt}.A", f"{g0}.Y", f"{gt}.B")
        l1 = L.add("and"); l0a = L.add("and"); l0 = L.add("and"); lt = L.add("or")
        L.chain(f"{b1}.OUT", f"{l1}.A", f"{na1}.Y", f"{l1}.B", f"{b0}.OUT", f"{l0a}.A", f"{na0}.Y", f"{l0a}.B", f"{e1}.Y", f"{l0}.A", f"{l0a}.Y", f"{l0}.B", f"{l1}.Y", f"{lt}.A", f"{l0}.Y", f"{lt}.B")
        probes(L, f"{gt}.Y", f"{eq}.Y", f"{lt}.Y")
        return L.finish()

    def check(prj, res):
        _, rows = patterns(4)
        return [_table(res, None, ["PR1", "PR2", "PR3"], rows, lambda b: [int(b[0] * 2 + b[1] > b[2] * 2 + b[3]), int(b[0] * 2 + b[1] == b[2] * 2 + b[3]), int(b[0] * 2 + b[1] < b[2] * 2 + b[3])], "A>B, A=B, A<B for all 16 pairs")]
    return build, check


# ---------------------------------------------------------------------------------------------------------------- arithmetic and data selection
@lab("dg_half_adder", G, "Half adder (gates)", {"analysis": "digital", "tstop": 4.0}, "Add two bits with an XOR gate (sum) and an AND gate (carry).",
     "SUM = A ⊕ B and CARRY = A · B. 1 + 1 = 10 in binary: sum 0, carry 1.",
     ["Run through the four input combinations and read SUM and CARRY."], ["Why can a half adder not be chained?"], mode="raw")
def _ha():
    def build():
        L = Lab("Half adder")
        pats, _ = patterns(2); a, b = switches(L, pats)
        x = L.add("xor"); n = L.add("and")
        L.chain(f"{a}.OUT", f"{x}.A", f"{b}.OUT", f"{x}.B", f"{a}.OUT", f"{n}.A", f"{b}.OUT", f"{n}.B")
        probes(L, f"{x}.Y", f"{n}.Y")
        return L.finish()

    def check(prj, res):
        _, rows = patterns(2)
        return [_table(res, None, ["PR1", "PR2"], rows, lambda b: [b[0] ^ b[1], b[0] & b[1]], "SUM = A⊕B, CARRY = A·B")]
    return build, check


@lab("dg_full_adder", G, "Full adder", {"analysis": "digital", "tstop": 8.0}, "Add two bits and a carry-in; verify SUM and COUT against binary addition for all 8 input combinations.",
     "SUM = A ⊕ B ⊕ CIN and COUT = majority(A, B, CIN). The pair (COUT, SUM) is the binary number A + B + CIN.",
     ["Run through all 8 combinations."], ["How do you build a 4-bit adder from full adders?"], mode="raw")
def _fa():
    def build():
        L = Lab("Full adder")
        pats, _ = patterns(3); a, b, c = switches(L, pats); f = L.add("fadd")
        L.chain(f"{a}.OUT", f"{f}.A", f"{b}.OUT", f"{f}.B", f"{c}.OUT", f"{f}.CI")
        probes(L, f"{f}.S", f"{f}.CO")
        return L.finish()

    def check(prj, res):
        _, rows = patterns(3)
        return [_table(res, None, ["PR1", "PR2"], rows, lambda b: [sum(b) & 1, sum(b) >> 1], "(COUT, SUM) = A + B + CIN")]
    return build, check


@lab("dg_adder4", G, "4-bit ripple-carry adder", {"analysis": "digital", "tstop": 4.0}, "Chain four full adders and add 7 + 5, 9 + 9, 15 + 1 and 6 + 3 (one per second).",
     "The carry ripples from bit 0 to bit 3: S = A + B (5 bits including the final carry C4). The delay grows with every stage.",
     ["Run and read S3…S0 and C4 for each of the four additions."], ["What limits the speed of a ripple-carry adder?"], mode="raw")
def _add4():
    A = [7, 9, 15, 6]; B = [5, 9, 1, 3]

    def pat(vals, bit):
        return "".join(str((v >> bit) & 1) for v in vals)

    def build():
        L = Lab("4-bit adder")
        a = [L.add("lswitch", pattern=pat(A, i), step=1.0) for i in range(4)]; b = [L.add("lswitch", pattern=pat(B, i), step=1.0) for i in range(4)]
        f = [L.add("fadd") for _ in range(4)]; c0 = L.add("lswitch", value=0)
        L.chain(f"{c0}.OUT", f"{f[0]}.CI")
        for i in range(4):
            L.chain(f"{a[i]}.OUT", f"{f[i]}.A", f"{b[i]}.OUT", f"{f[i]}.B")
            if i:
                L.chain(f"{f[i - 1]}.CO", f"{f[i]}.CI")
        probes(L, *[f"{f[i]}.S" for i in range(4)], f"{f[3]}.CO")
        return L.finish()

    def check(prj, res):
        bad = []
        for k in range(4):
            got = sum(v << i for i, v in enumerate(vec(res, ["PR1", "PR2", "PR3", "PR4", "PR5"], k + 0.5)))
            if got != A[k] + B[k]:
                bad.append(f"{A[k]}+{B[k]}={got}")
        return [_c("7+5=12, 9+9=18, 15+1=16, 6+3=9", not bad, ", ".join(bad) or "all four sums correct")]
    return build, check


@lab("dg_mux41", G, "4:1 multiplexer from 2:1 multiplexers", {"analysis": "digital", "tstop": 4.0}, "Select one of four data inputs (1, 0, 1, 1) with a two-bit select code, using three 2:1 multiplexers.",
     "Y = D[S1 S0]. The first rank of two multiplexers chooses between (D0, D1) and (D2, D3) with S0; the second rank chooses between the results with S1.",
     ["Run: the select lines count 00, 01, 10, 11 and the output follows D0 … D3."], ["How would you implement any 3-input function with an 8:1 mux?"], mode="raw")
def _mux():
    D = [1, 0, 1, 1]

    def build():
        L = Lab("4:1 multiplexer")
        s1 = L.add("lswitch", pattern="0011", step=1.0); s0 = L.add("lswitch", pattern="0101", step=1.0)
        d = [L.add("lswitch", value=v) for v in D]; m0 = L.add("mux2"); m1 = L.add("mux2"); m2 = L.add("mux2")
        L.chain(f"{d[0]}.OUT", f"{m0}.A", f"{d[1]}.OUT", f"{m0}.B", f"{d[2]}.OUT", f"{m1}.A", f"{d[3]}.OUT", f"{m1}.B", f"{s0}.OUT", f"{m0}.S", f"{s0}.OUT", f"{m1}.S",
                f"{m0}.Y", f"{m2}.A", f"{m1}.Y", f"{m2}.B", f"{s1}.OUT", f"{m2}.S")
        probes(L, f"{m2}.Y")
        return L.finish()

    def check(prj, res):
        return [_c("Y = D[S1 S0] = 1, 0, 1, 1", [val(res, "PR1", k + 0.5) for k in range(4)] == D, str([val(res, "PR1", k + 0.5) for k in range(4)]))]
    return build, check


@lab("dg_decoder24", G, "2-to-4 line decoder", {"analysis": "digital", "tstop": 4.0}, "Decode a two-bit code into one-hot outputs with NOT and AND gates.",
     "Y0 = A'B', Y1 = A'B, Y2 = AB', Y3 = AB: exactly one output is high for each input code.",
     ["Run and watch one output at a time go high."], ["How is a 3-to-8 decoder used for memory addressing?"], mode="raw")
def _dec():
    def build():
        L = Lab("2-to-4 decoder")
        a = L.add("lswitch", pattern="0011", step=1.0); b = L.add("lswitch", pattern="0101", step=1.0); na = L.add("not"); nb = L.add("not")
        L.chain(f"{a}.OUT", f"{na}.A", f"{b}.OUT", f"{nb}.A")
        ins = [(f"{na}.Y", f"{nb}.Y"), (f"{na}.Y", f"{b}.OUT"), (f"{a}.OUT", f"{nb}.Y"), (f"{a}.OUT", f"{b}.OUT")]
        for x, y in ins:
            g = L.add("and"); L.chain(x, f"{g}.A", y, f"{g}.B"); probes(L, f"{g}.Y")
        return L.finish()

    def check(prj, res):
        _, rows = patterns(2)
        return [_table(res, None, ["PR1", "PR2", "PR3", "PR4"], rows, lambda b: [int(b[0] * 2 + b[1] == i) for i in range(4)], "One-hot outputs for codes 00…11")]
    return build, check


# ---------------------------------------------------------------------------------------------------------------- flip-flops, counters, registers
@lab("dg_dff", G, "D flip-flop", {"analysis": "digital", "tstop": 8.0}, "Show that a D flip-flop samples D on the rising clock edge and holds it in between.",
     "Q takes the value of D present at each rising edge and holds it until the next. Changes of D between edges have no effect.",
     ["Run: D = 0 1 1 0 1 0 0 1; the clock rises at 0.5 s, 1.5 s, …", "Compare Q with D just before each edge."], ["What is set-up time?"], mode="raw")
def _dff():
    P = "01101001"

    def build():
        L = Lab("D flip-flop")
        d = L.add("lswitch", pattern=P, step=1.0); c = L.add("clock", freq=1.0); f = L.add("dff"); L.chain(f"{d}.OUT", f"{f}.D", f"{c}.OUT", f"{f}.CLK")
        probes(L, f"{f}.Q", f"{d}.OUT", f"{c}.OUT")
        return L.finish()

    def check(prj, res):
        got = [val(res, "PR1", k + 0.75) for k in range(8)]
        return [_c("Q after edge k equals D at edge k", got == [int(x) for x in P], str(got))]
    return build, check


@lab("dg_jk", G, "JK flip-flop (hold, set, reset, toggle)", {"analysis": "digital", "tstop": 8.0}, "Step a JK flip-flop through hold, set, reset and toggle on successive clock edges.",
     "JK = 00 hold, 10 set, 01 reset, 11 toggle. Starting from Q = 0 the sequence 00, 10, 01, 11 gives Q = 0, 1, 0, 1; the next 00 holds Q = 1.",
     ["Run and compare Q with the J and K patterns at each clock edge."], ["What is the race-around condition?"], mode="raw")
def _jk():
    def build():
        L = Lab("JK flip-flop")
        j = L.add("lswitch", pattern="01010101", step=1.0); k = L.add("lswitch", pattern="00110011", step=1.0); c = L.add("clock", freq=1.0); f = L.add("jkff")
        L.chain(f"{j}.OUT", f"{f}.J", f"{k}.OUT", f"{f}.K", f"{c}.OUT", f"{f}.CLK")
        probes(L, f"{f}.Q", f"{j}.OUT", f"{k}.OUT")
        return L.finish()

    def check(prj, res):
        got = [val(res, "PR1", k + 0.75) for k in range(8)]
        return [_c("Q = 0, 1, 0, 1 for JK = 00, 10, 01, 11; second round starts with hold (Q stays 1)", got == [0, 1, 0, 1, 1, 1, 0, 1], str(got))]
    return build, check


@lab("dg_counter4", G, "4-bit binary counter", {"analysis": "digital", "tstop": 17.0}, "Count 16 clock pulses with a 4-bit synchronous counter and read the binary count on four probes.",
     "Q0 toggles every clock, Q1 every 2nd, Q2 every 4th, Q3 every 8th: the outputs count 0000 … 1111 and wrap round. Each output is the clock divided by 2, 4, 8, 16.",
     ["Run and read Q3 Q2 Q1 Q0 after each rising edge."], ["What is the modulus of this counter?"], mode="raw")
def _ctr():
    def build():
        L = Lab("4-bit counter")
        c = L.add("clock", freq=1.0); n = L.add("counter4"); r = L.add("lswitch", value=0)
        L.chain(f"{c}.OUT", f"{n}.CLK", f"{r}.OUT", f"{n}.R")
        probes(L, f"{n}.Q0", f"{n}.Q1", f"{n}.Q2", f"{n}.Q3")
        return L.finish()

    def check(prj, res):
        bad = [k for k in range(16) if sum(v << i for i, v in enumerate(vec(res, ["PR1", "PR2", "PR3", "PR4"], k + 0.75))) != (k + 1) % 16]
        return [_c("Count after edge k = (k + 1) mod 16", not bad, str(bad))]
    return build, check


@lab("dg_mod6", G, "Mod-6 counter (asynchronous reset)", {"analysis": "digital", "tstop": 14.0}, "Make a counter that counts 0–5 by resetting a 4-bit counter as soon as it reaches 6.",
     "When the count becomes 6 (0110) the AND gate Q2·Q1 raises RESET and clears the counter immediately, so state 6 only exists as a very short glitch. The sequence is 0, 1, 2, 3, 4, 5, 0, …",
     ["Run and read the count after each rising edge.", "Use Q3·Q1 instead to build a mod-10 (decade) counter."], ["Why is the glitch on state 6 a drawback?"], mode="raw")
def _mod6():
    def build():
        L = Lab("Mod-6 counter")
        c = L.add("clock", freq=1.0); n = L.add("counter4"); g = L.add("and")
        L.chain(f"{c}.OUT", f"{n}.CLK", f"{n}.Q1", f"{g}.A", f"{n}.Q2", f"{g}.B", f"{g}.Y", f"{n}.R")
        probes(L, f"{n}.Q0", f"{n}.Q1", f"{n}.Q2", f"{n}.Q3")
        return L.finish()

    def check(prj, res):
        got = [sum(v << i for i, v in enumerate(vec(res, ["PR1", "PR2", "PR3", "PR4"], k + 0.75))) for k in range(12)]
        return [_c("Sequence 1, 2, 3, 4, 5, 0, 1, 2, 3, 4, 5, 0", got == [(k + 1) % 6 for k in range(12)], str(got))]
    return build, check


@lab("dg_shift_sipo", G, "Serial-in parallel-out shift register", {"analysis": "digital", "tstop": 6.0}, "Shift the serial word 1 0 1 1 into a 4-bit register and read it in parallel.",
     "On every rising edge each stage copies its neighbour and Q0 takes the serial input, so after 4 clocks the first bit has reached Q3: Q3 Q2 Q1 Q0 = 1 0 1 1.",
     ["Run and watch the bits move one place per clock.", "Read the register after the fourth edge."], ["How do you convert parallel data back to serial?"], mode="raw")
def _sipo():
    def build():
        L = Lab("Shift register")
        d = L.add("lswitch", pattern="1011", step=1.0); c = L.add("clock", freq=1.0); s = L.add("shift4")
        L.chain(f"{d}.OUT", f"{s}.D", f"{c}.OUT", f"{s}.CLK")
        probes(L, f"{s}.Q0", f"{s}.Q1", f"{s}.Q2", f"{s}.Q3")
        return L.finish()

    def check(prj, res):
        q = vec(res, ["PR1", "PR2", "PR3", "PR4"], 3.75)
        return [_c("After 4 clocks Q3 Q2 Q1 Q0 = 1 0 1 1", q[::-1] == [1, 0, 1, 1], f"Q3..Q0 = {q[::-1]}")]
    return build, check


@lab("dg_ring", G, "Ring counter", {"analysis": "digital", "tstop": 9.0}, "Circulate a single 1 around a 4-bit shift register (Q3 fed back to D).",
     "A ring counter with n flip-flops has n states: the one-hot pattern 1000 → 0100 → 0010 → 0001 → 1000 … Its outputs are ready-made timing phases.",
     ["Run and watch the 1 move one place per clock."], ["How many flip-flops does a Johnson counter need for 8 states?"], mode="raw")
def _ring():
    def build():
        L = Lab("Ring counter")
        c = L.add("clock", freq=1.0); s = L.add("shift4", init="1000")
        L.chain(f"{c}.OUT", f"{s}.CLK", f"{s}.Q3", f"{s}.D")
        probes(L, f"{s}.Q0", f"{s}.Q1", f"{s}.Q2", f"{s}.Q3")
        return L.finish()

    def check(prj, res):
        bad = []
        for k in range(8):
            q = vec(res, ["PR1", "PR2", "PR3", "PR4"], k + 0.75)
            if sum(q) != 1 or q.index(1) != (k + 1) % 4 if False else (sum(q) != 1):
                bad.append((k, q))
        pos = [vec(res, ["PR1", "PR2", "PR3", "PR4"], k + 0.75).index(1) for k in range(8)]
        return [_c("Exactly one output high at all times", not bad, str(bad[:2])), _c("The 1 advances one stage per clock and wraps every 4", all((pos[k + 1] - pos[k]) % 4 == 1 for k in range(7)), str(pos))]
    return build, check


@lab("dg_johnson", G, "Johnson (twisted-ring) counter", {"analysis": "digital", "tstop": 9.0}, "Feed the inverted last stage back to the first: a 4-bit register gives an 8-state sequence with only one bit changing at a time.",
     "D = NOT Q3. The register fills with 1s and then with 0s: 0000, 0001, 0011, 0111, 1111, 1110, 1100, 1000. n flip-flops give 2n states.",
     ["Run and read Q3 Q2 Q1 Q0 after each edge."], ["Why is a Johnson counter easy to decode?"], mode="raw")
def _johnson():
    def build():
        L = Lab("Johnson counter")
        c = L.add("clock", freq=1.0); s = L.add("shift4", init="0000"); n = L.add("not")
        L.chain(f"{c}.OUT", f"{s}.CLK", f"{s}.Q3", f"{n}.A", f"{n}.Y", f"{s}.D")
        probes(L, f"{s}.Q0", f"{s}.Q1", f"{s}.Q2", f"{s}.Q3")
        return L.finish()

    def check(prj, res):
        seq = ["0001", "0011", "0111", "1111", "1110", "1100", "1000", "0000"]
        got = ["".join(str(x) for x in vec(res, ["PR4", "PR3", "PR2", "PR1"], k + 0.75)) for k in range(8)]
        return [_c("Sequence 0001 0011 0111 1111 1110 1100 1000 0000", got == seq, " ".join(got))]
    return build, check


@lab("dg_seq_detect", G, "Serial sequence detector (1011)", {"analysis": "digital", "tstop": 12.0}, "Detect the pattern 1011 in a serial bit stream with a shift register and an AND gate.",
     "The register holds the last four bits (Q3 = oldest). The output is 1 when Q3 Q2 Q1 Q0 = 1 0 1 1: AND(Q3, NOT Q2, Q1, Q0). Overlapping occurrences are detected too.",
     ["Run: the stream 0 0 1 0 1 1 0 1 1 0 contains 1011 twice (overlapping)."], ["How would a Mealy FSM do the same with 3 states?"], mode="raw")
def _seq():
    S = "0010110110"

    def build():
        L = Lab("Sequence detector 1011")
        d = L.add("lswitch", pattern=S, step=1.0); c = L.add("clock", freq=1.0); s = L.add("shift4"); n = L.add("not"); a1 = L.add("and"); a2 = L.add("and"); a3 = L.add("and")
        L.chain(f"{d}.OUT", f"{s}.D", f"{c}.OUT", f"{s}.CLK", f"{s}.Q2", f"{n}.A", f"{s}.Q3", f"{a1}.A", f"{n}.Y", f"{a1}.B", f"{s}.Q1", f"{a2}.A", f"{s}.Q0", f"{a2}.B", f"{a1}.Y", f"{a3}.A", f"{a2}.Y", f"{a3}.B")
        probes(L, f"{a3}.Y", f"{d}.OUT")
        return L.finish()

    def check(prj, res):
        want = []
        for k in range(len(S)):
            win = S[max(0, k - 3):k + 1]
            want.append(int(win == "1011"))
        got = [val(res, "PR1", k + 0.75) for k in range(len(S))]
        return [_c("Output high exactly after each occurrence of 1011", got == want, f"{got} (want {want})")]
    return build, check
