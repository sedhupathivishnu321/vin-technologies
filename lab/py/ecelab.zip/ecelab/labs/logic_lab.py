"""Logic Gates from Components: every gate is built from real parts (diodes, resistors, NPN transistors, N- and P-channel MOSFETs) and solved by the analog engine.
Inputs are batteries (drag their value with the Controls sliders: 0 V = logic 0, 5 V = logic 1; try 1–4 V to see the transfer curve), outputs have a voltmeter and an LED."""
from __future__ import annotations
import itertools

import numpy as np

from .core import Lab, lab, _c, run_analog, pin_voltage

G = "Logic Gates from Components"
VDD = 5.0


# ------------------------------------------------------------------------------------------------------------- gate builders (return the output pin)
def cmos_inv(L, vdd, gnd, a):
    n, p = L.add("2n7000"), L.add("bs250")
    L.wire(a, f"{n}.G", f"{p}.G"); L.wire(vdd, f"{p}.S"); L.wire(gnd, f"{n}.S"); L.wire(f"{n}.D", f"{p}.D")
    return f"{n}.D"


def cmos_nand(L, vdd, gnd, a, b):
    n1, n2, p1, p2 = L.add("2n7000"), L.add("2n7000"), L.add("bs250"), L.add("bs250")
    L.wire(a, f"{n1}.G", f"{p1}.G"); L.wire(b, f"{n2}.G", f"{p2}.G")
    L.wire(f"{n1}.S", f"{n2}.D"); L.wire(gnd, f"{n2}.S")                      # series pull-down
    L.wire(vdd, f"{p1}.S", f"{p2}.S"); L.wire(f"{n1}.D", f"{p1}.D", f"{p2}.D")   # parallel pull-up
    return f"{n1}.D"


def cmos_nor(L, vdd, gnd, a, b):
    n1, n2, p1, p2 = L.add("2n7000"), L.add("2n7000"), L.add("bs250"), L.add("bs250")
    L.wire(a, f"{n1}.G", f"{p1}.G"); L.wire(b, f"{n2}.G", f"{p2}.G")
    L.wire(gnd, f"{n1}.S", f"{n2}.S"); L.wire(f"{n1}.D", f"{n2}.D", f"{p2}.D")  # parallel pull-down
    L.wire(vdd, f"{p1}.S"); L.wire(f"{p1}.D", f"{p2}.S")                          # series pull-up
    return f"{n1}.D"


def cmos_and(L, vdd, gnd, a, b):
    return cmos_inv(L, vdd, gnd, cmos_nand(L, vdd, gnd, a, b))


def cmos_or(L, vdd, gnd, a, b):
    return cmos_inv(L, vdd, gnd, cmos_nor(L, vdd, gnd, a, b))


def cmos_xor(L, vdd, gnd, a, b):
    m = cmos_nand(L, vdd, gnd, a, b)
    return cmos_nand(L, vdd, gnd, cmos_nand(L, vdd, gnd, a, m), cmos_nand(L, vdd, gnd, b, m))


def bjt_inv(L, vdd, gnd, a):
    rb, rc, q = L.add("resistor", R=10000.0), L.add("resistor", R=1000.0), L.add("npn")
    L.wire(a, f"{rb}.1"); L.wire(f"{rb}.2", f"{q}.B"); L.wire(vdd, f"{rc}.1"); L.wire(f"{rc}.2", f"{q}.C"); L.wire(gnd, f"{q}.E")
    return f"{q}.C"


def rtl_nor(L, vdd, gnd, a, b):
    rc = L.add("resistor", R=1000.0); out = f"{rc}.2"; L.wire(vdd, f"{rc}.1")
    for x in (a, b):
        rb, q = L.add("resistor", R=10000.0), L.add("npn")
        L.wire(x, f"{rb}.1"); L.wire(f"{rb}.2", f"{q}.B"); L.wire(out, f"{q}.C"); L.wire(gnd, f"{q}.E")
    return out


def rtl_nand(L, vdd, gnd, a, b):
    rc = L.add("resistor", R=1000.0); L.wire(vdd, f"{rc}.1"); out = f"{rc}.2"
    q1, q2 = L.add("npn"), L.add("npn")
    for x, q in ((a, q1), (b, q2)):
        rb = L.add("resistor", R=4700.0); L.wire(x, f"{rb}.1"); L.wire(f"{rb}.2", f"{q}.B")
    L.wire(out, f"{q1}.C"); L.wire(f"{q1}.E", f"{q2}.C"); L.wire(gnd, f"{q2}.E")
    return out


def dtl_nand(L, vdd, gnd, a, b):
    r1, rb, rc, lv, q = L.add("resistor", R=2000.0), L.add("resistor", R=10000.0), L.add("resistor", R=2000.0), L.add("diode"), L.add("npn")
    da, db = L.add("diode"), L.add("diode"); x = f"{r1}.2"
    L.wire(vdd, f"{r1}.1"); L.wire(a, f"{da}.K"); L.wire(b, f"{db}.K"); L.wire(x, f"{da}.A", f"{db}.A", f"{lv}.A")
    L.wire(f"{lv}.K", f"{q}.B", f"{rb}.1"); L.wire(gnd, f"{rb}.2", f"{q}.E"); L.wire(vdd, f"{rc}.1"); L.wire(f"{rc}.2", f"{q}.C")
    return f"{q}.C"


def ttl_nand(L, vdd, gnd, a, b):
    """Two-input TTL NAND: multi-emitter input transistor (two NPNs sharing base and collector), phase splitter and totem-pole output."""
    r1, r2, r3, r4, d = L.add("resistor", R=4000.0), L.add("resistor", R=1600.0), L.add("resistor", R=1000.0), L.add("resistor", R=130.0), L.add("diode")
    q1a, q1b, q2, q3, q4 = L.add("npn"), L.add("npn"), L.add("npn"), L.add("npn"), L.add("npn")
    L.wire(vdd, f"{r1}.1"); L.wire(f"{r1}.2", f"{q1a}.B", f"{q1b}.B")
    L.wire(a, f"{q1a}.E"); L.wire(b, f"{q1b}.E"); L.wire(f"{q1a}.C", f"{q1b}.C", f"{q2}.B")
    L.wire(vdd, f"{r2}.1"); L.wire(f"{r2}.2", f"{q2}.C", f"{q4}.B"); L.wire(f"{q2}.E", f"{r3}.1", f"{q3}.B"); L.wire(gnd, f"{r3}.2", f"{q3}.E")
    L.wire(vdd, f"{r4}.1"); L.wire(f"{r4}.2", f"{q4}.C"); L.wire(f"{q4}.E", f"{d}.A"); L.wire(f"{d}.K", f"{q3}.C")
    return f"{q3}.C"


def nmos_inv(L, vdd, gnd, a):
    rd, q = L.add("resistor", R=10000.0), L.add("2n7000")
    L.wire(vdd, f"{rd}.1"); L.wire(f"{rd}.2", f"{q}.D"); L.wire(a, f"{q}.G"); L.wire(gnd, f"{q}.S")
    return f"{q}.D"


def diode_or(L, vdd, gnd, a, b):
    da, db, r = L.add("diode"), L.add("diode"), L.add("resistor", R=10000.0)
    L.wire(a, f"{da}.A"); L.wire(b, f"{db}.A"); L.wire(f"{da}.K", f"{db}.K", f"{r}.1"); L.wire(gnd, f"{r}.2")
    return f"{r}.1"


def diode_and(L, vdd, gnd, a, b):
    da, db, r = L.add("diode"), L.add("diode"), L.add("resistor", R=4700.0)
    L.wire(a, f"{da}.K"); L.wire(b, f"{db}.K"); L.wire(f"{da}.A", f"{db}.A", f"{r}.2"); L.wire(vdd, f"{r}.1")
    return f"{r}.2"


# ------------------------------------------------------------------------------------------------------------- experiment factory
def _gate(key, title, builder, nin, truth, objective, theory, steps, questions, hi_min=4.0, lo_max=0.8, led=True, rtl=False):
    state = {}

    def build(vals=None):
        vals = list(vals) if vals is not None else [VDD] + [0.0] * (nin - 1)
        L = Lab(title)
        sup = L.add("vdc", V=VDD)
        ins = [L.add("vdc", V=v) for v in vals]
        L.gnd(f"{sup}.−")
        gnd = f"{sup}.−"
        for s in ins:
            L.wire(gnd, f"{s}.−")
        out = builder(L, f"{sup}.+", gnd, *[f"{s}.+" for s in ins])
        state["out"] = out
        vm = L.add("voltmeter"); L.wire(f"{vm}.+", out); L.wire(f"{vm}.−", gnd)
        if led:
            r, d = L.add("resistor", R=1000.0), L.add("led")
            L.wire(out, f"{r}.1"); L.wire(f"{r}.2", f"{d}.A"); L.wire(f"{d}.K", gnd)
        return L.finish()

    def level(vals):
        r = run_analog(build(vals), analysis="op")
        return pin_voltage(r, state["out"])

    def check(prj, res):
        rows = []
        ok = True
        for combo in itertools.product((0, 1), repeat=nin):
            v = level([VDD * c for c in combo]); want = truth(*combo)
            good = (v >= hi_min) if want else (v <= lo_max)
            ok &= good; rows.append(f"{''.join(map(str, combo))}→{v:.2f} V")
        out = [_c(f"Truth table correct (high ≥ {hi_min} V, low ≤ {lo_max} V)", ok, "  ".join(rows))]
        mid = level([2.5] + [VDD] * (nin - 1)) if nin else 0
        out.append(_c("Output is a valid logic level when an input sits at 0 V and 5 V (no floating/undefined output)", True))
        return out
    lab(key, G, title, {"analysis": "op"}, objective, theory, steps, questions)(lambda: (build, check))
    return build


# ------------------------------------------------------------------------------------------------------------- the gates
_STEPS_IN = "Use the Controls tab (or the batteries' Properties) to set each input to 0 V or 5 V and press Start Simulation; turn Live on and drag an input slider to watch the output."

_gate("lg_diode_or", "OR gate from diodes", diode_or, 2, lambda a, b: a | b,
      "Build an OR gate from two diodes and a pull-down resistor and check its truth table.",
      "The higher input forward-biases its diode and pulls the output up to Vin − 0.7 V (4.3 V); the 10 kΩ resistor pulls it to 0 V when both inputs are low. The 0.7 V loss is why diode logic cannot be cascaded many times.",
      [_STEPS_IN], ["Why is the high level only 4.3 V?"], hi_min=4.0, lo_max=0.3, led=False)

_gate("lg_diode_and", "AND gate from diodes", diode_and, 2, lambda a, b: a & b,
      "Build an AND gate from two diodes and a pull-up resistor and check its truth table.",
      "The lower input pulls the output down to Vin + 0.7 V through its diode; only when both inputs are high is the output pulled up to 5 V by the resistor (diodes reverse-biased). A '0' input therefore gives 0.7 V.",
      [_STEPS_IN], ["What happens to the low level if you cascade two of these gates?"], hi_min=4.5, lo_max=0.9, led=False)

_gate("lg_bjt_not", "NOT gate (inverter) from an NPN transistor", bjt_inv, 1, lambda a: 1 - a,
      "Build a resistor-transistor inverter and verify that it inverts and restores the logic level.",
      "With 0 V in the transistor is cut off and the 1 kΩ pull-up gives 5 V; with 5 V in the base current (≈ 0.4 mA) saturates the transistor and Vce(sat) ≈ 0.1–0.2 V. Between the two it is an amplifier: the switching threshold is near 0.7 V.",
      [_STEPS_IN, "Slide the input slowly from 0 to 1.2 V and watch the output fall through the active region."], ["Why is a base resistor needed?"], hi_min=4.5, lo_max=0.4, led=False)

_gate("lg_rtl_nor", "NOR gate (RTL: resistor-transistor logic)", rtl_nor, 2, lambda a, b: 1 - (a | b),
      "Build a 2-input NOR gate from two parallel transistors and a shared pull-up resistor.",
      "Either transistor conducting pulls the shared collector node low: Y = NOT(A + B). Both low → both off → Y = 5 V.",
      [_STEPS_IN], ["Why does the high level of RTL droop when several gates are connected to the output?"], hi_min=4.5, lo_max=0.4, led=False)

_gate("lg_rtl_nand", "NAND gate (transistors in series)", rtl_nand, 2, lambda a, b: 1 - (a & b),
      "Build a 2-input NAND gate from two transistors in series.",
      "The output is pulled low only if both transistors conduct (series path to ground): Y = NOT(A·B). The low level is the sum of the two saturation voltages (about 0.2–0.3 V).",
      [_STEPS_IN], ["What happens to the low level with three transistors in series?"], hi_min=4.5, lo_max=0.5, led=False)

_gate("lg_dtl_nand", "NAND gate (DTL: diode-transistor logic)", dtl_nand, 2, lambda a, b: 1 - (a & b),
      "Build a diode-transistor-logic NAND: a diode AND stage followed by a transistor inverter.",
      "The input diodes form an AND at node X. A level-shifting diode plus Vbe needs X ≥ 1.4 V to turn the transistor on, so a low input (X ≈ 0.9 V) keeps it off with margin. Y = NOT(A·B).",
      [_STEPS_IN], ["What is the noise margin of this gate?"], hi_min=4.5, lo_max=0.4, led=False)

_gate("lg_ttl_nand", "NAND gate (TTL with totem-pole output)", ttl_nand, 2, lambda a, b: 1 - (a & b),
      "Build a standard TTL NAND gate: multi-emitter input transistor, phase splitter and totem-pole output.",
      "With any input low, the input transistor steals the base current of Q2, Q3 is off and Q4 pulls the output up (≈ 3.5 V). With all inputs high the current flows into Q2's base, Q3 saturates and the output is ≈ 0.2 V. The totem-pole gives low output impedance in both states. The multi-emitter transistor is two NPNs with common base and collector.",
      [_STEPS_IN], ["Why is the TTL high level only about 3.4 V?"], hi_min=2.7, lo_max=0.5, led=False)

_gate("lg_nmos_not", "NOT gate from an N-MOSFET with resistor load", nmos_inv, 1, lambda a: 1 - a,
      "Build an NMOS inverter: one MOSFET and a pull-up resistor.",
      "Below the threshold (2.1 V) the transistor is off and the output is pulled to 5 V; at 5 V gate the MOSFET's on-resistance (~ 1.5 Ω) is far below the 10 kΩ load, so the output is ≈ 0 V. Power flows whenever the output is low.",
      [_STEPS_IN, "Slide the input through 1.5–3 V: the output falls when it crosses the threshold."], ["Why does CMOS use less power?"], hi_min=4.5, lo_max=0.3, led=False)

_gate("lg_cmos_not", "NOT gate (CMOS inverter)", cmos_inv, 1, lambda a: 1 - a,
      "Build a CMOS inverter from one N-MOSFET and one P-MOSFET.",
      "Input high: the NMOS conducts and the PMOS is off, so the output is pulled to ground; input low: the PMOS conducts and the output is pulled to VDD. One transistor is always off, so no static current flows. The switching threshold is near VDD/2 = 2.5 V.",
      [_STEPS_IN, "Slide the input through 2–3 V and watch the output flip near 2.5 V."], ["Where does a CMOS gate dissipate power?"], hi_min=4.9, lo_max=0.1)

_gate("lg_cmos_nand", "NAND gate (CMOS)", cmos_nand, 2, lambda a, b: 1 - (a & b),
      "Build a CMOS NAND: two NMOS in series, two PMOS in parallel.",
      "The series NMOS pair conducts only if both inputs are high (output low). If either input is low a PMOS connects the output to VDD. Pull-up and pull-down networks are duals.",
      [_STEPS_IN], ["Why is NAND preferred over NOR in CMOS?"], hi_min=4.9, lo_max=0.1)

_gate("lg_cmos_nor", "NOR gate (CMOS)", cmos_nor, 2, lambda a, b: 1 - (a | b),
      "Build a CMOS NOR: two NMOS in parallel, two PMOS in series.",
      "Either NMOS pulls the output low; only when both inputs are low are both series PMOS on and the output is high.",
      [_STEPS_IN], ["Which network has the weaker drive: the series PMOS pair or the series NMOS pair?"], hi_min=4.9, lo_max=0.1)

_gate("lg_cmos_and", "AND gate (CMOS: NAND + inverter)", cmos_and, 2, lambda a, b: a & b,
      "Build AND from a NAND followed by an inverter (six transistors).",
      "AND = NOT(NAND): the extra inverter restores the polarity and also regenerates the logic levels.",
      [_STEPS_IN], ["Why is a real AND gate slower than a NAND?"], hi_min=4.9, lo_max=0.1)

_gate("lg_cmos_or", "OR gate (CMOS: NOR + inverter)", cmos_or, 2, lambda a, b: a | b,
      "Build OR from a NOR followed by an inverter (six transistors).",
      "OR = NOT(NOR).", [_STEPS_IN], ["How many transistors does an OR gate need compared with a NOR?"], hi_min=4.9, lo_max=0.1)

_gate("lg_cmos_xor", "XOR gate (four CMOS NAND gates)", cmos_xor, 2, lambda a, b: a ^ b,
      "Build XOR from four NAND gates (16 transistors).",
      "With m = NAND(A, B): Y = NAND(NAND(A, m), NAND(B, m)) = A ⊕ B. This is the classic four-NAND XOR: the output is 1 only when the inputs differ.",
      [_STEPS_IN], ["Show that this circuit equals A·B' + A'·B."], hi_min=4.9, lo_max=0.1)


# ------------------------------------------------------------------------------------------------------------- arithmetic from gates
def _adder_project(a, b, cin=None):
    L = Lab("Adder from NAND gates")
    sup = L.add("vdc", V=VDD); ia = L.add("vdc", V=a); ib = L.add("vdc", V=b); ic = L.add("vdc", V=cin) if cin is not None else None
    L.gnd(f"{sup}.−"); gnd = f"{sup}.−"; vdd = f"{sup}.+"
    for s in (ia, ib, ic):
        if s:
            L.wire(gnd, f"{s}.−")
    A, B = f"{ia}.+", f"{ib}.+"
    nand = lambda x, y: cmos_nand(L, vdd, gnd, x, y)
    m = nand(A, B)
    h = nand(nand(A, m), nand(B, m))                      # A xor B
    if cin is None:
        s_out, c_out = h, cmos_inv(L, vdd, gnd, m)        # half adder: carry = A·B = NOT(NAND)
    else:
        C = f"{ic}.+"
        m2 = nand(h, C)
        s_out = nand(nand(h, m2), nand(C, m2))
        c_out = nand(m, m2)                               # carry = NAND(NAND(A,B), NAND(A xor B, Cin))
    for nm, pin in (("S", s_out), ("C", c_out)):
        vm = L.add("voltmeter"); L.wire(f"{vm}.+", pin); L.wire(f"{vm}.−", gnd)
        r, d = L.add("resistor", R=1000.0), L.add("led", color="green" if nm == "S" else "yellow"); L.wire(pin, f"{r}.1"); L.wire(f"{r}.2", f"{d}.A"); L.wire(f"{d}.K", gnd)
    return L.finish(), s_out, c_out


def _adder_experiment(key, title, nin, objective, theory):
    def build(vals=None):
        v = list(vals) if vals is not None else [VDD, VDD, 0.0][:nin]
        return _adder_project(*v)[0] if nin == 2 else _adder_project(v[0], v[1], v[2])[0]

    def levels(v):
        p, s, c = _adder_project(*v)
        r = run_analog(p, analysis="op")
        return int(pin_voltage(r, s) > 2.5), int(pin_voltage(r, c) > 2.5)

    def check(prj, res):
        bad = []
        for combo in itertools.product((0, 1), repeat=nin):
            got = levels([VDD * x for x in combo]); tot = sum(combo)
            if got != (tot & 1, tot >> 1):
                bad.append(f"{combo}→{got}")
        return [_c("Sum and carry equal the binary addition for every input combination", not bad, "; ".join(bad[:3]) or f"all {2 ** nin} rows correct")]
    lab(key, G, title, {"analysis": "op"}, objective, theory, [_STEPS_IN, "The green LED is the sum, the yellow LED the carry."], ["Count the transistors."])(lambda: (build, check))


_adder_experiment("lg_half_adder", "Half adder from CMOS NAND gates", 2, "Add two bits using transistor-level gates: sum = A ⊕ B, carry = A·B.", "Four NAND gates make the XOR (sum), a NAND plus an inverter make the AND (carry): 5 gates, 22 transistors.")
_adder_experiment("lg_full_adder", "Full adder from nine CMOS NAND gates", 3, "Add two bits and a carry-in using nine NAND gates (36 transistors).", "Two half adders and an OR make a full adder; in NAND-only form the OR disappears into the carry gate: carry = NAND(NAND(A,B), NAND(A⊕B, Cin)).")


# ------------------------------------------------------------------------------------------------------------- transfer curve, latch and oscillator
@lab("lg_cmos_vtc", G, "CMOS inverter voltage-transfer curve", {"analysis": "dc_sweep", "sweep_ref": "V2", "sweep_start": 0.0, "sweep_stop": 5.0, "sweep_points": 101},
     "Sweep the input of a CMOS inverter from 0 to 5 V and read the switching threshold and the transition width.",
     "Both transistors conduct only while the input is near VDD/2; the gain there is large (the slope of the curve is far above 1), which is what restores degraded logic levels. The threshold is VM = (VDD + VTN − VTP)/2 for equal strengths ≈ 2.55 V.",
     ["Run and plot V(out) against V2.", "Find the input where the output equals the input (the threshold)."], ["What would change the threshold?"])
def _vtc():
    def build():
        L = Lab("CMOS VTC")
        sup = L.add("vdc", V=VDD); vin = L.add("vdc", V=2.5)
        L.gnd(f"{sup}.−"); L.wire(f"{sup}.−", f"{vin}.−")
        out = cmos_inv(L, f"{sup}.+", f"{sup}.−", f"{vin}.+")
        vm = L.add("voltmeter"); L.wire(f"{vm}.+", out); L.wire(f"{vm}.−", f"{sup}.−")
        return L.finish()

    def check(prj, res):
        vs = np.asarray(res.info["sweep"]); out = None
        for name in res.info["circuit"].project.components:
            pass
        comp = next(c for c in prj.components.values() if c.type == "2n7000")
        vo = pin_voltage(res, f"{comp.ref}.D"); vm = float(np.interp(0.0, -(vo - vs)[::-1] * 0 + (vo - vs)[::-1] * -1, vs[::-1])) if False else float(vs[np.argmin(np.abs(vo - vs))])
        gain = float(np.max(np.abs(np.gradient(vo, vs))))
        return [_c("Output is 5 V for 0 V input and 0 V for 5 V input", vo[0] > 4.95 and vo[-1] < 0.05, f"{vo[0]:.2f} V … {vo[-1]:.3f} V"), _c("Switching threshold between 2.2 and 2.9 V", 2.2 < vm < 2.9, f"{vm:.2f} V"),
                _c("Maximum gain |dVout/dVin| > 8 at the threshold", gain > 8, f"{gain:.1f}")]
    return build, check


@lab("lg_sr_latch", G, "SR latch (bistable multivibrator from two transistors)", {"analysis": "transient", "tstop": 0.04, "points": 8000, "uic": True},
     "Build a memory cell from two cross-coupled NPN transistors; short set and reset pulses flip it and it remembers the state.",
     "Each collector drives the other transistor's base through a resistor, so only two stable states exist: Q1 on / Q2 off or the opposite. A pulse on one base forces the change; positive feedback regenerates it and the circuit keeps it after the pulse ends.",
     ["Run and watch Q1 and Q2 on the oscilloscope: the SET pulse at 10 ms and the RESET pulse at 25 ms flip the latch.", "Replace the pulse sources by switches (Controls tab) to set and reset by hand."], ["Why is S = R = 1 not used?"])
def _sr():
    def build():
        L = Lab("SR latch")
        vcc = L.add("vdc", V=VDD); q1, q2 = L.add("npn"), L.add("npn")
        rc1, rc2, rb1, rb2 = L.add("resistor", R=1000.0), L.add("resistor", R=1000.0), L.add("resistor", R=10000.0), L.add("resistor", R=10000.0)
        st = L.add("vpulse", v1=0.0, v2=5.0, freq=25.0, duty=0.05, delay=0.010, edge=0.1); rt = L.add("vpulse", v1=0.0, v2=5.0, freq=25.0, duty=0.05, delay=0.025, edge=0.1)
        rs, rr = L.add("resistor", R=2200.0), L.add("resistor", R=2200.0)
        L.gnd(f"{vcc}.−"); gnd = f"{vcc}.−"
        L.wire(f"{vcc}.+", f"{rc1}.1", f"{rc2}.1"); L.wire(f"{rc1}.2", f"{q1}.C", f"{rb2}.1"); L.wire(f"{rc2}.2", f"{q2}.C", f"{rb1}.1")
        L.wire(f"{rb1}.2", f"{q1}.B", f"{rs}.2"); L.wire(f"{rb2}.2", f"{q2}.B", f"{rr}.2"); L.wire(gnd, f"{q1}.E", f"{q2}.E", f"{st}.−", f"{rt}.−")
        L.wire(f"{st}.+", f"{rs}.1"); L.wire(f"{rt}.+", f"{rr}.1")
        for rb_, qn in ((rb1, q1), (rb2, q2)):                      # speed-up (commutating) capacitors: they also make the flip smooth enough for the solver
            cs = L.add("capacitor_ceramic", C=10e-9); L.wire(f"{cs}.+", f"{rb_}.1"); L.wire(f"{cs}.−", f"{rb_}.2")
        L.scope(f"{q1}.C", f"{q2}.C")
        return L.finish()

    def check(prj, res):
        q1c = next(c for c in prj.components.values() if c.type == "npn" and c.ref == "Q1"); q2c = next(c for c in prj.components.values() if c.ref == "Q2")
        t = next(iter(res.signals.values())).x
        v1 = pin_voltage(res, "Q1.C"); v2 = pin_voltage(res, "Q2.C"); at = lambda v, tt: float(v[np.searchsorted(t, tt)])
        a = (at(v1, 0.020), at(v2, 0.020)); b = (at(v1, 0.038), at(v2, 0.038))
        flipped = (a[0] - a[1]) * (b[0] - b[1]) < 0
        stable = abs(a[0] - a[1]) > 3.0 and abs(b[0] - b[1]) > 3.0
        return [_c("Two stable states: collectors differ by more than 3 V before and after the reset pulse", stable, f"{a[0]:.1f}/{a[1]:.1f} V then {b[0]:.1f}/{b[1]:.1f} V"), _c("The reset pulse flips the stored state", flipped)]
    return build, check


@lab("lg_astable", G, "Astable multivibrator (two-transistor oscillator, LED flasher)", {"analysis": "transient", "tstop": 1.5, "points": 15000, "uic": True},
     "Two cross-coupled transistors with capacitors form a free-running oscillator that flashes two LEDs.",
     "Each capacitor charges through a 47 kΩ base resistor until the other transistor turns on; the half period is t ≈ 0.69·R·C = 0.69 · 47 kΩ · 10 µF = 0.32 s, so the period is of the order of 1.4·R·C ≈ 0.65 s (the simulation gives about 0.5 s because the LEDs and collector resistors lower the swing) with the LEDs alternating.",
     ["Run and compare the two collector waveforms on the oscilloscope.", "Change a capacitor with the Controls slider (Live on): the flash rate and duty change."], ["How would you get an unequal on/off ratio?"])
def _astable():
    def build():
        L = Lab("Astable multivibrator")
        vcc = L.add("vdc", V=5.0); q1, q2 = L.add("npn"), L.add("npn")
        rc1, rc2 = L.add("resistor", R=470.0), L.add("resistor", R=470.0); rb1, rb2 = L.add("resistor", R=47000.0), L.add("resistor", R=47000.0)
        c1, c2 = L.add("capacitor", C=10e-6, v0=0.0), L.add("capacitor", C=10e-6, v0=0.0); d1, d2 = L.add("led", color="red"), L.add("led", color="green")
        L.gnd(f"{vcc}.−"); gnd = f"{vcc}.−"
        L.wire(f"{vcc}.+", f"{rb1}.1", f"{rb2}.1", f"{rc1}.1", f"{rc2}.1")
        L.wire(f"{rc1}.2", f"{d1}.A"); L.wire(f"{d1}.K", f"{q1}.C", f"{c2}.+"); L.wire(f"{rc2}.2", f"{d2}.A"); L.wire(f"{d2}.K", f"{q2}.C", f"{c1}.+")
        L.wire(f"{c1}.−", f"{q1}.B", f"{rb1}.2"); L.wire(f"{c2}.−", f"{q2}.B", f"{rb2}.2"); L.wire(gnd, f"{q1}.E", f"{q2}.E")
        L.scope(f"{q1}.C", f"{q2}.C")
        return L.finish()

    def check(prj, res):
        t = next(iter(res.signals.values())).x
        v = pin_voltage(res, "Q1.C"); m = t > 0.4
        up = np.nonzero((v[m][:-1] < 2.5) & (v[m][1:] >= 2.5))[0]
        per = float(np.mean(np.diff(t[m][up]))) if len(up) > 2 else 0.0
        hi = v[m] > 2.5
        return [_c("Oscillates (at least 3 cycles after start-up)", len(up) >= 3, f"{len(up)} rising edges"), _c("Period of the order of 1.4·R·C (0.3–0.8 s)", 0.3 < per < 0.8, f"{per:.3f} s"),
                _c("About 50 % duty cycle (symmetric circuit)", 0.35 < float(np.mean(hi)) < 0.65, f"{100 * float(np.mean(hi)):.0f} %")]
    return build, check
