"""Microcontroller Laboratory (Arduino UNO sketches on a breadboard): LED chaser, event counting, light-controlled lamp, PWM fade."""
from __future__ import annotations
import numpy as np

from ..examples import ex, Bench, _c, _row, _led_row, _gnd_rail, LIMIT_BB, LIMIT_MCU
from ..sim.manager import run_sync

G = "Microcontroller Lab"

CHASER = """// LED chaser: one LED at a time on pins 2, 3, 4, 5
const int first = 2;
const int last = 5;

void setup() {
  for (int p = first; p <= last; p++) {
    pinMode(p, OUTPUT);
  }
}

void loop() {
  for (int p = first; p <= last; p++) {
    digitalWrite(p, HIGH);
    delay(200);
    digitalWrite(p, LOW);
  }
}
"""

COUNTER = """// Count button presses (rising edges on pin 2) and print the total
int count = 0;
int lastState = LOW;

void setup() {
  Serial.begin(9600);
  pinMode(2, INPUT);
  pinMode(8, OUTPUT);
}

void loop() {
  int now = digitalRead(2);
  if (now == HIGH && lastState == LOW) {
    count++;
    Serial.print("count=");
    Serial.println(count);
  }
  digitalWrite(8, now);
  lastState = now;
  delay(20);
}
"""

LDR_LAMP = """// Light-controlled lamp: LED on pin 8 turns on when it gets dark (A0 below 300)
void setup() {
  pinMode(8, OUTPUT);
  Serial.begin(9600);
}

void loop() {
  int level = analogRead(A0);
  if (level < 300) {
    digitalWrite(8, HIGH);
  } else {
    digitalWrite(8, LOW);
  }
  Serial.println(level);
  delay(200);
}
"""

FADE = """// PWM fade: brightness of the LED on pin 9 ramps up from 0 to 255
void setup() {
  pinMode(9, OUTPUT);
}

void loop() {
  for (int b = 0; b <= 255; b += 5) {
    analogWrite(9, b);
    delay(20);
  }
  delay(100);
}
"""


def _led_currents(res, n):
    return [res.signals.get(f"I(D{i})") for i in range(1, n + 1)]


@ex("mc_chaser", G, "LED chaser (for loop over pins)", {"analysis": "transient", "tstop": 1.8, "points": 7200},
    "Light four LEDs one after another with a for loop over pins 2–5.",
    "A for loop writes HIGH to a pin, waits 200 ms and writes LOW before moving to the next pin. Each LED has its own 220 Ω resistor: I ≈ (5 V − 1.9 V − 0.6 V drop in the pin)/220 Ω ≈ 11 mA.",
    ["Press ▶ Start Simulation and watch the LEDs.", "Change delay(200) to delay(50) for a faster chaser.", "Add a fifth LED on pin 6."], ["How would you make the light bounce back and forth?"],
    LIMIT_BB + " " + LIMIT_MCU)
def _chaser():
    def build():
        b = Bench("LED chaser", uno=True, code=CHASER)
        for k, (pin, col) in enumerate((("D2", 4), ("D3", 10), ("D4", 16), ("D5", 22))):
            _led_row(b, f"UNO1.{pin}", col)
        _gnd_rail(b)
        return b.p

    def check(prj, res):
        s = _led_currents(res, 4)
        if any(x is None for x in s):
            return [_c("All four LED currents recorded", False)]
        order = [float(x.x[np.argmax(x.y > 5e-3)]) if np.any(x.y > 5e-3) else -1.0 for x in s]
        one_at_a_time = all(int(sum(float(np.interp(t, x.x, x.y)) > 5e-3 for x in s)) <= 1 for t in np.linspace(0.05, 1.7, 60))
        return [_c("Each LED lights, in order D2 → D3 → D4 → D5", all(o >= 0 for o in order) and order == sorted(order), ", ".join(f"{o:.2f}s" for o in order)),
                _c("Only one LED is on at any time", one_at_a_time)]
    return build, check


@ex("mc_counter", G, "Button press counter (Serial output)", {"analysis": "transient", "tstop": 5.0, "points": 5000},
    "Count the rising edges of a push button on pin 2 and print the running total on the Serial monitor.",
    "Edge detection: a press is counted when the pin changes from LOW to HIGH, not while it stays HIGH. The button pattern 0101010100 at 0.5 s steps gives four presses.",
    ["Press ▶ Start Simulation and open the Serial tab: count=1 … count=4.", "Change the button's press pattern to add more presses."], ["What happens if the contact bounces?"], LIMIT_BB + " " + LIMIT_MCU)
def _counter():
    def build():
        b = Bench("Button counter", uno=True, code=COUNTER)
        _led_row(b, "UNO1.D8", 6)
        b.seat("pushbutton", {"1": "e18", "2": "e20", "3": "f18", "4": "f20"}, pattern="0101010100", step=0.5)
        b.seat("resistor", {"1": "a20", "2": "a24"}, R=10000.0)
        b.jumper("UNO1.5V", "BB.j18", "#d62828"); b.jumper("UNO1.D2", "BB.c20", "#2a9d3a"); b.jumper("BB.b24", "BB.tn24", "#2b2b2b")
        _gnd_rail(b)
        return b.p

    def check(prj, res):
        txt = res.info.get("serial_text", "")
        return [_c("Serial prints count=1 … count=4", all(f"count={n}" in txt for n in (1, 2, 3, 4)), txt.replace(chr(10), " | ")[:60]), _c("No fifth count", "count=5" not in txt)]
    return build, check


def _ldr_project(lux):
    b = Bench("Light-controlled lamp", uno=True, code=LDR_LAMP)
    _led_row(b, "UNO1.D8", 6)
    b.seat("ldr", {"A": "e18", "B": "e20"}, lux=lux)
    b.seat("resistor", {"1": "a20", "2": "a24"}, R=10000.0)
    b.jumper("UNO1.5V", "BB.a18", "#d62828"); b.jumper("UNO1.A0", "BB.b20", "#2a9d3a"); b.jumper("BB.b24", "BB.tn24", "#2b2b2b")
    _gnd_rail(b)
    return b.p


@ex("mc_ldr_lamp", G, "Light-controlled lamp (LDR + analogRead)", {"analysis": "transient", "tstop": 1.0, "points": 2000},
    "Read an LDR divider on A0 and switch an LED on when the room gets dark.",
    "The LDR and a 10 kΩ resistor form a divider: in the dark the LDR resistance is high, so A0 is low (below 300 of 1023) and the sketch lights the LED; in bright light A0 is high and the LED is off.",
    ["Press ▶ Start Simulation with the LDR at 1 lux: the LED is on.", "Change the LDR 'lux' to 1000 and run again: the LED goes off."], ["How would you add hysteresis so the lamp does not flicker at dusk?"],
    LIMIT_BB + " " + LIMIT_MCU)
def _ldr():
    def build():
        return _ldr_project(1.0)

    def led_on(prj):
        _, r = run_sync(prj)
        s = r.signals.get("I(D1)")
        return s is not None and float(s.y[-1]) > 5e-3

    def check(prj, res):
        s = res.signals.get("I(D1)")
        dark = s is not None and float(s.y[-1]) > 5e-3
        bright = led_on_cfg(1000.0)
        return [_c("Dark (1 lux): LED on", dark), _c("Bright (1000 lux): LED off", not bright)]

    def led_on_cfg(lux):
        p = _ldr_project(lux); p.sim.update(analysis="transient", tstop=1.0, points=2000)
        return led_on(p)
    return build, check


@ex("mc_pwm_fade", G, "PWM fade (analogWrite ramp)", {"analysis": "transient", "tstop": 1.4, "points": 14000},
    "Ramp the duty cycle of pin 9 from 0 to 100 % and watch the LED brighten.",
    "analogWrite(pin, b) produces a 490 Hz PWM wave with duty b/255. The LED's average current, and so its brightness, grows in proportion to the duty cycle.",
    ["Press ▶ Start Simulation and watch the LED brighten over about 1 s.", "Change the step 5 to 15 for a coarser, faster ramp."], ["Why does the eye see the LED as dimmer rather than flickering at 490 Hz?"],
    LIMIT_BB + " " + LIMIT_MCU)
def _fade():
    def build():
        b = Bench("PWM fade", uno=True, code=FADE)
        _led_row(b, "UNO1.D9", 6)
        _gnd_rail(b)
        return b.p

    def check(prj, res):
        s = res.signals.get("I(D1)")
        if s is None:
            return [_c("LED current recorded", False)]
        m = lambda a, b: float(np.mean(s.y[(s.x >= a) & (s.x < b)]))
        early, mid, late = m(0.05, 0.25), m(0.4, 0.6), m(0.8, 1.0)
        return [_c("Average LED current rises: early < mid < late", early < mid < late, f"{early * 1e3:.2f} < {mid * 1e3:.2f} < {late * 1e3:.2f} mA")]
    return build, check
