"""Arduino-style C/C++ subset: lexer, parser and tree-walking interpreter.

Supported: #define (object-like), #include (ignored), global/local variables and arrays, int/long/short/char/byte/bool/float/double/unsigned/String,
AVR-sized integers (int = 16 bit, wrap applied on store), functions (by value), if/else, for, while, do-while, switch/case, break/continue/return,
all C operators incl. ternary, compound assignment, ++/--, casts, and the Arduino API (pinMode, digitalWrite/Read, analogRead/Write, delay, millis,
Serial.print/println, tone, map, constrain, random, math, bit helpers).
NOT supported (reported with a line number): classes/structs, pointers/references, templates, new/delete, function-like macros, interrupts, libraries.
"""
from __future__ import annotations
import math
import random
import re

NOT_SUPPORTED = {"class": "classes", "struct": "structs", "enum": "enums", "typedef": "typedef", "template": "templates", "namespace": "namespaces",
                 "union": "unions", "new": "dynamic allocation", "delete": "dynamic allocation", "goto": "goto", "try": "exceptions", "catch": "exceptions"}


class CppError(Exception):
    def __init__(self, msg, line=0):
        super().__init__(f"line {line}: {msg}" if line else msg)
        self.msg, self.line = msg, line


class Ch(int):
    """A char value (prints as a character)."""


# ------------------------------------------------------------------------------------------------ lexer
_TOK = re.compile(r"""
 (?P<ws>\s+)
|(?P<num>0[xX][0-9a-fA-F]+[uUlL]*|0[bB][01]+[uUlL]*|(?:\d+\.\d*|\.\d+)(?:[eE][+-]?\d+)?[fF]?|\d+[eE][+-]?\d+[fF]?|\d+[uUlL]*)
|(?P<id>[A-Za-z_]\w*)
|(?P<str>"(?:\\.|[^"\\])*")
|(?P<chr>'(?:\\.|[^'\\])')
|(?P<op><<=|>>=|\+\+|--|\+=|-=|\*=|/=|%=|&=|\|=|\^=|<<|>>|<=|>=|==|!=|&&|\|\||->|::|[-+*/%&|^~!<>=?:;,.(){}\[\]])
""", re.X)
_ESC = {"n": "\n", "t": "\t", "r": "\r", "0": "\0", "\\": "\\", "'": "'", '"': '"'}


def _unesc(s):
    return re.sub(r"\\(.)", lambda m: _ESC.get(m.group(1), m.group(1)), s)


def preprocess(src):
    """Strip comments, apply #define macros, drop #include. Returns (text, macros)."""
    src = re.sub(r"/\*.*?\*/", lambda m: "\n" * m.group(0).count("\n"), src, flags=re.S)
    src = re.sub(r"//[^\n]*", "", src)
    macros, out = {}, []
    for ln, line in enumerate(src.split("\n"), 1):
        s = line.strip()
        if s.startswith("#"):
            m = re.match(r"#\s*define\s+(\w+)(\(?)\s*(.*)$", s)
            if m:
                if m.group(2):
                    raise CppError("function-like macros are not supported", ln)
                macros[m.group(1)] = m.group(3).strip()
            elif re.match(r"#\s*(include|pragma|ifndef|ifdef|endif|if|else|undef)", s):
                pass
            else:
                raise CppError(f"unsupported preprocessor directive: {s}", ln)
            out.append("")
        else:
            out.append(line)
    return "\n".join(out), macros


def lex(src):
    text, macros = preprocess(src)
    toks = []
    line = 1
    pos = 0
    while pos < len(text):
        m = _TOK.match(text, pos)
        if not m:
            raise CppError(f"unexpected character {text[pos]!r}", line)
        kind, val = m.lastgroup, m.group()
        pos = m.end()
        if kind == "ws":
            line += val.count("\n")
            continue
        if kind == "id" and val in macros:
            for t in ([x for x in lex(macros[val]) if x[0] != "eof"] if macros[val] else []):
                toks.append((t[0], t[1], line))
            continue
        toks.append((kind, val, line))
    toks.append(("eof", "", line))
    return toks


# ------------------------------------------------------------------------------------------------ types
TYPE_WORDS = {"void", "int", "long", "short", "char", "byte", "bool", "boolean", "float", "double", "unsigned", "signed", "word", "String",
              "uint8_t", "uint16_t", "uint32_t", "int8_t", "int16_t", "int32_t", "size_t"}
QUALS = {"const", "static", "volatile", "extern", "register"}


def make_spec(words):
    w = [x for x in words]
    if "String" in w: return ("str",)
    if "void" in w: return ("void",)
    if "bool" in w or "boolean" in w: return ("bool",)
    if "float" in w or "double" in w: return ("float",)
    uns = "unsigned" in w or any(x in ("byte", "word", "uint8_t", "uint16_t", "uint32_t", "size_t") for x in w)
    if "char" in w or "byte" in w or "uint8_t" in w or "int8_t" in w:
        return ("int", 8, not uns, "char" in w and not uns)
    if "long" in w or "uint32_t" in w or "int32_t" in w:
        return ("int", 64 if w.count("long") > 1 else 32, not uns, False)
    return ("int", 16, not uns, False)


def wrap(v, spec):
    k = spec[0]
    if k == "int":
        if isinstance(v, str): raise CppError("cannot convert String to a number")
        v = int(v)
        bits = spec[1]
        v &= (1 << bits) - 1
        if spec[2] and v >= 1 << (bits - 1):
            v -= 1 << bits
        return Ch(v) if spec[3] else v
    if k == "float": return float(v)
    if k == "bool": return bool(v)
    if k == "str": return v if isinstance(v, str) else _to_str(v)
    return v


def _to_str(v):
    if isinstance(v, Ch): return chr(v & 255)
    if isinstance(v, bool): return "1" if v else "0"
    if isinstance(v, float): return f"{v:.2f}"
    return str(v)


# ------------------------------------------------------------------------------------------------ parser
class Parser:
    def __init__(self, toks):
        self.t, self.i = toks, 0

    def peek(self, k=0): return self.t[min(self.i + k, len(self.t) - 1)]
    def line(self): return self.peek()[2]

    def next(self):
        tok = self.t[self.i]; self.i += 1; return tok

    def accept(self, val):
        if self.peek()[1] == val and self.peek()[0] in ("op", "id"):
            self.i += 1; return True
        return False

    def expect(self, val):
        if not self.accept(val):
            raise CppError(f"expected '{val}' but found '{self.peek()[1] or 'end of file'}'", self.line())

    def ident(self):
        k, v, ln = self.next()
        if k != "id": raise CppError(f"expected a name but found '{v}'", ln)
        return v

    def is_type(self, k=0):
        t = self.peek(k)
        return t[0] == "id" and (t[1] in TYPE_WORDS or t[1] in QUALS)

    def parse_type(self):
        words, qual = [], set()
        while self.peek()[0] == "id" and (self.peek()[1] in TYPE_WORDS or self.peek()[1] in QUALS):
            w = self.next()[1]
            (qual.add(w) if w in QUALS else words.append(w))
        if not words: raise CppError("expected a type", self.line())
        if self.peek()[1] in ("*", "&") and self.peek()[0] == "op":
            raise CppError("pointers and references are not supported", self.line())
        return make_spec(words), qual

    def program(self):
        globs, funcs = [], {}
        while self.peek()[0] != "eof":
            kw = self.peek()[1]
            if kw in NOT_SUPPORTED:
                raise CppError(f"C++ feature not supported: {NOT_SUPPORTED[kw]}", self.line())
            ln = self.line()
            spec, qual = self.parse_type()
            name = self.ident()
            if self.accept("("):
                params = []
                if not self.accept(")"):
                    if self.peek()[1] == "void" and self.peek(1)[1] == ")":
                        self.next(); self.next()
                    else:
                        while True:
                            ps, _ = self.parse_type(); pn = self.ident(); arr = False
                            if self.accept("["): self.expect("]"); arr = True
                            params.append((ps, pn, arr))
                            if self.accept(")"): break
                            self.expect(",")
                if self.accept(";"): continue
                funcs[name] = (spec, params, self.block(), ln)
            else:
                globs.extend(self.declarators(spec, name, qual, ln))
        return globs, funcs

    def declarators(self, spec, first, qual, ln):
        out = []
        name = first
        while True:
            size, init = None, None
            if self.accept("["):
                size = ("auto",) if self.peek()[1] == "]" else self.expr()
                self.expect("]")
            if self.accept("="):
                if self.peek()[1] == "{":
                    self.next(); lst = []
                    while not self.accept("}"):
                        lst.append(self.assign()); self.accept(",")
                    init = ("list", lst)
                else:
                    init = self.assign()
            out.append(("decl", spec, name, size, init, ln))
            if self.accept(","):
                name = self.ident(); continue
            self.expect(";")
            return out

    # statements
    def block(self):
        self.expect("{")
        body = []
        while not self.accept("}"):
            if self.peek()[0] == "eof": raise CppError("missing '}'", self.line())
            body.append(self.stmt())
        return ("block", body)

    def stmt(self):
        t = self.peek(); ln = t[2]; v = t[1]
        if t[0] == "id" and v in NOT_SUPPORTED:
            raise CppError(f"C++ feature not supported: {NOT_SUPPORTED[v]}", ln)
        if v == "{" and t[0] == "op": return self.block()
        if t[0] == "op" and v == ";": self.next(); return ("block", [])
        if t[0] == "id":
            if v == "if":
                self.next(); self.expect("("); c = self.expr(); self.expect(")"); a = self.stmt(); b = self.stmt() if self.accept("else") else None
                return ("if", c, a, b)
            if v == "while":
                self.next(); self.expect("("); c = self.expr(); self.expect(")"); return ("while", c, self.stmt())
            if v == "do":
                self.next(); body = self.stmt(); self.expect("while"); self.expect("("); c = self.expr(); self.expect(")"); self.expect(";"); return ("do", body, c)
            if v == "for":
                self.next(); self.expect("(")
                if self.accept(";"): init = None
                elif self.is_type():
                    sp, q = self.parse_type(); n = self.ident(); init = ("decls", self.declarators(sp, n, q, ln))
                else: init = ("expr", self.expr()); self.expect(";")
                cond = None if self.peek()[1] == ";" else self.expr(); self.expect(";")
                step = None if self.peek()[1] == ")" else self.expr(); self.expect(")")
                return ("for", init, cond, step, self.stmt())
            if v == "switch":
                self.next(); self.expect("("); e = self.expr(); self.expect(")"); self.expect("{")
                cases = []
                while not self.accept("}"):
                    if self.accept("case"): lab = self.expr(); self.expect(":")
                    elif self.accept("default"): lab = None; self.expect(":")
                    else: raise CppError("expected 'case' or 'default'", self.line())
                    body = []
                    while self.peek()[1] not in ("case", "default", "}"):
                        body.append(self.stmt())
                    cases.append((lab, body))
                return ("switch", e, cases)
            if v == "break": self.next(); self.expect(";"); return ("break",)
            if v == "continue": self.next(); self.expect(";"); return ("continue",)
            if v == "return":
                self.next(); e = None if self.peek()[1] == ";" else self.expr(); self.expect(";"); return ("return", e)
            if self.is_type() and not (self.peek(1)[1] == "(" and v not in QUALS):
                sp, q = self.parse_type(); n = self.ident(); return ("decls", self.declarators(sp, n, q, ln))
        e = self.expr(); self.expect(";")
        return ("expr", e, ln)

    # expressions
    def expr(self):
        e = self.assign()
        while self.accept(","):
            e = ("comma", e, self.assign())
        return e

    ASSIGN = {"=", "+=", "-=", "*=", "/=", "%=", "&=", "|=", "^=", "<<=", ">>="}

    def assign(self):
        lhs = self.ternary()
        t = self.peek()
        if t[0] == "op" and t[1] in self.ASSIGN:
            self.next()
            if lhs[0] not in ("id", "idx"): raise CppError("left side of assignment must be a variable", t[2])
            return ("assign", t[1], lhs, self.assign(), t[2])
        return lhs

    def ternary(self):
        c = self.binary(0)
        if self.accept("?"):
            a = self.expr(); self.expect(":"); b = self.ternary()
            return ("tern", c, a, b)
        return c

    LEVELS = [["||"], ["&&"], ["|"], ["^"], ["&"], ["==", "!="], ["<", ">", "<=", ">="], ["<<", ">>"], ["+", "-"], ["*", "/", "%"]]

    def binary(self, lvl):
        if lvl == len(self.LEVELS): return self.unary()
        e = self.binary(lvl + 1)
        while self.peek()[0] == "op" and self.peek()[1] in self.LEVELS[lvl]:
            op = self.next(); e = ("bin", op[1], e, self.binary(lvl + 1), op[2])
        return e

    def unary(self):
        t = self.peek()
        if t[0] == "op":
            if t[1] in ("!", "-", "+", "~"):
                self.next(); return ("un", t[1], self.unary(), t[2])
            if t[1] in ("++", "--"):
                self.next(); tg = self.unary(); return ("assign", "+=" if t[1] == "++" else "-=", tg, ("num", 1), t[2])
            if t[1] == "(" and self.is_type(1):
                self.next(); sp, _ = self.parse_type(); self.expect(")"); return ("cast", sp, self.unary())
            if t[1] in ("*", "&"):
                raise CppError("pointers and references are not supported", t[2])
        if t[0] == "id" and t[1] == "sizeof":
            self.next(); self.expect("(")
            if self.is_type():
                sp, _ = self.parse_type(); self.expect(")"); return ("num", {"int": (sp[1] // 8 if sp[0] == "int" else 4), "float": 4, "bool": 1}.get(sp[0], 1) if sp[0] != "int" else sp[1] // 8)
            e = self.expr(); self.expect(")"); return ("sizeof", e)
        return self.postfix()

    def postfix(self):
        e = self.primary()
        while True:
            t = self.peek()
            if t[0] == "op" and t[1] == "[":
                self.next(); i = self.expr(); self.expect("]"); e = ("idx", e, i, t[2])
            elif t[0] == "op" and t[1] == "(":
                if e[0] != "id": raise CppError("only named functions can be called", t[2])
                self.next(); args = []
                if not self.accept(")"):
                    while True:
                        args.append(self.assign())
                        if self.accept(")"): break
                        self.expect(",")
                e = ("call", e[1], args, t[2])
            elif t[0] == "op" and t[1] == ".":
                self.next(); m = self.ident(); self.expect("("); args = []
                if not self.accept(")"):
                    while True:
                        args.append(self.assign())
                        if self.accept(")"): break
                        self.expect(",")
                e = ("mcall", e, m, args, t[2])
            elif t[0] == "op" and t[1] in ("++", "--"):
                self.next(); e = ("post", t[1], e, t[2])
            else:
                return e

    def primary(self):
        k, v, ln = self.next()
        if k == "num":
            s = v.rstrip("uUlL") if not re.search(r"[.eE]", v) or v.lower().startswith("0x") else v.rstrip("fF")
            if re.search(r"[.]", v) or (re.search(r"[eE]", v) and not v.lower().startswith("0x")):
                return ("num", float(v.rstrip("fF")))
            if s.lower().startswith("0x"): return ("num", int(s, 16))
            if s.lower().startswith("0b"): return ("num", int(s[2:], 2))
            return ("num", int(s, 10))
        if k == "str": return ("str", _unesc(v[1:-1]))
        if k == "chr": return ("chr", ord(_unesc(v[1:-1])))
        if k == "id":
            if v in NOT_SUPPORTED: raise CppError(f"C++ feature not supported: {NOT_SUPPORTED[v]}", ln)
            return ("id", v, ln)
        if v == "(":
            e = self.expr(); self.expect(")"); return e
        raise CppError(f"unexpected '{v or 'end of file'}'", ln)


def parse(src):
    return Parser(lex(src)).program()


# ------------------------------------------------------------------------------------------------ interpreter
class _Break(Exception): pass
class _Continue(Exception): pass
class _Return(Exception):
    def __init__(self, v): self.v = v


class Var:
    __slots__ = ("spec", "val", "arr")

    def __init__(self, spec, val, arr=False):
        self.spec, self.val, self.arr = spec, val, arr


CONSTS = {"HIGH": 1, "LOW": 0, "INPUT": 0, "OUTPUT": 1, "INPUT_PULLUP": 2, "LED_BUILTIN": 13, "true": True, "false": False, "PI": math.pi, "M_PI": math.pi,
          "A0": 14, "A1": 15, "A2": 16, "A3": 17, "A4": 18, "A5": 19, "DEC": 10, "HEX": 16, "BIN": 2, "OCT": 8, "NULL": 0}


class Interp:
    """`dev` is the device object providing: pin_mode, write, read, analog_read, analog_write, delay, now_s, serial, tone, no_tone, tick, rng."""

    def __init__(self, program, dev):
        self.globs_decl, self.funcs = program
        self.dev = dev
        self.g: dict[str, Var] = {}
        self.scopes: list[dict] = []
        self.rng = random.Random(1)
        self.depth = 0

    # -- environment
    def lookup(self, name, ln):
        for sc in reversed(self.scopes):
            if name in sc: return sc[name]
        if name in self.g: return self.g[name]
        raise CppError(f"'{name}' was not declared in this scope", ln)

    def declare(self, spec, name, size, init, ln, scope):
        if size is not None:
            n = None if size == ("auto",) else int(self.eval(size))
            if init is not None:
                vals = [self.eval(e) for e in init[1]] if init[0] == "list" else None
                if vals is None: raise CppError("array initialiser must use { }", ln)
                n = len(vals) if n is None else n
                if len(vals) > n: raise CppError("too many initialisers for array", ln)
                vals = [wrap(v, spec) for v in vals] + [wrap(0, spec)] * (n - len(vals))
            else:
                if n is None: raise CppError("array size missing", ln)
                vals = [wrap(0, spec) if spec[0] != "str" else "" for _ in range(n)]
            scope[name] = Var(spec, vals, True)
        else:
            v = self.eval(init) if init is not None else (0 if spec[0] != "str" else "")
            scope[name] = Var(spec, wrap(v, spec))

    def run_globals(self):
        for d in self.globs_decl:
            _, spec, name, size, init, ln = d
            self.declare(spec, name, size, init, ln, self.g)

    def call_user(self, name, args, ln):
        if name not in self.funcs: raise CppError(f"'{name}' was not declared in this scope", ln)
        spec, params, body, _ = self.funcs[name]
        if len(args) != len(params): raise CppError(f"function '{name}' expects {len(params)} argument(s), got {len(args)}", ln)
        self.depth += 1
        if self.depth > 60: raise CppError("stack overflow (recursion too deep)", ln)
        sc = {}
        for (ps, pn, arr), a in zip(params, args):
            sc[pn] = Var(ps, a if arr else wrap(a, ps), arr)
        self.scopes.append(sc)
        try:
            self.exec(body)
            r = None
        except _Return as ret:
            r = ret.v
        finally:
            self.scopes.pop(); self.depth -= 1
        return wrap(r, spec) if (r is not None and spec[0] != "void") else r

    # -- statements
    def exec(self, s):
        self.dev.tick()
        k = s[0]
        if k == "block":
            self.scopes.append({})
            try:
                for st in s[1]: self.exec(st)
            finally:
                self.scopes.pop()
        elif k == "decls":
            for st in s[1]: self.exec(st)
        elif k == "decl":
            _, spec, name, size, init, ln = s
            self.declare(spec, name, size, init, ln, self.scopes[-1] if self.scopes else self.g)
        elif k == "expr": self.eval(s[1])
        elif k == "if":
            if self.truth(self.eval(s[1])): self.exec(s[2])
            elif s[3] is not None: self.exec(s[3])
        elif k == "while":
            while self.truth(self.eval(s[1])):
                try: self.exec(s[2])
                except _Break: break
                except _Continue: continue
        elif k == "do":
            while True:
                try: self.exec(s[1])
                except _Break: break
                except _Continue: pass
                if not self.truth(self.eval(s[2])): break
        elif k == "for":
            self.scopes.append({})
            try:
                if s[1] is not None: self.exec(s[1])
                while s[2] is None or self.truth(self.eval(s[2])):
                    try: self.exec(s[4])
                    except _Break: break
                    except _Continue: pass
                    if s[3] is not None: self.eval(s[3])
            finally:
                self.scopes.pop()
        elif k == "switch":
            v = self.eval(s[1]); matched = False
            try:
                for lab, body in s[2]:
                    if not matched and (lab is None or self.eval(lab) == v): matched = True
                    if matched:
                        for st in body: self.exec(st)
                if not matched:                      # default not last
                    for lab, body in s[2]:
                        if lab is None: matched = True
                        if matched:
                            for st in body: self.exec(st)
            except _Break:
                pass
        elif k == "break": raise _Break()
        elif k == "continue": raise _Continue()
        elif k == "return": raise _Return(self.eval(s[1]) if s[1] is not None else None)
        else: raise CppError(f"internal: unknown statement {k}")

    @staticmethod
    def truth(v):
        return bool(v) if not isinstance(v, str) else bool(v)

    # -- expressions
    def eval(self, e):
        self.dev.tick()
        k = e[0]
        if k == "num": return e[1]
        if k == "str": return e[1]
        if k == "chr": return Ch(e[1])
        if k == "id":
            name, ln = e[1], e[2]
            for sc in reversed(self.scopes):
                if name in sc: return sc[name].val
            if name in self.g: return self.g[name].val
            if name in CONSTS: return CONSTS[name]
            raise CppError(f"'{name}' was not declared in this scope", ln)
        if k == "bin": return self.binop(e)
        if k == "un":
            v = self.eval(e[2])
            return {"!": lambda: not self.truth(v), "-": lambda: -v, "+": lambda: +v, "~": lambda: ~int(v)}[e[1]]()
        if k == "assign": return self.assign(e)
        if k == "post":
            old = self.eval(e[2]); self.assign(("assign", "+=" if e[1] == "++" else "-=", e[2], ("num", 1), e[3])); return old
        if k == "tern": return self.eval(e[2]) if self.truth(self.eval(e[1])) else self.eval(e[3])
        if k == "idx":
            base = self.eval(e[1]); i = int(self.eval(e[2]))
            if not isinstance(base, list): raise CppError("subscripted value is not an array", e[3])
            if not 0 <= i < len(base): raise CppError(f"array index {i} out of range (size {len(base)})", e[3])
            return base[i]
        if k == "call": return self.call(e)
        if k == "mcall": return self.mcall(e)
        if k == "cast": return wrap(self.eval(e[2]), e[1])
        if k == "comma": self.eval(e[1]); return self.eval(e[2])
        if k == "sizeof":
            v = self.eval(e[1]); return len(v) if isinstance(v, list) else 2
        raise CppError(f"internal: unknown expression {k}")

    def binop(self, e):
        op, ln = e[1], e[4]
        if op == "&&": return self.truth(self.eval(e[2])) and self.truth(self.eval(e[3]))
        if op == "||": return self.truth(self.eval(e[2])) or self.truth(self.eval(e[3]))
        a, b = self.eval(e[2]), self.eval(e[3])
        if isinstance(a, str) or isinstance(b, str):
            if op == "+": return _to_str(a) + _to_str(b)
            if op in ("==", "!="): return (a == b) == (op == "==")
            raise CppError(f"operator {op} is not valid for String", ln)
        if op == "+": return a + b
        if op == "-": return a - b
        if op == "*": return a * b
        if op in ("/", "%"):
            if b == 0:
                if op == "/" and (isinstance(a, float) or isinstance(b, float)): return float("inf")
                raise CppError("division by zero", ln)
            if isinstance(a, float) or isinstance(b, float):
                if op == "/": return a / b
                return math.fmod(a, b)
            q = abs(int(a)) // abs(int(b)) * (1 if (a >= 0) == (b >= 0) else -1)
            return q if op == "/" else int(a) - q * int(b)
        if op == "<": return a < b
        if op == ">": return a > b
        if op == "<=": return a <= b
        if op == ">=": return a >= b
        if op == "==": return a == b
        if op == "!=": return a != b
        a, b = int(a), int(b)
        if op == "&": return a & b
        if op == "|": return a | b
        if op == "^": return a ^ b
        if op == "<<": return a << b
        if op == ">>": return a >> b
        raise CppError(f"unknown operator {op}", ln)

    def assign(self, e):
        _, op, tgt, val, ln = e
        v = self.eval(val)
        if tgt[0] == "id":
            var = self.lookup(tgt[1], tgt[2])
            if var.arr: raise CppError("cannot assign to an array", ln)
            cur = var.val
            if op != "=":
                v = self.binop(("bin", op[:-1], ("num", cur) if not isinstance(cur, str) else ("str", cur), ("num", v) if not isinstance(v, str) else ("str", v), ln))
            var.val = wrap(v, var.spec); return var.val
        base_node, idx_node = tgt[1], tgt[2]
        if base_node[0] != "id": raise CppError("only simple arrays can be indexed", ln)
        var = self.lookup(base_node[1], ln); i = int(self.eval(idx_node))
        if not var.arr: raise CppError("subscripted value is not an array", ln)
        if not 0 <= i < len(var.val): raise CppError(f"array index {i} out of range (size {len(var.val)})", ln)
        if op != "=":
            v = self.binop(("bin", op[:-1], ("num", var.val[i]), ("num", v), ln))
        var.val[i] = wrap(v, var.spec); return var.val[i]

    # -- calls
    def call(self, e):
        name, args, ln = e[1], e[2], e[3]
        if name in self.funcs:
            return self.call_user(name, [self.eval(a) for a in args], ln)
        vals = [self.eval(a) for a in args]
        fn = getattr(self, "f_" + name, None)
        if fn is None: raise CppError(f"'{name}' was not declared in this scope (library functions are not available)", ln)
        try:
            return fn(*vals)
        except TypeError:
            raise CppError(f"wrong number of arguments to {name}()", ln)

    def mcall(self, e):
        obj, m, args, ln = e[1], e[2], e[3], e[4]
        vals = [self.eval(a) for a in args]
        if obj[0] == "id" and obj[1] == "Serial":
            return self.serial(m, vals, ln)
        o = self.eval(obj)
        if isinstance(o, str):
            if m == "length": return len(o)
            if m == "charAt": return Ch(ord(o[int(vals[0])]))
            if m == "toInt": return int(re.match(r"\s*-?\d+", o).group()) if re.match(r"\s*-?\d+", o) else 0
            if m == "indexOf": return o.find(_to_str(vals[0]))
        raise CppError(f"method .{m}() is not supported", ln)

    def serial(self, m, v, ln):
        d = self.dev
        if m == "begin": d.serial_begin(int(v[0]) if v else 9600); return None
        if m in ("print", "println"):
            if not v: s = ""
            else:
                x = v[0]
                if isinstance(x, float) and not isinstance(x, bool): s = f"{x:.{int(v[1]) if len(v) > 1 else 2}f}"
                elif isinstance(x, Ch) and len(v) == 1: s = chr(x & 255)
                elif isinstance(x, int) and not isinstance(x, bool) and len(v) > 1:
                    base = int(v[1]); s = {16: f"{x & 0xFFFFFFFF:X}" if x < 0 else f"{x:X}", 2: bin(x & 0xFFFFFFFF)[2:] if x < 0 else bin(x)[2:], 8: oct(x)[2:]}.get(base, str(x))
                else: s = _to_str(x)
            d.serial_write(s + ("\n" if m == "println" else "")); return None
        if m == "write": d.serial_write(chr(int(v[0]) & 255) if not isinstance(v[0], str) else v[0]); return None
        if m == "available": return 0
        if m in ("read", "peek"): return -1
        if m == "flush": return None
        raise CppError(f"Serial.{m}() is not supported", ln)

    # -- Arduino API
    def f_pinMode(self, pin, mode): self.dev.pin_mode(int(pin), int(mode))
    def f_digitalWrite(self, pin, val): self.dev.write(int(pin), 1 if val else 0)
    def f_digitalRead(self, pin): return self.dev.read(int(pin))
    def f_analogRead(self, pin): return self.dev.analog_read(int(pin))
    def f_analogWrite(self, pin, v): self.dev.analog_write(int(pin), max(0, min(255, int(v))))
    def f_delay(self, ms): self.dev.delay(max(0.0, float(ms)) / 1000.0)
    def f_delayMicroseconds(self, us): self.dev.delay(max(0.0, float(us)) / 1e6)
    def f_millis(self): return wrap(int(self.dev.now_s() * 1000), ("int", 32, False, False))
    def f_micros(self): return wrap(int(self.dev.now_s() * 1e6), ("int", 32, False, False))
    def f_tone(self, pin, f, *dur): self.dev.tone(int(pin), float(f), (float(dur[0]) / 1000.0) if dur else None)
    def f_noTone(self, pin): self.dev.no_tone(int(pin))
    def f_abs(self, x): return abs(x)
    def f_min(self, a, b): return a if a < b else b
    def f_max(self, a, b): return a if a > b else b
    def f_constrain(self, x, lo, hi): return lo if x < lo else hi if x > hi else x
    def f_sq(self, x): return x * x
    def f_sqrt(self, x): return math.sqrt(x)
    def f_pow(self, a, b): return float(a) ** float(b)
    def f_sin(self, x): return math.sin(x)
    def f_cos(self, x): return math.cos(x)
    def f_tan(self, x): return math.tan(x)
    def f_floor(self, x): return float(math.floor(x))
    def f_ceil(self, x): return float(math.ceil(x))
    def f_round(self, x): return float(math.floor(x + 0.5))
    def f_log(self, x): return math.log(x)
    def f_exp(self, x): return math.exp(x)
    def f_randomSeed(self, s): self.rng.seed(int(s))
    def f_bitRead(self, v, b): return (int(v) >> int(b)) & 1
    def f_bitSet(self, v, b): return int(v) | (1 << int(b))
    def f_bitClear(self, v, b): return int(v) & ~(1 << int(b))
    def f_lowByte(self, v): return int(v) & 255
    def f_highByte(self, v): return (int(v) >> 8) & 255
    def f_isDigit(self, c): return chr(int(c)).isdigit()

    def f_random(self, a, b=None):
        lo, hi = (0, int(a)) if b is None else (int(a), int(b))
        return self.rng.randrange(lo, hi) if hi > lo else lo

    def f_map(self, x, a, b, c, d):
        x, a, b, c, d = int(x), int(a), int(b), int(c), int(d)
        if b == a: raise CppError("map(): input range is empty")
        n = (x - a) * (d - c); den = b - a
        q = abs(n) // abs(den) * (1 if (n >= 0) == (den >= 0) else -1)
        return q + c


def check_syntax(src):
    """Returns (ok, message). Also verifies setup() and loop() exist."""
    try:
        g, f = parse(src)
    except CppError as e:
        return False, str(e)
    for need in ("setup", "loop"):
        if need not in f:
            return False, f"the sketch must define void {need}()"
    return True, "OK"
