"""Example sketches shipped with the app (all verified by tests)."""

BLINK = """// Blink: toggle pin 13 every 500 ms
#define LED 13

void setup() {
  pinMode(LED, OUTPUT);
}

void loop() {
  digitalWrite(LED, HIGH);
  delay(500);
  digitalWrite(LED, LOW);
  delay(500);
}
"""

BUTTON = """// Button -> LED with a software debounce
const int BUTTON = 2;
const int LED = 8;
int state = 0;

void setup() {
  pinMode(BUTTON, INPUT);
  pinMode(LED, OUTPUT);
}

void loop() {
  int reading = digitalRead(BUTTON);
  delay(20);                       // debounce interval
  if (reading == digitalRead(BUTTON)) {
    state = reading;
  }
  digitalWrite(LED, state);
}
"""

PWM = """// PWM: 25 % duty on pin 9 (analogWrite 64 of 255), 490 Hz
void setup() {
  pinMode(9, OUTPUT);
  analogWrite(9, 64);
}

void loop() {
  delay(100);
}
"""

TRAFFIC = """// Traffic-light controller: red 3 s, green 2 s, yellow 1 s
const int RED = 2, YELLOW = 3, GREEN = 4;

void setup() {
  pinMode(RED, OUTPUT);
  pinMode(YELLOW, OUTPUT);
  pinMode(GREEN, OUTPUT);
}

void light(int r, int y, int g) {
  digitalWrite(RED, r);
  digitalWrite(YELLOW, y);
  digitalWrite(GREEN, g);
}

void loop() {
  light(1, 0, 0); delay(3000);
  light(0, 0, 1); delay(2000);
  light(0, 1, 0); delay(1000);
}
"""

SERIAL = """// Serial: print a counter every second
int n = 0;

void setup() {
  Serial.begin(9600);
  Serial.println("Hello, ECE Lab");
}

void loop() {
  Serial.print("count = ");
  Serial.println(n);
  n++;
  delay(1000);
}
"""

DVM = """// Digital voltmeter: read A0 (0..1023 -> 0..5 V) and print it
void setup() {
  Serial.begin(9600);
}

void loop() {
  int raw = analogRead(A0);
  float volts = raw * 5.0 / 1023.0;
  Serial.print("V = ");
  Serial.println(volts);
  delay(500);
}
"""

EXAMPLES = {"Blink": BLINK, "Button + debounce": BUTTON, "PWM 25 %": PWM, "Traffic light": TRAFFIC, "Serial counter": SERIAL, "Digital voltmeter": DVM}
