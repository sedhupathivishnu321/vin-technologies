"""Thread-free sketch interpreter for the browser build (Pyodide has no threads).

The evaluator in cpp.py is rewritten at import time into generators: every call that can end up in delay() becomes `yield from`, and delay()
itself yields the wake-up time to the runner. The semantics are identical to the threaded interpreter, only the hand-off differs.
"""
from __future__ import annotations
import inspect
import re

from .cpp import Interp

GEN_METHODS = ("eval", "exec", "binop", "assign", "call", "mcall", "call_user", "declare", "run_globals")
_CALL = re.compile(r"self\.(" + "|".join(GEN_METHODS) + r")\(")


def _close_paren(src: str, open_idx: int) -> int:
    depth = 0; i = open_idx; q = None
    while i < len(src):
        ch = src[i]
        if q:
            if ch == "\\":
                i += 1
            elif ch == q:
                q = None
        elif ch in "\"'":
            q = ch
        elif ch == "(":
            depth += 1
        elif ch == ")":
            depth -= 1
            if depth == 0:
                return i
        i += 1
    raise ValueError("unbalanced parentheses")


def _transform(src: str) -> str:
    src = src.replace("[self.eval(e) for e in init[1]]", "(yield from self._evall(init[1]))").replace("[self.eval(a) for a in args]", "(yield from self._evall(args))")
    starts = [m.start() for m in _CALL.finditer(src)]
    for st in reversed(starts):
        op = src.index("(", st)
        cl = _close_paren(src, op)
        src = src[:st] + "(yield from " + src[st:cl + 1] + ")" + src[cl + 1:]
    return src


def _build():
    out = ["class GInterp(Interp):\n",
           "    def _evall(self, nodes):\n        out = []\n        for n in nodes:\n            out.append((yield from self.eval(n)))\n        return out\n\n",
           "    def f_delay(self, ms):\n        return ('__wait__', max(0.0, float(ms)) / 1000.0)\n\n",
           "    def f_delayMicroseconds(self, us):\n        return ('__wait__', max(0.0, float(us)) / 1e6)\n\n"]
    for name in GEN_METHODS:
        s = inspect.getsource(getattr(Interp, name))
        s = _transform(s)
        if name == "call":
            a = "            return fn(*vals)\n"
            assert a in s, "call(): unexpected source"
            s = s.replace(a, "            r = fn(*vals)\n            if type(r) is tuple and r[:1] == ('__wait__',):\n"
                             "                self.dev._yielded = True\n                yield self.dev.t + r[1]\n                return None\n            return r\n")
        out.append(s + "\n")
    ns = {"Interp": Interp}
    ns.update({k: v for k, v in vars(__import__("ecelab.mcu.cpp", fromlist=["x"])).items() if not k.startswith("__")})
    exec(compile("".join(out), "<ecelab.mcu.gen>", "exec"), ns)
    return ns["GInterp"]


GInterp = _build()
