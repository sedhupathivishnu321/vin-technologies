"""Event scheduler that drives a sketch runner inside a time-stepped (analog) simulation.

The sketch sleeps in delay(); the host wakes it at its wake-up time, feeds it the pin voltages as logic levels, and generates PWM / tone edges.
Every output change is logged with its time so the buzzer audio can be synthesised from the real waveform.
"""
from __future__ import annotations
import heapq
import itertools

from .runner import McuRunner, McuError

D_PINS = range(2, 14)


class McuHost:
    def __init__(self, runner: McuRunner):
        self.r = runner
        self.heap = []
        self.seq = itertools.count()
        self.token = {}
        self.log: dict[int, list] = {}
        self._last: dict[int, int] = {}
        heapq.heappush(self.heap, (0.0, next(self.seq), "wake", None))

    def advance(self, t: float, read_pin, set_analog=None):
        """Process every event due at or before t. read_pin(pin) -> 0/1/None (None = floating)."""
        while self.heap and self.heap[0][0] <= t + 1e-12:
            tt, _, kind, extra = heapq.heappop(self.heap)
            if kind == "wake":
                inputs = {p: read_pin(p) for p in D_PINS}
                if set_analog:
                    set_analog(self.r.analog)
                wake = self.r.resume(tt, inputs)                 # raises McuError
                if wake is not None:
                    heapq.heappush(self.heap, (max(wake, tt), next(self.seq), "wake", None))
                for pin in sorted(self.r.pwm_dirty):
                    self.token[pin] = self.token.get(pin, 0) + 1
                    cfg = self.r.pwm.get(pin)
                    if cfg:
                        self.r.levels[pin] = 1
                        heapq.heappush(self.heap, (tt + cfg[0] * cfg[1], next(self.seq), "pwm", (pin, self.token[pin], 0)))
                self.r.pwm_dirty.clear()
            else:
                pin, tok, level = extra
                if self.token.get(pin) != tok or pin not in self.r.pwm:
                    continue
                duty, period = self.r.pwm[pin]
                self.r.levels[pin] = level
                nxt = tt + (duty * period if level == 1 else (1 - duty) * period)
                heapq.heappush(self.heap, (nxt, next(self.seq), "pwm", (pin, tok, 1 - level)))
            self._record(tt)

    def _record(self, t):
        for pin, mode in self.r.modes.items():
            if mode == 1:
                lv = self.r.levels.get(pin, 0)
                if self._last.get(pin) != lv:
                    self._last[pin] = lv
                    self.log.setdefault(pin, []).append((t, lv))

    def stop(self):
        self.r.stop()
