"""Runs a sketch on a virtual Arduino-class MCU with cooperative virtual time (thread hand-off at delay()).

The sketch runs on its own thread but only while the simulator is blocked waiting for it, so execution is deterministic.
Timing model: only delay()/delayMicroseconds() advance time; a loop() that never delays costs LOOP_COST seconds per iteration.
"""
from __future__ import annotations
import threading

from .cpp import parse, Interp, CppError, CONSTS

LOOP_COST = 100e-6
STEP_BUDGET = 2_000_000
PWM_PERIOD = 1 / 490.0


class _Halt(BaseException):
    pass


class McuError(Exception):
    pass


class McuRunner:
    def __init__(self, source: str, analog=(0, 0, 0, 0, 0, 0), seed=1, ref="U1"):
        self.ref = ref
        try:
            self.program = parse(source)
        except CppError as e:
            raise McuError(str(e)) from e
        for need in ("setup", "loop"):
            if need not in self.program[1]:
                raise McuError(f"the sketch must define void {need}()")
        self.analog = list(analog) + [0] * (6 - len(analog))
        self.modes: dict[int, int] = {}
        self.levels: dict[int, int] = {}
        self.pullup: set[int] = set()
        self.pwm: dict[int, tuple] = {}          # pin -> (duty fraction, period)
        self.pwm_dirty: set[int] = set()
        self.inputs: dict[int, int | None] = {}
        self.serial: list[tuple] = []
        self.baud = None
        self.tones: list[tuple] = []
        self.t = 0.0
        self.wake: float | None = 0.0
        self.error: str | None = None
        self.steps = 0
        self._to_sketch = threading.Semaphore(0)
        self._to_main = threading.Semaphore(0)
        self._thread = None
        self._halt = False
        self._done = False
        self._yielded = False
        self.interp = Interp(self.program, self)
        self.interp.rng.seed(seed)

    # ---- device API used by the interpreter (runs on the sketch thread)
    def tick(self):
        self.steps += 1
        if self.steps > STEP_BUDGET:
            raise CppError("the sketch ran too long without calling delay() (infinite loop?)")

    def pin_mode(self, pin, mode):
        self.modes[pin] = mode
        if mode == 2:
            self.pullup.add(pin)
        else:
            self.pullup.discard(pin)

    def write(self, pin, v):
        if self.modes.get(pin, 0) == 0:                      # INPUT: write toggles the pull-up (AVR behaviour)
            (self.pullup.add if v else self.pullup.discard)(pin)
            return
        self.levels[pin] = v
        if pin in self.pwm:
            self.pwm.pop(pin); self.pwm_dirty.add(pin)

    def read(self, pin):
        if self.modes.get(pin) == 1:
            return self.levels.get(pin, 0)
        v = self.inputs.get(pin)
        if v is None:
            return 1 if pin in self.pullup else 0
        return int(v)

    def analog_read(self, pin):
        i = pin - 14 if pin >= 14 else pin
        if not 0 <= i < 6:
            raise CppError(f"analogRead({pin}): not an analog pin")
        return int(max(0, min(1023, self.analog[i])))

    def analog_write(self, pin, v):
        if self.modes.get(pin) != 1:
            self.modes[pin] = 1
        if v <= 0:
            self.pwm.pop(pin, None); self.levels[pin] = 0
        elif v >= 255:
            self.pwm.pop(pin, None); self.levels[pin] = 1
        else:
            self.pwm[pin] = (v / 255.0, PWM_PERIOD)
        self.pwm_dirty.add(pin)

    def tone(self, pin, f, dur):
        self.modes[pin] = 1
        if f > 0:
            self.pwm[pin] = (0.5, 1.0 / f); self.pwm_dirty.add(pin)
            self.tones.append((self.t, pin, f))

    def no_tone(self, pin):
        self.pwm.pop(pin, None); self.levels[pin] = 0; self.pwm_dirty.add(pin)

    def serial_begin(self, baud):
        self.baud = baud

    def serial_write(self, s):
        self.serial.append((self.t, s))

    def now_s(self):
        return self.t

    def delay(self, dt):
        self._yield(self.t + dt)

    def _yield(self, wake):
        self._yielded = True
        self.wake = wake
        self._to_main.release()
        self._to_sketch.acquire()
        if self._halt:
            raise _Halt()

    # ---- thread body
    def _main(self):
        try:
            it = self.interp
            it.run_globals()
            it.call_user("setup", [], 0)
            while True:
                self._yielded = False
                it.call_user("loop", [], 0)
                if not self._yielded:                      # a loop() without delay() still costs time
                    self._yield(self.t + LOOP_COST)
        except _Halt:
            pass
        except CppError as e:
            self.error = str(e)
        except RecursionError:
            self.error = "stack overflow in sketch"
        except Exception as e:                                       # noqa: BLE001 — never let a sketch bug kill the simulator
            self.error = f"{type(e).__name__}: {e}"
        finally:
            self._done = True
            self.wake = None
            self._to_main.release()

    # ---- simulator side
    def resume(self, now: float, inputs: dict):
        """Run the sketch until its next delay. Returns the wake-up time (None when the sketch ended). Raises McuError."""
        if self._done:
            return None
        self.inputs = inputs
        self.t = now
        self.steps = 0
        if self._thread is None:
            self._thread = threading.Thread(target=self._main, daemon=True)
            self._thread.start()
        else:
            self._to_sketch.release()
        self._to_main.acquire()
        if self.error:
            raise McuError(f"{self.ref}: {self.error}")
        return self.wake

    def stop(self):
        if self._thread is not None and not self._done:
            self._halt = True
            self._to_sketch.release()
            self._thread.join(timeout=1.0)

    def serial_text(self):
        return "".join(s for _, s in self.serial)


def compile_check(source: str):
    """(ok, message) for the editor's Compile button."""
    try:
        r = McuRunner(source)
    except McuError as e:
        return False, str(e)
    return True, f"OK — {len(r.program[1])} function(s), {len(r.program[0])} global declaration(s)"
