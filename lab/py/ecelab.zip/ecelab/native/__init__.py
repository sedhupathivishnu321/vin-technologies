"""Native C++ core (llcore.dll, source in native/llcore.cpp): dense LU solver for the circuit engine. Falls back to NumPy when the library is absent."""
from __future__ import annotations
import ctypes
import os
import sys

import numpy as np

_lib = None
_tried = False


def _candidates():
    here = os.path.dirname(os.path.abspath(__file__))
    out = [os.path.join(here, "llcore.dll")]
    base = getattr(sys, "_MEIPASS", None)
    if base:
        out += [os.path.join(base, "ecelab", "native", "llcore.dll"), os.path.join(base, "llcore.dll")]
    return out


def _load():
    global _lib, _tried
    if _tried:
        return _lib
    _tried = True
    if os.environ.get("ECELAB_NO_NATIVE"):
        return None
    for p in _candidates():
        if os.path.exists(p):
            try:
                lib = ctypes.CDLL(p)
                lib.ll_solve.restype = ctypes.c_int
                lib.ll_solve.argtypes = [ctypes.c_int, ctypes.c_void_p, ctypes.c_void_p, ctypes.c_void_p, ctypes.c_void_p]
                lib.ll_version.restype = ctypes.c_int
                _lib = lib
                break
            except OSError:
                continue
    return _lib


def available() -> bool:
    return _load() is not None


def version() -> int:
    lib = _load()
    return int(lib.ll_version()) if lib else 0


def solve(A, b):
    """Solve A x = b. Returns (x, status, residual) with status 0 = ok, 1 = singular, 2 = non-finite result."""
    lib = _load()
    A = np.ascontiguousarray(A, dtype=np.float64)
    b = np.ascontiguousarray(b, dtype=np.float64)
    n = len(b)
    if lib is None:
        try:
            x = np.linalg.solve(A, b)
        except np.linalg.LinAlgError:
            return np.zeros(n), 1, 0.0
        return x, (0 if np.all(np.isfinite(x)) else 2), float(np.max(np.abs(A @ x - b))) if n else 0.0
    x = np.empty(n, dtype=np.float64)
    res = ctypes.c_double(0.0)
    st = lib.ll_solve(n, A.ctypes.data, b.ctypes.data, x.ctypes.data, ctypes.byref(res))
    return x, int(st), float(res.value)
