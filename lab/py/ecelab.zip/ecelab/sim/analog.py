"""Analog circuit engine: modified nodal analysis with Newton iteration.

Supported analyses: DC operating point, DC sweep, transient (trapezoidal, BE start-up), AC small-signal sweep.
Nonlinear devices: diode/LED/Zener (Shockley + breakdown), NPN BJT (Ebers-Moll), op-amp (tanh-saturating VCVS).
Fails loudly (SimError) on singular matrices or non-convergence; never falls back to ideal behaviour silently.
"""
from __future__ import annotations
import math
import numpy as np
from .. import native
try:
    from scipy.linalg import lu_factor, lu_solve
except ImportError:                                                  # browser build (Pyodide) ships NumPy only: invert once, multiply per step
    def lu_factor(A, check_finite=True):
        return (np.linalg.inv(A), None)

    def lu_solve(lu, b):
        return lu[0] @ b

from .base import Engine, SimError, Diagnostic, Cancelled
from ..core import parts
from ..mcu.host import McuHost
from ..mcu.runner import McuRunner, McuError

VT = 0.025852
GMIN = 1e-12
VMETER_R = 1e7


def _exp(x):
    return math.exp(x) if x < 100 else math.exp(100) * (1 + x - 100)


def _pnjlim(vnew, vold, vt, vcrit):
    if vnew > vcrit and abs(vnew - vold) > 2 * vt:
        if vold > 0:
            arg = 1 + (vnew - vold) / vt
            vnew = vold + vt * math.log(arg) if arg > 0 else vcrit
        else:
            vnew = vt * math.log(vnew / vt)
    return vnew


class Ctx:
    __slots__ = ("mode", "t", "dt", "first", "w")

    def __init__(self, mode="dc", t=0.0, dt=1.0, first=False, w=0.0):
        self.mode, self.t, self.dt, self.first, self.w = mode, t, dt, first, w


def _v(x, i):
    return 0.0 if i < 0 else x[i]


def _g(A, i, j, val):
    if i >= 0 and j >= 0:
        A[i, j] += val


def _stamp_g(A, a, b, g):
    _g(A, a, a, g); _g(A, b, b, g); _g(A, a, b, -g); _g(A, b, a, -g)


def _add(vec, i, val):
    if i >= 0:
        vec[i] += val


class El:
    nl = False
    ref = ""
    cid = None

    def matrix(self, A, m): ...
    def rhs(self, b, m): ...
    def accept(self, x, m): ...
    def reset(self, x=None): ...


class Res(El):
    def __init__(s, ref, a, b, R):
        s.ref, s.a, s.b, s.R = ref, a, b, R

    def matrix(s, A, m):
        _stamp_g(A, s.a, s.b, 1.0 / s.R)

    def current(s, x):
        return (_v(x, s.a) - _v(x, s.b)) / s.R


class Cap(El):
    def __init__(s, ref, a, b, C, v0):
        s.ref, s.a, s.b, s.C, s.v0 = ref, a, b, C, v0
        s.vp = v0; s.ip = 0.0

    def reset(s, x=None):
        s.vp = s.v0 if x is None else _v(x, s.a) - _v(x, s.b)
        s.ip = 0.0

    def matrix(s, A, m):
        if m.mode == "dc":
            return
        if m.mode == "ac":
            g = 1j * m.w * s.C
        else:
            g = s.C / m.dt if m.first else 2 * s.C / m.dt
        _stamp_g(A, s.a, s.b, g)

    def rhs(s, b, m):
        if m.mode != "tran":
            return
        ieq = (s.C / m.dt) * s.vp if m.first else (2 * s.C / m.dt) * s.vp + s.ip
        _add(b, s.a, ieq); _add(b, s.b, -ieq)

    def accept(s, x, m):
        v = _v(x, s.a) - _v(x, s.b)
        s.ip = (s.C / m.dt) * (v - s.vp) if m.first else (2 * s.C / m.dt) * (v - s.vp) - s.ip
        s.vp = v


class Ind(El):
    def __init__(s, ref, a, b, L, i0, k):
        s.ref, s.a, s.b, s.L, s.i0, s.k = ref, a, b, L, i0, k
        s.ip = i0; s.vp = 0.0

    def reset(s, x=None):
        s.ip = s.i0 if x is None else x[s.k]
        s.vp = 0.0

    def matrix(s, A, m):
        k = s.k
        _g(A, s.a, k, 1); _g(A, s.b, k, -1); _g(A, k, s.a, 1); _g(A, k, s.b, -1)
        if m.mode == "ac":
            A[k, k] -= 1j * m.w * s.L
        elif m.mode == "tran":
            A[k, k] -= s.L / m.dt if m.first else 2 * s.L / m.dt

    def rhs(s, b, m):
        if m.mode == "tran":
            Z = s.L / m.dt if m.first else 2 * s.L / m.dt
            b[s.k] = -Z * s.ip - (0.0 if m.first else s.vp)

    def accept(s, x, m):
        s.ip = x[s.k]; s.vp = _v(x, s.a) - _v(x, s.b)


class VSrc(El):
    """kind: dc | ac | pulse | zero (ammeter)."""
    def __init__(s, ref, a, b, k, kind, p):
        s.ref, s.a, s.b, s.k, s.kind, s.p = ref, a, b, k, kind, p
        s.override = None

    def matrix(s, A, m):
        k = s.k
        _g(A, s.a, k, 1); _g(A, s.b, k, -1); _g(A, k, s.a, 1); _g(A, k, s.b, -1)

    def value(s, t):
        p = s.p
        if s.override is not None:
            return s.override
        if s.kind == "dc":
            return p["V"]
        if s.kind == "zero":
            return 0.0
        if s.kind == "ac":
            return p["offset"] + p["amp"] * math.sin(2 * math.pi * p["freq"] * t + math.radians(p["phase"]))
        T = 1.0 / p["freq"]
        if t < p["delay"]:
            return p["v1"]
        tt = (t - p["delay"]) % T
        tr = max(p["edge"] * T, 1e-15)
        hi = max(p["duty"] * T - tr, 0.0)
        if tt < tr:
            return p["v1"] + (p["v2"] - p["v1"]) * tt / tr
        if tt < tr + hi:
            return p["v2"]
        if tt < 2 * tr + hi:
            return p["v2"] - (p["v2"] - p["v1"]) * (tt - tr - hi) / tr
        return p["v1"]

    def dc_value(s):
        if s.override is not None:
            return s.override
        if s.kind == "ac":
            return s.p["offset"]
        if s.kind == "pulse":
            return s.p["v1"]
        return s.value(0.0)

    def ac_value(s):
        if s.kind == "ac":
            return s.p["amp"] * complex(math.cos(math.radians(s.p["phase"])), math.sin(math.radians(s.p["phase"])))
        return 0.0

    def rhs(s, b, m):
        if m.mode == "ac":
            b[s.k] = s.ac_value()
        elif m.mode == "dc":
            b[s.k] = s.dc_value()
        else:
            b[s.k] = s.value(m.t)


class PSU(VSrc):
    """Bench supply: V source whose output folds back once the delivered current exceeds Ilim (constant-current region)."""
    nl = True
    RLIM = 1000.0

    def __init__(s, ref, a, b, k, p):
        super().__init__(ref, a, b, k, "dc", {"V": p["V"] if p.get("on", True) else 0.0})
        s.ilim = p["Ilim"]

    def nl(s, x, F, J, limit=True):
        idel = -x[s.k]
        if idel > s.ilim:
            F[s.k] += s.RLIM * (idel - s.ilim)
            J[s.k, s.k] += -s.RLIM
        return False

    def in_cc(s, x):
        return -x[s.k] > s.ilim * 0.999


class ISrc(El):
    def __init__(s, ref, a, b, I):
        s.ref, s.a, s.b, s.I = ref, a, b, I   # I flows out of a (+) into the circuit

    def rhs(s, b, m):
        if m.mode != "ac":
            _add(b, s.a, s.I); _add(b, s.b, -s.I)


class TimedSwitch(El):
    """Push button: conducts (1 mΩ) while its pattern character is '1', else open (1 GΩ). The matrix changes with time."""
    dyn = True

    def __init__(s, ref, a, b, pattern, step):
        s.ref, s.a, s.b = ref, a, b
        s.pattern = "".join(ch for ch in str(pattern) if ch in "01") or "0"
        s.step = max(float(step), 1e-9)

    def state(s, t):
        return s.pattern[min(int(t / s.step + 1e-9), len(s.pattern) - 1)] == "1"

    def matrix(s, A, m):
        _stamp_g(A, s.a, s.b, 1e3 if s.state(m.t) else 1e-9)


class McuPin(El):
    """Arduino output / pull-up: a 5 V (or 0 V) source behind a resistance, as a Norton equivalent. The level is read from the sketch at each step."""

    def __init__(s, ref, node, host, pin, r_out=25.0, pullup=False):
        s.ref, s.a, s.host, s.pin, s.R, s.pullup = ref, node, host, pin, r_out, pullup

    def matrix(s, A, m):
        _g(A, s.a, s.a, 1.0 / s.R)

    def rhs(s, b, m):
        lv = 1 if s.pullup else s.host.r.levels.get(s.pin, 0)
        _add(b, s.a, 5.0 * lv / s.R)


class Diode(El):
    nl = True

    def __init__(s, ref, a, k, Is, n, bv, kind):
        s.ref, s.a, s.k, s.Is, s.n, s.bv, s.kind = ref, a, k, Is, n, bv, kind
        s.nvt = n * VT
        s.vcrit = s.nvt * math.log(s.nvt / (math.sqrt(2) * Is))
        s.vold = 0.0
        s.limited = False

    def reset(s, x=None):
        s.vold = 0.0

    def iv(s, v):
        e = _exp(v / s.nvt)
        i = s.Is * (e - 1.0); g = s.Is * e / s.nvt
        if s.bv:
            e2 = _exp(-(v + s.bv) / s.nvt)
            i -= 1e-3 * e2; g += 1e-3 * e2 / s.nvt
        return i, g + GMIN

    def current(s, x):
        return s.iv(_v(x, s.a) - _v(x, s.k))[0]

    def current_vec(s, va, vk):
        v = va - vk
        i = s.Is * (np.exp(np.minimum(v / s.nvt, 100)) - 1.0)
        if s.bv:
            i -= 1e-3 * np.exp(np.minimum(-(v + s.bv) / s.nvt, 100))
        return i

    def nl(s, x, F, J, limit=True):
        vnew = _v(x, s.a) - _v(x, s.k)
        vl = vnew
        if limit:
            if s.bv and vnew < -s.bv / 2:
                w = _pnjlim(-vnew - s.bv, -s.vold - s.bv, s.nvt, s.vcrit)
                vl = -w - s.bv
            else:
                vl = _pnjlim(vnew, s.vold, s.nvt, s.vcrit)
        i, g = s.iv(vl)
        i0 = i + g * (vnew - vl)
        s.limited = abs(vnew - vl) > 1e-9
        s.vold = vl
        if F is not None:
            _add(F, s.a, i0); _add(F, s.k, -i0)
        _stamp_g(J, s.a, s.k, g)
        return s.limited


class Bjt(El):
    nl = True

    def __init__(s, ref, c, b, e, Is, bf, br, pol=1):
        s.ref, s.c, s.b, s.e, s.Is, s.bf, s.br, s.pol = ref, c, b, e, Is, bf, br, pol
        s.vcrit = VT * math.log(VT / (math.sqrt(2) * Is))
        s.vbe_o = 0.0; s.vbc_o = 0.0; s.limited = False

    def reset(s, x=None):
        s.vbe_o = s.vbc_o = 0.0

    def currents(s, vbe, vbc):
        ef, er = _exp(vbe / VT), _exp(vbc / VT)
        If, Ir = s.Is * (ef - 1), s.Is * (er - 1)
        gf, gr = s.Is * ef / VT, s.Is * er / VT
        ic = If - Ir - Ir / s.br
        ib = If / s.bf + Ir / s.br
        return ic, ib, gf, gr

    def op(s, x):
        vb, vc, ve = _v(x, s.b), _v(x, s.c), _v(x, s.e)
        ic, ib, _, _ = s.currents(s.pol * (vb - ve), s.pol * (vb - vc))
        return {"Ic": s.pol * ic, "Ib": s.pol * ib, "Vbe": vb - ve, "Vce": vc - ve}

    def nl(s, x, F, J, limit=True):
        vb, vc, ve = _v(x, s.b), _v(x, s.c), _v(x, s.e)
        vbe, vbc = s.pol * (vb - ve), s.pol * (vb - vc)
        if limit:
            vbe_l = _pnjlim(vbe, s.vbe_o, VT, s.vcrit)
            vbc_l = _pnjlim(vbc, s.vbc_o, VT, s.vcrit)
        else:
            vbe_l, vbc_l = vbe, vbc
        s.limited = abs(vbe - vbe_l) > 1e-9 or abs(vbc - vbc_l) > 1e-9
        s.vbe_o, s.vbc_o = vbe_l, vbc_l
        ic, ib, gf, gr = s.currents(vbe_l, vbc_l)
        dIc_be, dIc_bc = gf, -gr * (1 + 1 / s.br)
        dIb_be, dIb_bc = gf / s.bf, gr / s.br
        ic += dIc_be * (vbe - vbe_l) + dIc_bc * (vbc - vbc_l)
        ib += dIb_be * (vbe - vbe_l) + dIb_bc * (vbc - vbc_l)
        if F is not None:
            _add(F, s.c, s.pol * ic); _add(F, s.b, s.pol * ib); _add(F, s.e, -s.pol * (ic + ib))
        # d/d(vb, vc, ve) of vbe = (1,0,-1), vbc = (1,-1,0)
        for node, (dbe, dbc) in ((s.b, (1, 1)), (s.c, (0, -1)), (s.e, (-1, 0))):
            dic = dIc_be * dbe + dIc_bc * dbc
            dib = dIb_be * dbe + dIb_bc * dbc
            _g(J, s.c, node, dic); _g(J, s.b, node, dib); _g(J, s.e, node, -(dic + dib))
        return s.limited


class OpAmp(El):
    nl = True

    def __init__(s, ref, p, m_, o, k, A, vsat):
        s.ref, s.p, s.m, s.o, s.k, s.A, s.vs = ref, p, m_, o, k, A, vsat
        s.limited = False

    def matrix(s, A, m):
        _g(A, s.o, s.k, 1)           # branch current leaves the output node into the controlled source

    def nl(s, x, F, J, limit=True):
        u = s.A * (_v(x, s.p) - _v(x, s.m)) / s.vs
        th = math.tanh(u)
        sech2 = 1.0 - th * th
        k = s.k
        if F is not None:
            F[k] += _v(x, s.o) - s.vs * th
        _g(J, k, s.o, 1.0)
        _g(J, k, s.p, -s.A * sech2); _g(J, k, s.m, s.A * sech2)
        return False


def _smin(u, v, e=0.02):
    r = math.sqrt((u - v) ** 2 + e * e)
    return 0.5 * (u + v - r), 0.5 * (1 - (u - v) / r), 0.5 * (1 + (u - v) / r)        # value, d/du, d/dv


def _smax(u, v, e=0.02):
    r = math.sqrt((u - v) ** 2 + e * e)
    return 0.5 * (u + v + r), 0.5 * (1 + (u - v) / r), 0.5 * (1 - (u - v) / r)


class Fet(El):
    """Level-1 (Shichman-Hodges) FET. Enhancement MOSFET (vto > 0) and depletion JFET (vto < 0) share the equations; n-channel only.
    Source and drain are swapped internally when Vds < 0, so the device is symmetric."""
    nl = True

    def __init__(s, ref, d, g, src, vto, beta, lam, pol=1):
        s.ref, s.d, s.g, s.s, s.vto, s.beta, s.lam, s.pol = ref, d, g, src, vto, beta, lam, pol          # pol = -1: p-channel (Vto is the threshold magnitude)
        s.limited = False

    def _ids(s, vgs, vds):
        vov = vgs - s.vto
        if vov <= 0:
            return 0.0, 0.0, 0.0
        cl = 1 + s.lam * vds
        if vds < vov:
            core = vov * vds - 0.5 * vds * vds
            return s.beta * core * cl, s.beta * vds * cl, s.beta * (vov - vds) * cl + s.beta * core * s.lam
        core = 0.5 * vov * vov
        return s.beta * core * cl, s.beta * vov * cl, s.beta * core * s.lam

    def op(s, x):
        vd, vg, vs = _v(x, s.d), _v(x, s.g), _v(x, s.s)
        p = s.pol
        if p * (vd - vs) >= 0:
            i, _, _ = s._ids(p * (vg - vs), p * (vd - vs))
            i *= p
        else:
            i, _, _ = s._ids(p * (vg - vd), p * (vs - vd))
            i = -i * p
        return {"Id": i, "Vgs": vg - vs, "Vds": vd - vs}

    def nl(s, x, F, J, limit=True):
        d, g, src = s.d, s.g, s.s
        vd, vg, vs = _v(x, d), _v(x, g), _v(x, src)
        p = s.pol
        if p * (vd - vs) < 0:                            # reverse operation: swap drain and source
            d, src = src, d
            vd, vs = vs, vd
        i, gm, gds = s._ids(p * (vg - vs), p * (vd - vs))
        i *= p
        if F is not None:
            _add(F, d, i); _add(F, src, -i)
        for node, dvgs, dvds in ((g, 1, 0), (src, -1, -1), (d, 0, 1)):
            di = gm * dvgs + gds * dvds
            _g(J, d, node, di); _g(J, src, node, -di)
        return False


class OpAmpR(OpAmp):
    """Op-amp whose output swings between its own supply rails: hi = V(V+) - dh, lo = V(V-) + dl (rails not wired: +/- vsat)."""

    def __init__(s, ref, p, m_, o, k, A, vp, vn, dh, dl, vsat=13.0):
        super().__init__(ref, p, m_, o, k, A, vsat)
        s.vp, s.vn, s.dh, s.dl = vp, vn, dh, dl
        s.scale = 1.0                                   # < 1 only inside the gain-continuation fallback of Circuit.newton

    def nl(s, x, F, J, limit=True):
        hi = (_v(x, s.vp) - s.dh) if s.vp is not None else s.vs
        lo = (_v(x, s.vn) + s.dl) if s.vn is not None else -s.vs
        k = s.k
        vin = _v(x, s.p) - _v(x, s.m)
        if hi - lo < 0.2:                                # unpowered: output sits at the low rail
            if F is not None:
                F[k] += _v(x, s.o) - lo
            _g(J, k, s.o, 1.0)
            return False
        half = 0.5 * (hi - lo)
        gain = s.A * s.scale
        u = gain * vin / half
        th = math.tanh(u)
        sech2 = 1.0 - th * th
        sh = 0.5 * (1 + th)
        if F is not None:
            F[k] += _v(x, s.o) - (lo + (hi - lo) * sh)
        _g(J, k, s.o, 1.0)
        _g(J, k, s.p, -gain * sech2); _g(J, k, s.m, gain * sech2)
        if s.vp is not None:
            _g(J, k, s.vp, -(sh - 0.5 * u * sech2))
        if s.vn is not None:
            _g(J, k, s.vn, -((1 - sh) + 0.5 * u * sech2))
        return False


class Reg(El):
    """Linear regulator: Vout = clamp(min(Vin - dropout, Vref_target), floor) with a small output resistance.
    sign = +1 for 78xx / LM317, -1 for 79xx. `bnode`/`boff`: regulation target = V(bnode) + sign*boff (fixed: the GND pin; LM317: ADJ pin, +1.25 V)."""
    nl = True

    def __init__(s, ref, i, o, bnode, boff, floor, k, sign=1, dropout=2.0, rout=0.05):
        s.ref, s.i, s.o, s.bn, s.boff, s.fl, s.k, s.sign, s.dro, s.rout = ref, i, o, bnode, boff, floor, k, sign, dropout, rout

    def matrix(s, A, m):
        _g(A, s.o, s.k, 1); _g(A, s.i, s.k, -1)

    def target(s, x):
        sg = s.sign
        u = sg * _v(x, s.i) - s.dro
        vb = sg * (_v(x, s.bn) + sg * s.boff)
        mn, dmu, dmv = _smin(u, vb)
        fl = sg * _v(x, s.fl)
        w, dwu, dwv = _smax(mn, fl)
        return sg * w, dwu * dmu, dwu * dmv, dwv

    def nl(s, x, F, J, limit=True):
        T, d_in, d_b, d_fl = s.target(x)
        k = s.k
        if F is not None:
            F[k] += _v(x, s.o) - T - s.rout * x[k]
        _g(J, k, s.o, 1.0); J[k, k] += -s.rout
        _g(J, k, s.i, -d_in); _g(J, k, s.bn, -d_b); _g(J, k, s.fl, -d_fl)
        return False


class LogicIC(El):
    """Behavioural digital IC (see core/icmodels.py). Inputs are high-impedance, thresholds follow the logic family; outputs are Norton
    sources whose level comes from the truth-table / state model. The solver re-evaluates `evaluate()` after each solve until the outputs settle."""
    dyn = True

    def __init__(s, ref, spec, nodes, floating):
        s.ref, s.spec, s.nodes, s.floating = ref, spec, nodes, floating
        s.model = spec.model()
        s.fam = spec.fam
        s.reset()

    def reset(s, x=None):
        s.st = s.model.init()
        s.prev = None
        s.cur = {o: 0 for o in s.model.outs}
        s.powered = False
        s.vcc = 5.0
        s.new_st, s.new_in = s.st, None

    def state(s, t):
        return (s.powered,) + tuple(s.cur[o] for o in s.model.outs)

    def levels(s, x):
        vg = _v(x, s.nodes["GND"])
        vcc = _v(x, s.nodes["VCC"]) - vg
        lo, hi = s.fam.vil(vcc), s.fam.vih(vcc)
        ins = {}
        for p in s.model.ins:
            if p in s.floating:
                ins[p] = 1 if s.fam.ttl else 0
                continue
            v = _v(x, s.nodes[p]) - vg
            ins[p] = 1 if v >= hi else 0 if v <= lo else (s.prev or {}).get(p, 0)
        return vcc, ins

    def evaluate(s, x, m=None):
        vcc, ins = s.levels(x)
        pw = vcc >= s.fam.vmin
        if pw:
            s.vcc = vcc
            outs, s.new_st = s.model.fn(ins, s.prev if s.prev is not None else ins, s.st)
        else:
            outs, s.new_st = {o: None for o in s.model.outs}, s.st
        s.new_in = ins
        changed = outs != s.cur or pw != s.powered
        s.cur, s.powered = outs, pw
        return changed

    def accept(s, x, m):
        s.evaluate(x, m)
        s.st, s.prev = s.new_st, s.new_in

    def drive(s, o):
        lv = s.cur[o]
        if lv is None:
            return None
        if o in s.model.oc:
            return (1.0 / s.fam.rlo, s.fam.vol) if lv == 0 else None
        return (1.0 / s.fam.rhi, s.fam.voh(s.vcc)) if lv == 1 else (1.0 / s.fam.rlo, s.fam.vol)

    def matrix(s, A, m):
        for o in s.model.outs:
            d = s.drive(o)
            if d:
                _g(A, s.nodes[o], s.nodes[o], d[0])

    def rhs(s, b, m):
        if m.mode == "ac":
            return
        for o in s.model.outs:
            d = s.drive(o)
            if d:
                _add(b, s.nodes[o], d[0] * d[1])


class Timer555(El):
    """NE555: internal 3 x 5 kΩ divider (real resistors, so the CTRL pin works), two comparators, an SR latch (RESET dominates),
    push-pull output (Vcc - 1.7 V / 0.1 V) and an open-collector discharge transistor on while the output is low."""
    dyn = True

    def __init__(s, ref, nodes, mid, drop=1.7, reset_open=False):
        s.ref, s.nodes, s.mid, s.drop, s.reset_open = ref, nodes, mid, drop, reset_open
        s.reset()

    def reset(s, x=None):
        s.q = 0; s.qc = 0; s.powered = False; s.vcc = 5.0

    def state(s, t):
        return (s.powered, s.q)

    def evaluate(s, x, m=None):
        n = s.nodes
        vg = _v(x, n["GND"])
        vcc = _v(x, n["VCC"]) - vg
        pw = vcc >= 4.5
        q = s.qc
        if pw:
            s.vcc = vcc
            vctrl, vmid = _v(x, n["CTRL"]) - vg, _v(x, s.mid) - vg
            if (not s.reset_open and _v(x, n["RESET"]) - vg < 0.7) or _v(x, n["THR"]) - vg > vctrl:
                q = 0
            elif _v(x, n["TRIG"]) - vg < vmid:
                q = 1
        else:
            q = 0
        changed = q != s.q or pw != s.powered
        s.q, s.powered = q, pw
        return changed

    def accept(s, x, m):
        s.evaluate(x, m)
        s.qc = s.q

    def matrix(s, A, m):
        if not s.powered:
            return
        _g(A, s.nodes["OUT"], s.nodes["OUT"], 1 / 25.0 if s.q else 1 / 10.0)
        if not s.q:
            _stamp_g(A, s.nodes["DIS"], s.nodes["GND"], 1 / 15.0)

    def rhs(s, b, m):
        if s.powered and m.mode != "ac":
            _add(b, s.nodes["OUT"], (max(s.vcc - s.drop, 0.0) / 25.0) if s.q else 0.1 / 10.0)


class Comparator(El):
    """LM311-style comparator: the open-collector output transistor (to the GND pin) is on while IN+ < IN-."""
    dyn = True

    def __init__(s, ref, ip, im, out, gnd, vpos, vneg):
        s.ref, s.ip, s.im, s.out, s.gnd, s.vpos, s.vneg = ref, ip, im, out, gnd, vpos, vneg
        s.on = False

    def reset(s, x=None):
        s.on = False

    def state(s, t):
        return (s.on,)

    def evaluate(s, x, m=None):
        pw = _v(x, s.vpos) - _v(x, s.vneg) >= 3.5
        on = pw and (_v(x, s.ip) - _v(x, s.im)) < 0
        ch = on != s.on
        s.on = on
        return ch

    def accept(s, x, m):
        s.evaluate(x, m)

    def matrix(s, A, m):
        if s.on:
            _stamp_g(A, s.out, s.gnd, 1 / 20.0)


class Thyristor(El):
    """SCR (one-way) or TRIAC (two-way) with a gate-trigger current, holding current and on-state drop. The latch state is
    evaluated after each solve (gate currents come from the gate diodes in the netlist)."""
    dyn = True

    def __init__(s, ref, a, k, gate_diodes, igt, ih, von, ron, triac):
        s.ref, s.a, s.k, s.gd, s.igt, s.ih, s.von, s.ron, s.triac = ref, a, k, gate_diodes, igt, ih, von, ron, triac
        s.reset()

    def reset(s, x=None):
        s.on = 0                      # 0 off, +1 conducting a -> k, -1 conducting k -> a (TRIAC)
        s.oc = 0

    def state(s, t):
        return (s.on,)

    def evaluate(s, x, m=None):
        v = _v(x, s.a) - _v(x, s.k)
        on = s.oc
        if on:
            i = (abs(v) - s.von) / s.ron
            if i < s.ih or (v * on < 0):
                on = 0
        else:
            ig = max(abs(d.current(x)) for d in s.gd)
            if ig >= s.igt and (v > 0.5 or (s.triac and v < -0.5)):
                on = 1 if v > 0 else -1
        ch = on != s.on
        s.on = on
        return ch

    def accept(s, x, m):
        s.evaluate(x, m)
        s.oc = s.on

    def matrix(s, A, m):
        if s.on:
            _stamp_g(A, s.a, s.k, 1.0 / s.ron)

    def rhs(s, b, m):
        if s.on and m.mode != "ac":
            i0 = s.on * s.von / s.ron
            _add(b, s.a, i0); _add(b, s.k, -i0)


class Circuit:
    """Compiled analog netlist."""

    def __init__(self, project, mcu=None):
        self.project = project
        self.mcu = mcu or {}
        self.nets = project.nets()
        self.net_of = {}
        self.pin_deg = {}
        idx = 0
        self.node_names = []
        self.node_net = []
        for net in self.nets:
            if net.is_ground:
                i = -1
            else:
                i = idx; idx += 1
                self.node_names.append(net.name)
                self.node_net.append(net)
            for k in net.pins:
                self.net_of[k] = i
                self.pin_deg[k] = len(net.pins)
        self.n = idx
        self.nb = 0
        self.els: list[El] = []
        self.by_ref: dict[str, El] = {}
        self.meters = []      # (component, kind, nodes)
        self.comp_el = {}
        self.warnings = []
        self._build()
        self.N = self.n + self.nb
        self.nlels = [e for e in self.els if e.nl]
        self.beh = [e for e in self.els if hasattr(e, "evaluate")]

    def node(self, c, pin):
        return self.net_of[(c.id, pin)]

    def _new_node(self, name):
        i = self.n
        self.n += 1
        self.node_names.append(name)
        self.node_net.append(None)
        return i

    def _build(self):
        for c in self.project.components.values():
            d = c.defn
            if d.engine != "analog":
                continue
            if c.type == "arduino":
                self._build_arduino(c)
                continue
            if d.spec is not None:
                self._build_spec(c)
                continue
            t, p = c.type, c.params
            node = lambda pin: self.node(c, pin)
            e = None
            if t == "resistor":
                e = Res(c.ref, node("1"), node("2"), p["R"])
            elif t in ("capacitor", "capacitor_ceramic"):
                e = Cap(c.ref, node("+"), node("−"), p["C"], p["v0"])
            elif t == "motor":
                e = Res(c.ref, node("+"), node("−"), max(p["R"], 1e-3))
            elif t == "speaker":
                e = Res(c.ref, node("+"), node("−"), max(p["Z"], 0.1))
                self.meters.append((c, "buzzer", (node("+"), node("−"))))
            elif t == "buzzer":
                e = Res(c.ref, node("+"), node("−"), 150.0)
                self.meters.append((c, "buzzer", (node("+"), node("−"))))
            elif t == "pushbutton":
                e = TimedSwitch(c.ref, node("1"), node("3"), p["pattern"], p["step"])
            elif t == "inductor":
                e = Ind(c.ref, node("1"), node("2"), p["L"], p["i0"], None)
            elif t == "switch":
                e = Res(c.ref, node("1"), node("2"), 1e-3 if p["closed"] else 1e9)
            elif t == "vdc":
                a = node("+")
                if p["Rs"] > 0:
                    mid = self._new_node(f"{c.ref}.int")
                    self.els.append(Res(c.ref + ".Rs", mid, a, p["Rs"]))
                    a = mid
                e = VSrc(c.ref, a, node("−"), None, "dc", p)
            elif t == "psu":
                e = PSU(c.ref, node("+"), node("−"), None, p)
            elif t == "dmm":
                mode = p["mode"]
                if mode in ("DC volts", "AC volts"):
                    e = Res(c.ref, node("V"), node("COM"), VMETER_R)
                    self.meters.append((c, "dmm_v", (node("V"), node("COM"))))
                elif mode == "Resistance":
                    e = ISrc(c.ref, node("V"), node("COM"), 1e-3)
                    self.meters.append((c, "dmm_ohm", (node("V"), node("COM"))))
                else:
                    e = VSrc(c.ref, node("V"), node("COM"), None, "zero", p)
                    self.meters.append((c, "dmm_a", e))
            elif t == "vac":
                e = VSrc(c.ref, node("+"), node("−"), None, "ac", p)
            elif t == "vpulse":
                if p["freq"] <= 0:
                    raise SimError(f"{c.ref}: frequency must be > 0")
                e = VSrc(c.ref, node("+"), node("−"), None, "pulse", p)
            elif t == "pot":
                pos = min(max(p["pos"], 0.0), 1.0)
                self.els.append(Res(c.ref + ".a", node("1"), node("W"), max(p["R"] * pos, 1e-3)))
                e = Res(c.ref, node("W"), node("2"), max(p["R"] * (1 - pos), 1e-3))
            elif t == "ammeter":
                e = VSrc(c.ref, node("+"), node("−"), None, "zero", p)
            elif t == "idc":
                e = ISrc(c.ref, node("+"), node("−"), p["I"])
            elif t in ("diode", "led", "zener"):
                a, k = node("A"), node("K")
                if p["Rs"] > 0:
                    mid = self._new_node(f"{c.ref}.int")
                    self.els.append(Res(c.ref + ".Rs", a, mid, p["Rs"]))
                    a = mid
                e = Diode(c.ref, a, k, p["Is"], p["n"], p.get("Vz") if t == "zener" else 0.0, t)
            elif t == "npn":
                e = Bjt(c.ref, node("C"), node("B"), node("E"), p["Is"], p["bf"], p["br"])
            elif t == "opamp":
                e = OpAmp(c.ref, node("+"), node("−"), node("OUT"), None, p["A"], p["vsat"])
            elif t == "voltmeter":
                e = Res(c.ref, node("+"), node("−"), VMETER_R)
                self.meters.append((c, "voltmeter", (node("+"), node("−"))))
            elif t == "scope":
                g = node("GND")
                self.els.append(Res(c.ref + ".1", node("CH1"), g, VMETER_R))
                self.els.append(Res(c.ref + ".2", node("CH2"), g, VMETER_R))
                self.meters.append((c, "scope", (node("CH1"), node("CH2"), g)))
            elif t == "ground":
                continue
            else:
                raise SimError(f"{c.ref}: part type {t!r} has no analog model")
            if e is not None:
                e.cid = c.id
                self.els.append(e)
                self.by_ref[c.ref] = e
                self.comp_el[c.id] = e
        k = self.n
        for e in self.els:
            if isinstance(e, (Ind, VSrc, OpAmp, Reg)):
                e.k = k
                k += 1
        self.nb = k - self.n

    def _reg_el(self, c, e):
        e.cid = c.id
        self.els.append(e)
        self.by_ref.setdefault(e.ref, e)
        return e

    def _build_spec(self, c):
        """Catalogue parts (ecelab/catalogue.py): discrete semiconductors and behavioural ICs."""
        d, p, sp = c.defn, c.params, c.defn.spec
        node = lambda pin: self.node(c, pin)                      # noqa: E731
        deg = lambda pin: self.pin_deg.get((c.id, pin), 1)         # noqa: E731
        k = sp.kind
        if k == "diode":
            a, kk = node("A"), node("K")
            if p["Rs"] > 0:
                mid = self._new_node(f"{c.ref}.int")
                self.els.append(Res(c.ref + ".Rs", a, mid, p["Rs"]))
                a = mid
            zen = sp.base == "zener"
            self.comp_el[c.id] = self._reg_el(c, Diode(c.ref, a, kk, p["Is"], p["n"], p["Vz"] if zen else 0.0, "zener" if zen else "diode"))
        elif k == "bjt":
            e = Bjt(c.ref, node("C"), node("B"), node("E"), p["Is"], p["bf"], p["br"], sp.pol)
            e.kind = "npn" if sp.pol > 0 else "pnp"
            self.comp_el[c.id] = self._reg_el(c, e)
        elif k == "fet":
            dn, gn, sn = node("D"), node("G"), node("S")
            pol = getattr(sp, "pol", 1)
            self.comp_el[c.id] = self._reg_el(c, Fet(c.ref, dn, gn, sn, p["Vto"], p["beta"], p["lam"], pol))
            if sp.body:
                self.els.append(Diode(c.ref + ".body", sn, dn, 1e-13, 1.0, 0.0, "diode") if pol > 0 else Diode(c.ref + ".body", dn, sn, 1e-13, 1.0, 0.0, "diode"))
        elif k == "ldr":
            lux = max(float(p["lux"]), 1e-3)
            r = min(max(p["R10"] * (10.0 / lux) ** p["gamma"], 50.0), p["Rdark"])
            self.comp_el[c.id] = self._reg_el(c, Res(c.ref, node("A"), node("B"), r))
        elif k == "photodiode":
            a, kk = node("A"), node("K")
            self.comp_el[c.id] = self._reg_el(c, Diode(c.ref, a, kk, p["Is"], 1.0, 0.0, "diode"))
            self.els.append(ISrc(c.ref + ".ph", a, kk, p["E"] * p["S"]))
        elif k in ("scr", "triac"):
            if k == "scr":
                a, kk, g = node("A"), node("K"), node("G")
                gds = [Diode(c.ref + ".g", g, kk, 1e-14, 1.0, 0.0, "diode")]
            else:
                a, kk, g = node("MT2"), node("MT1"), node("G")
                gds = [Diode(c.ref + ".g1", g, kk, 1e-14, 1.0, 0.0, "diode"), Diode(c.ref + ".g2", kk, g, 1e-14, 1.0, 0.0, "diode")]
            self.els.extend(gds)
            self.comp_el[c.id] = self._reg_el(c, Thyristor(c.ref, a, kk, gds, p["Igt"], p["Ih"], p["Von"], p["Ron"], sp.triac))
        elif k == "opamps":
            def rail(pin):
                n_ = node(pin)
                return n_ if (n_ == -1 or deg(pin) > 1) else None
            vp, vn = rail(sp.vp), rail(sp.vn)
            for i, (ip, im, out) in enumerate(sp.units, start=1):
                e = OpAmpR(f"{c.ref}.{i}", node(ip), node(im), node(out), None, p["A"], vp, vn, p["dh"], p["dl"])
                self._reg_el(c, e)
            self.comp_el[c.id] = self.els[-1]
        elif k == "comparator":
            e = Comparator(c.ref, node("INP"), node("INN"), node("OUT"), node("GND"), node("VCC"), node("VEE"))
            self.comp_el[c.id] = self._reg_el(c, e)
        elif k == "timer555":
            nodes = {pn.name: node(pn.name) for pn in d.pins}
            mid = self._new_node(f"{c.ref}.mid")
            for nm, a, b in ((".r1", nodes["VCC"], nodes["CTRL"]), (".r2", nodes["CTRL"], mid), (".r3", mid, nodes["GND"])):
                self.els.append(Res(c.ref + nm, a, b, 5000.0))
            e = Timer555(c.ref, nodes, mid, p["drop"], reset_open=deg("RESET") == 1)
            self.comp_el[c.id] = self._reg_el(c, e)
        elif k == "reg":
            vin, vout = node("IN"), node("OUT")
            if sp.fixed:
                gnd = node("GND")
                e = Reg(c.ref, vin, vout, gnd, p["Vout"], gnd, None, sp.sign, p["dropout"], p["rout"])
            else:
                e = Reg(c.ref, vin, vout, node("ADJ"), p["Vref"], -1, None, sp.sign, p["dropout"], p["rout"])
            self.comp_el[c.id] = self._reg_el(c, e)
        elif k == "logic":
            nodes = {pn.name: node(pn.name) for pn in d.pins}
            floating = {pn.name for pn in d.pins if deg(pn.name) == 1}
            self.comp_el[c.id] = self._reg_el(c, LogicIC(c.ref, sp, nodes, floating))
        else:
            raise SimError(f"{c.ref}: catalogue model {k!r} is not implemented")

    def _build_arduino(self, c):
        """UNO: GND pins are ground (handled in Project.nets), 5V/3V3 are ideal rails, D2–D13 follow the running sketch, A0–A5 are high-impedance inputs."""
        host = self.mcu.get(c.id)
        for rail, volts in (("5V", 5.0), ("3V3", 3.3)):
            nd = self.node(c, rail)
            if nd >= 0:
                e = VSrc(f"{c.ref}.{rail}", nd, -1, None, "dc", {"V": volts})
                self.els.append(e)
        if host is None:
            return
        for pin in range(2, 14):
            mode = host.r.modes.get(pin)
            nd = self.node(c, f"D{pin}")
            if mode == 1:
                self.els.append(McuPin(f"{c.ref}.D{pin}", nd, host, pin))
            elif mode == 2 or (mode == 0 and pin in host.r.pullup):
                self.els.append(McuPin(f"{c.ref}.D{pin}", nd, host, pin, 20e3, pullup=True))

    # ---------------------------------------------------------------- assembly
    def matrix(self, m, dtype=float):
        N = self.N
        A = np.zeros((N, N), dtype=complex if m.mode == "ac" else float)
        for e in self.els:
            e.matrix(A, m)
        for i in range(self.n):
            A[i, i] += GMIN
        return A

    def rhs(self, m):
        b = np.zeros(self.N, dtype=complex if m.mode == "ac" else float)
        for e in self.els:
            e.rhs(b, m)
        return b

    def reset_states(self, x=None):
        for e in self.els:
            e.reset(x)

    # ---------------------------------------------------------------- solving
    @staticmethod
    def _solve(A, b, what=""):
        if A.dtype == np.float64 and native.available():
            x, st, res = native.solve(A, b)
            if st == 1:
                raise SimError(f"Singular circuit matrix {what}. Look for voltage sources in parallel/loops with no "
                               "resistance, or an unconnected supply.")
            if st == 2:
                raise SimError(f"Circuit matrix is singular {what}. Check for voltage-source loops or conflicting "
                               "sources.")
            if len(b) and res > 1e-6 * (1 + np.max(np.abs(b))) + 1e-9 * np.max(np.abs(x)) * np.max(np.abs(A)):
                raise SimError(f"Circuit matrix is singular or badly conditioned {what} (residual {res:.2e}). "
                               "Check for voltage-source loops or floating subcircuits.")
            return x
        try:
            lu = lu_factor(A, check_finite=True)
            x = lu_solve(lu, b)
        except (np.linalg.LinAlgError, ValueError) as ex:
            raise SimError(f"Singular circuit matrix {what}: {ex}. Look for voltage sources in parallel/loops with no "
                           "resistance, or an unconnected supply.") from ex
        if not np.all(np.isfinite(x)):
            raise SimError(f"Circuit matrix is singular {what}. Check for voltage-source loops or conflicting "
                           "sources.")
        res = np.max(np.abs(A @ x - b)) if len(b) else 0.0
        if res > 1e-6 * (1 + np.max(np.abs(b))) + 1e-9 * np.max(np.abs(x)) * np.max(np.abs(A)):
            raise SimError(f"Circuit matrix is singular or badly conditioned {what} (residual {res:.2e}). "
                           "Check for voltage-source loops or floating subcircuits.")
        return x

    def newton(self, m, x0, A=None, b=None, maxit=150):
        if A is None:
            A = self.matrix(m)
        if b is None:
            b = self.rhs(m)
        if not self.nlels:
            return self._solve(A, b, f"at t={m.t:g}")
        last_err = None
        for gshunt in (0.0, 1e-3, 1e-6, 1e-9):       # gmin stepping fallback
            Ag = A.copy()
            if gshunt:
                for i in range(self.n):
                    Ag[i, i] += gshunt
            x = x0.copy()
            ok = False
            for it in range(maxit):
                F = Ag @ x - b
                J = Ag.copy()
                lim = False
                for e in self.nlels:
                    lim |= bool(e.nl(x, F, J))
                try:
                    dx, st, _ = native.solve(J, -F)
                    if st == 1:
                        raise np.linalg.LinAlgError("singular matrix")
                except np.linalg.LinAlgError as ex:
                    raise SimError(f"Singular Jacobian at t={m.t:g}: {ex}. Check biasing of nonlinear devices.") from ex
                if not np.all(np.isfinite(dx)):
                    last_err = "non-finite Newton step"
                    break
                # damping of node-voltage steps
                big = np.max(np.abs(dx[: self.n])) if self.n else 0
                if big > 50:
                    dx *= 50 / big
                x = x + dx
                if not lim and np.all(np.abs(dx) <= 1e-9 + 1e-6 * np.abs(x)):
                    ok = True
                    break
            if ok:
                if gshunt:
                    ok2 = self._refine(m, x, A, b)
                    if ok2 is not None:
                        return ok2
                else:
                    return x
            last_err = last_err or "iteration limit"
        ops = [e for e in self.nlels if hasattr(e, "scale")]
        if ops:                                      # high-gain op-amps: walk the gain up from a well-conditioned circuit
            x = x0.copy()
            try:
                for sc in [1e-6 * 2.0 ** i for i in range(21)] + [1.0]:     # ×2 per step keeps each solution inside the next linear region
                    for e in ops:
                        e.scale = sc
                    x = self._refine(m, x, A, b, maxit=200)
                    if x is None:
                        break
            finally:
                for e in ops:
                    e.scale = 1.0
            if x is not None:
                return x
        names = ", ".join(e.ref for e in self.nlels)
        raise SimError(f"Newton iteration did not converge at t={m.t:g} s ({last_err}). "
                       f"Nonlinear devices: {names}. Check for a forward-biased junction without current limiting.")

    def _refine(self, m, x, A, b, maxit=60):
        """Continue plain Newton from a gmin-stepped solution."""
        for _ in range(maxit):
            F = A @ x - b
            J = A.copy()
            lim = False
            for e in self.nlels:
                lim |= bool(e.nl(x, F, J))
            try:
                dx = np.linalg.solve(J, -F)
            except np.linalg.LinAlgError:
                return None
            x = x + dx
            if not lim and np.all(np.abs(dx) <= 1e-9 + 1e-6 * np.abs(x)):
                return x
        return None

    def jacobian_at(self, x):
        J = np.zeros((self.N, self.N))
        for e in self.nlels:
            e.nl(x, None, J, limit=False)
        return J

    # ---------------------------------------------------------------- diagnostics
    def dc_floating_nodes(self):
        parent = list(range(self.n + 1))        # last index = ground

        def f(i):
            i = self.n if i < 0 else i
            while parent[i] != i:
                parent[i] = parent[parent[i]]
                i = parent[i]
            return i

        def u(a, b):
            parent[f(a)] = f(b)
        for e in self.els:
            if isinstance(e, (Res, Ind)):
                u(e.a, e.b)
            elif isinstance(e, VSrc):
                u(e.a, e.b)
            elif isinstance(e, Diode):
                u(e.a, e.k)
            elif isinstance(e, Bjt):
                u(e.c, e.b); u(e.b, e.e)
            elif isinstance(e, (OpAmp, Reg)):
                u(e.o, -1)
            elif isinstance(e, Fet):
                u(e.d, e.s)
            elif isinstance(e, LogicIC):
                for o in e.model.outs:
                    u(e.nodes[o], -1)
            elif isinstance(e, Timer555):
                u(e.nodes["OUT"], -1); u(e.nodes["DIS"], e.nodes["GND"])
            elif isinstance(e, Comparator):
                u(e.out, e.gnd)
            elif isinstance(e, Thyristor):
                u(e.a, e.k)
        g = f(-1)
        used = set()                                           # nodes that actually touch a circuit element (unused breadboard strips don't count)
        for e in self.els:
            for attr in ("a", "b", "k", "c", "e", "p", "m", "o", "d", "s", "i"):
                v = getattr(e, attr, None)
                if isinstance(v, int) and v >= 0:
                    used.add(v)
        return [self.node_names[i] for i in range(self.n) if f(i) != g and i in used]


def _dmm_reading(comp, kind, nodes, x, X):
    """DMM display value from the active model: mode decides what is measured. X (full history) is given for transient runs."""
    from .base import SimError
    mode = comp.params["mode"]
    if kind == "dmm_v":
        a, b = nodes
        if X is None:
            v = _v(x, a) - _v(x, b)
            return {"type": "dmm", "mode": mode, "value": float(v) if mode == "DC volts" else 0.0, "unit": "V", "text_ok": mode == "DC volts"}
        va = X[:, a] if a >= 0 else 0 * X[:, 0]
        vb = X[:, b] if b >= 0 else 0 * X[:, 0]
        v = va - vb
        val = float(np.mean(v)) if mode == "DC volts" else float(np.sqrt(np.mean((v - 0) ** 2)))
        return {"type": "dmm", "mode": mode, "value": val, "unit": "V", "text_ok": True}
    if kind == "dmm_ohm":
        v = _v(x, nodes[0]) - _v(x, nodes[1])
        r = v / 1e-3
        return {"type": "dmm", "mode": mode, "value": float(r), "unit": "Ω", "text_ok": True, "overload": bool(v > 3.9)}
    e = nodes
    cur = float(x[e.k])
    return {"type": "dmm", "mode": mode, "value": cur, "unit": "A", "text_ok": True}


def element_table(circ: Circuit, x):
    rows = []
    for e in circ.els:
        if isinstance(e, Res) and "." not in e.ref:
            v = _v(x, e.a) - _v(x, e.b)
            i = e.current(x)
            rows.append({"ref": e.ref, "type": "R", "V": v, "I": i, "P": v * i})
        elif isinstance(e, PSU):
            rows.append({"ref": e.ref, "type": "psu", "V": _v(x, e.a) - _v(x, e.b), "I": x[e.k], "P": (_v(x, e.a) - _v(x, e.b)) * x[e.k],
                         "mode": "CC" if e.in_cc(x) else "CV"})
        elif isinstance(e, VSrc):
            rows.append({"ref": e.ref, "type": "ammeter" if e.kind == "zero" else "source",
                         "V": _v(x, e.a) - _v(x, e.b), "I": x[e.k], "P": (_v(x, e.a) - _v(x, e.b)) * x[e.k]})
        elif isinstance(e, Diode):
            v = _v(x, e.a) - _v(x, e.k)
            i = e.current(x)
            rows.append({"ref": e.ref, "type": e.kind, "V": v, "I": i, "P": v * i})
        elif isinstance(e, Bjt):
            o = e.op(x)
            rows.append({"ref": e.ref, "type": getattr(e, "kind", "npn"), "V": o["Vce"], "I": o["Ic"], "P": o["Vce"] * o["Ic"],
                         "Ib": o["Ib"], "Vbe": o["Vbe"]})
        elif isinstance(e, Fet):
            o = e.op(x)
            rows.append({"ref": e.ref, "type": "fet", "V": o["Vds"], "I": o["Id"], "P": o["Vds"] * o["Id"], "Vgs": o["Vgs"]})
        elif isinstance(e, Cap):
            rows.append({"ref": e.ref, "type": "C", "V": _v(x, e.a) - _v(x, e.b), "I": e.ip, "P": 0.0})
        elif isinstance(e, Ind):
            rows.append({"ref": e.ref, "type": "L", "V": _v(x, e.a) - _v(x, e.b), "I": x[e.k], "P": 0.0})
    return rows


class AnalogEngine(Engine):
    name = "analog"
    streaming = True

    def validate(self, project):
        diags = []
        comps = [c for c in project.components.values() if c.defn.engine == "analog"]
        if not comps:
            return [Diagnostic("error", "analog", "No analog components on the canvas")]
        if any(c.defn.engine == "digital" for c in project.components.values()):
            diags.append(Diagnostic("error", "analog", "Project mixes analog and digital parts; "
                                    "mixed-signal simulation is not supported"))
        if not any(c.type in ("ground", "arduino") for c in comps):
            diags.append(Diagnostic("error", "analog", "Circuit has no ground reference — add a Ground part and wire it"))
        pin_nets = project.net_of()
        for c in comps:
            for pin in c.defn.pins:
                net = pin_nets[(c.id, pin.name)]
                if len(net.pins) == 1 and c.type not in ("ground", "scope") and pin.name not in c.defn.optional and not c.defn.all_optional:
                    diags.append(Diagnostic("warning", f"{c.ref}.{pin.name}", "Pin is not connected", c.id))
            pr = c.params
            for k in ("R", "C", "L"):
                if k in pr and pr[k] <= 0:
                    diags.append(Diagnostic("error", c.ref, f"{k} must be > 0 (got {pr[k]})", c.id))
            if c.type in ("vdc", "vac", "vpulse", "ammeter", "idc"):
                pa, pb = [pin.name for pin in c.defn.pins]
                if pin_nets[(c.id, pa)] is pin_nets[(c.id, pb)] and c.type != "idc":
                    diags.append(Diagnostic("error", c.ref, "Source terminals are shorted together (short circuit)", c.id))
            for sp_pin in c.defn.supply:
                if len(pin_nets[(c.id, sp_pin)].pins) == 1:
                    diags.append(Diagnostic("error", f"{c.ref}.{sp_pin}", f"{c.defn.name}: power pin {sp_pin} is not connected", c.id))
            if c.type == "scope" and len(pin_nets[(c.id, "GND")].pins) == 1:
                diags.append(Diagnostic("warning", c.ref, "Scope GND is not connected; readings are meaningless", c.id))
        for c in comps:
            if c.type == "arduino":
                try:
                    McuRunner(c.params["code"], ref=c.ref)
                except McuError as ex:
                    diags.append(Diagnostic("error", c.ref, f"Sketch does not compile: {ex}", c.id))
        try:
            circ = Circuit(project)
            fl = circ.dc_floating_nodes()
            if fl:
                diags.append(Diagnostic("warning", "analog", f"No DC path to ground for node(s): {', '.join(fl)} "
                                        "(they are held near 0 V by a 1 pS leakage; results are not meaningful)"))
        except (SimError, KeyError) as ex:
            diags.append(Diagnostic("error", "analog", str(ex)))
        return diags

    def prepare(self, project, settings):
        super().prepare(project, settings)
        self.hosts = {}
        for c in project.components.values():
            if c.type == "arduino":
                try:
                    rn = McuRunner(c.params["code"], [0] * 6, int(settings.get("seed", 1)), c.ref)
                    h = McuHost(rn)
                    h.advance(0.0, lambda pin: None)                    # setup() and the first part of loop() at t = 0
                except McuError as ex:
                    raise SimError(str(ex)) from ex
                self.hosts[c.id] = h
        self.circ = Circuit(project, self.hosts)
        self.result.diagnostics = [d for d in self.validate(project) if d.severity != "error"]

    # ------------------------------------------------------------------ microcontroller co-simulation
    def _mcu_step(self, t, x):
        """Advance every sketch to time t, feeding it the present pin voltages."""
        c = self.circ
        for cid, h in self.hosts.items():
            comp = c.project.components[cid]

            def volt(name):
                i = c.net_of[(cid, name)]
                return 0.0 if i < 0 else float(x[i])

            def read(pin):
                return 1 if volt(f"D{pin}") > 2.5 else 0

            def adc(arr):
                for k in range(6):
                    arr[k] = int(max(0, min(1023, round(volt(f"A{k}") / 5.0 * 1023))))
            try:
                h.advance(t, read, adc)
            except McuError as ex:
                raise SimError(str(ex)) from ex

    def _finish_mcu(self):
        r = self.result
        ser, logs = [], {}
        for cid, h in self.hosts.items():
            ref = self.circ.project.components[cid].ref
            ser.extend(h.r.serial)
            logs[ref] = {pin: list(ev) for pin, ev in h.log.items()}
            h.stop()
        ser.sort(key=lambda s_: s_[0])
        r.info["serial"] = ser
        r.info["serial_text"] = "".join(s_ for _, s_ in ser)
        r.info["mcu_log"] = logs

    # ------------------------------------------------------------------ helpers
    def _settle(self, m, x, getA):
        """Re-evaluate behavioural parts (logic ICs, 555, comparators, thyristors) on the new solution; re-solve until their outputs stop changing."""
        c = self.circ
        for _ in range(12):
            changed = False
            for e in c.beh:
                changed |= bool(e.evaluate(x, m))
            if not changed:
                break
            x = c.newton(m, x, A=getA(), b=c.rhs(m))
        return x

    def _op(self, t0=0.0):
        c = self.circ
        c.reset_states()
        m = Ctx("dc", t0)
        x = c.newton(m, np.zeros(c.N))
        if c.beh:
            x = self._settle(m, x, lambda: c.matrix(m))
        return x

    def run(self):
        an = self.settings.get("analysis", "transient")
        try:
            {"op": self._run_op, "dc_sweep": self._run_sweep, "transient": self._run_tran,
             "ac": self._run_ac}[an]()
        except KeyError as ex:
            raise SimError(f"Unknown analog analysis {an!r}") from ex
        return self.result

    # ------------------------------------------------------------------ DC op
    def _run_op(self):
        c, r = self.circ, self.result
        x = self._op()
        self._publish_op(x)
        self.on_update(r, 1.0)

    def _publish_op(self, x):
        c, r = self.circ, self.result
        for i, nm in enumerate(c.node_names):
            net = c.node_net[i]
            pins = ", ".join(f"{c.project.components[cid].ref}.{p}" for cid, p in net.pins) if net else "(internal)"
            r.add(f"V({nm})", float(x[i]), "V", nm, pins)
        r.table = element_table(c, x)
        for row in r.table:
            r.add(f"I({row['ref']})", float(row["I"]), "A", row["ref"])
        self._instrument_op(x)
        r.info["x_op"] = x

    def _instrument_op(self, x):
        c, r = self.circ, self.result
        for comp, kind, nodes in c.meters:
            if kind == "voltmeter":
                v = _v(x, nodes[0]) - _v(x, nodes[1])
                r.instruments[comp.ref] = {"type": "voltmeter", "mode": "DC", "value": float(v), "unit": "V"}
            elif kind == "scope":
                g = _v(x, nodes[2])
                r.instruments[comp.ref] = {"type": "scope", "ch1_dc": float(_v(x, nodes[0]) - g),
                                           "ch2_dc": float(_v(x, nodes[1]) - g)}
        for e in c.els:
            if isinstance(e, VSrc) and e.kind == "zero" and not isinstance(e, PSU) and c.project.by_ref(e.ref).type != "dmm":
                r.instruments[e.ref] = {"type": "ammeter", "value": float(x[e.k]), "unit": "A"}
            if isinstance(e, PSU):
                r.instruments[e.ref] = {"type": "psu", "v": float(_v(x, e.a) - _v(x, e.b)), "i": float(-x[e.k]), "mode": "CC" if e.in_cc(x) else "CV",
                                        "vset": e.p["V"], "ilim": e.ilim}
        for comp, kind, nodes in c.meters:
            if kind.startswith("dmm"):
                r.instruments[comp.ref] = _dmm_reading(comp, kind, nodes, x, None)

    # ------------------------------------------------------------------ DC sweep
    def _run_sweep(self):
        c, r, s = self.circ, self.result, self.settings
        src = c.by_ref.get(s["sweep_ref"])
        if not isinstance(src, VSrc):
            raise SimError(f"DC sweep source {s['sweep_ref']!r} is not a voltage source")
        vals = np.linspace(s["sweep_start"], s["sweep_stop"], int(s["sweep_points"]))
        c.reset_states()
        X = np.zeros((len(vals), c.N))
        x = np.zeros(c.N)
        m = Ctx("dc")
        A = c.matrix(m)
        for i, v in enumerate(vals):
            src.override = float(v)
            x = c.newton(m, x, A=None if c.beh else A)
            if c.beh:
                x = self._settle(m, x, lambda: c.matrix(m))
            X[i] = x
            if i % 20 == 0:
                self.checkpoint(i / len(vals), pace=False)
        src.override = None
        r.info.update(sweep=vals, X=X)
        for i, nm in enumerate(c.node_names):
            r.sig(f"V({nm})", vals, X[:, i], f"{s['sweep_ref']} (V)", "V", group="Node voltages")
        for e in c.els:
            if isinstance(e, VSrc):
                r.sig(f"I({e.ref})", vals, X[:, e.k], f"{s['sweep_ref']} (V)", "A", group="Currents")
            elif isinstance(e, Res) and "." not in e.ref:
                r.sig(f"I({e.ref})", vals, [e.current(x_) for x_ in X], f"{s['sweep_ref']} (V)", "A", group="Currents")
            elif isinstance(e, Diode):
                r.sig(f"I({e.ref})", vals, [e.current(x_) for x_ in X], f"{s['sweep_ref']} (V)", "A", group="Currents")
        r.table = element_table(c, x)
        self.on_update(r, 1.0)

    # ------------------------------------------------------------------ transient
    def _run_tran(self):
        c, r, s = self.circ, self.result, self.settings
        tstop, npts = float(s["tstop"]), int(s["points"])
        if tstop <= 0 or npts < 10:
            raise SimError("Transient needs tstop > 0 and at least 10 points")
        dt = tstop / npts
        c.reset_states()
        N = c.N
        X = np.zeros((npts + 1, N))
        T = np.linspace(0, tstop, npts + 1)
        if s.get("uic", True):
            c.reset_states()
            m0 = Ctx("tran", 0.0, dt * 1e-6, True)
            x = c.newton(m0, np.zeros(N))
            if c.beh:
                x = self._settle(m0, x, lambda: c.matrix(m0))
            for e in c.els:             # restore initial conditions (state untouched by solve)
                e.reset(None)
        else:
            x = self._op()
            c.reset_states(x)
        X[0] = x
        dyn = [e for e in c.els if getattr(e, "dyn", False)]
        mats = {}

        def get_A(first, t):
            key = (first, tuple(e.state(t) for e in dyn))
            if key not in mats:
                mats[key] = c.matrix(Ctx("tran", t, dt, first))
            return mats[key]
        use_mcu = bool(self.hosts)
        lin = not c.nlels and not dyn and not use_mcu
        if lin:
            A_first, A_trap = get_A(True, 0.0), get_A(False, 0.0)
            lu_first = lu_factor(A_first)
            lu_trap = lu_factor(A_trap)
            if not (np.all(np.isfinite(lu_first[0])) and np.all(np.isfinite(lu_trap[0]))):
                raise SimError("Singular circuit matrix in transient analysis (voltage-source loop or floating part?)")
        chunk = max(1, npts // 40)
        for k in range(1, npts + 1):
            m = Ctx("tran", T[k], dt, k == 1)
            if use_mcu:
                self._mcu_step(T[k], x)
            b = c.rhs(m)
            if lin:
                x = lu_solve(lu_first if k == 1 else lu_trap, b)
                if not np.all(np.isfinite(x)):
                    raise SimError("Singular circuit matrix in transient analysis (voltage-source loop?)")
            else:
                x = c.newton(m, x, A=get_A(k == 1, T[k]), b=b)
                if c.beh:
                    x = self._settle(m, x, lambda: get_A(k == 1, T[k]))
            for e in c.els:
                e.accept(x, m)
            X[k] = x
            if k % chunk == 0 or k == npts:
                self.checkpoint(k / npts)
                self._publish_tran(T[: k + 1], X[: k + 1], final=(k == npts))
                self.on_update(r, k / npts)
        r.info.update(T=T, X=X)
        if use_mcu:
            self._finish_mcu()
        self._collect_buzzers(T, X)

    def _collect_buzzers(self, T, X):
        c, r = self.circ, self.result
        out = []
        for comp, kind, nodes in c.meters:
            if kind != "buzzer":
                continue
            a, b = nodes
            va = X[:, a] if a >= 0 else 0 * T
            vb = X[:, b] if b >= 0 else 0 * T
            events = None
            for cid, h in self.hosts.items():
                for pin, ev in h.log.items():
                    if c.net_of.get((cid, f"D{pin}")) == a and a >= 0:
                        events = ev
            out.append({"ref": comp.ref, "kind": "speaker" if comp.type == "speaker" else comp.params["kind"], "volume": comp.params["volume"], "t": np.asarray(T), "v": np.asarray(va - vb),
                        "events": events, "tstop": float(T[-1])})
        r.info["buzzers"] = out

    def _publish_tran(self, T, X, final):
        c, r = self.circ, self.result
        r.signals.clear()
        for i, nm in enumerate(c.node_names):
            r.sig(f"V({nm})", T, X[:, i], "t (s)", "V", group="Node voltages")
        cur = {}
        for e in c.els:
            if isinstance(e, VSrc):
                cur[e.ref] = X[:, e.k]
            elif isinstance(e, Ind):
                cur[e.ref] = X[:, e.k]
            elif isinstance(e, Res) and "." not in e.ref:
                cur[e.ref] = (np.where(e.a >= 0, X[:, max(e.a, 0)], 0) - np.where(e.b >= 0, X[:, max(e.b, 0)], 0)) / e.R
            elif isinstance(e, Diode):
                va = X[:, e.a] if e.a >= 0 else 0 * T
                vk = X[:, e.k] if e.k >= 0 else 0 * T
                cur[e.ref] = e.current_vec(va, vk)
        for ref, y in cur.items():
            r.sig(f"I({ref})", T, y, "t (s)", "A", group="Currents")
        # instruments
        for comp, kind, nodes in c.meters:
            def col(i):
                return X[:, i] if i >= 0 else np.zeros(len(T))
            if kind == "voltmeter":
                v = col(nodes[0]) - col(nodes[1])
                r.instruments[comp.ref] = {"type": "voltmeter", "t": T, "v": v, "value": float(v[-1]),
                                           "mean": float(np.mean(v)), "rms": float(np.sqrt(np.mean(v ** 2))),
                                           "pp": float(np.ptp(v)), "unit": "V", "mode": "TRAN"}
            elif kind == "scope":
                g = col(nodes[2])
                r.instruments[comp.ref] = {"type": "scope", "t": T, "ch1": col(nodes[0]) - g, "ch2": col(nodes[1]) - g}
        for e in c.els:
            if isinstance(e, PSU):
                ii = -X[:, e.k]
                r.instruments[e.ref] = {"type": "psu", "v": float((X[-1, e.a] if e.a >= 0 else 0) - (X[-1, e.b] if e.b >= 0 else 0)), "i": float(ii[-1]),
                                        "mode": "CC" if e.in_cc(X[-1]) else "CV", "vset": e.p["V"], "ilim": e.ilim}
        for comp, kind, nodes in c.meters:
            if kind.startswith("dmm"):
                r.instruments[comp.ref] = _dmm_reading(comp, kind, nodes, X[-1], X)
        for e in c.els:
            if isinstance(e, VSrc) and e.kind == "zero" and c.project.by_ref(e.ref).type != "dmm":
                y = X[:, e.k]
                r.instruments[e.ref] = {"type": "ammeter", "t": T, "i": y, "value": float(y[-1]),
                                        "mean": float(np.mean(y)), "rms": float(np.sqrt(np.mean(y ** 2))), "unit": "A"}
        if final:
            r.measurements.clear()
            for i, nm in enumerate(c.node_names):
                y = X[:, i]
                r.add(f"V({nm}) final", float(y[-1]), "V", nm)
                r.add(f"V({nm}) rms", float(np.sqrt(np.mean(y ** 2))), "V", nm)
                r.add(f"V({nm}) pk-pk", float(np.ptp(y)), "V", nm)
            r.table = element_table(c, X[-1])

    # ------------------------------------------------------------------ AC
    def _run_ac(self):
        c, r, s = self.circ, self.result, self.settings
        x_op = self._op()
        Jop = c.jacobian_at(x_op)
        f = np.logspace(np.log10(s["fmin"]), np.log10(s["fmax"]), int(s["fpoints"]))
        H = np.zeros((len(f), c.N), dtype=complex)
        b = c.rhs(Ctx("ac", w=1.0))
        if not np.any(b):
            raise SimError("AC analysis needs an AC voltage source (amplitude > 0)")
        for i, fr in enumerate(f):
            m = Ctx("ac", w=2 * math.pi * fr)
            A = c.matrix(m) + Jop
            H[i] = Circuit._solve(A, b, f"at f={fr:g} Hz")
            if i % 10 == 0:
                self.checkpoint(i / len(f), pace=False)
        r.info.update(f=f, H=H, x_op=x_op)
        for i, nm in enumerate(c.node_names):
            r.sig(f"|V({nm})|", f, np.abs(H[:, i]), "f (Hz)", "V", group="Magnitude")
            r.sig(f"∠V({nm})", f, np.degrees(np.angle(H[:, i])), "f (Hz)", "deg", group="Phase")
        for e in c.els:
            if isinstance(e, VSrc):
                r.sig(f"|I({e.ref})|", f, np.abs(H[:, e.k]), "f (Hz)", "A", group="Current magnitude")
        r.table = element_table(c, x_op)
        self.on_update(r, 1.0)


def run_analog(project, **settings) -> "SimResult":
    """Synchronous helper for tests and analysis experiments."""
    eng = AnalogEngine()
    errs = [d for d in eng.validate(project) if d.severity == "error"]
    if errs:
        raise SimError("; ".join(d.message for d in errs))
    eng.prepare(project, settings)
    eng.run()
    eng.result.info["circuit"] = eng.circ
    return eng.result


def pin_voltage(res, ref_pin: str):
    """Node voltage at 'R1.2' from a finished run (scalar for op, array for sweeps/transient, complex for AC)."""
    circ = res.info["circuit"]
    ref, pin = ref_pin.split(".", 1)
    c = circ.project.by_ref(ref)
    i = circ.net_of[(c.id, pin)]
    if "x_op" in res.info and "X" not in res.info and "H" not in res.info:
        return 0.0 if i < 0 else float(res.info["x_op"][i])
    if "H" in res.info:
        return np.zeros(len(res.info["f"])) if i < 0 else res.info["H"][:, i]
    X = res.info["X"]
    return np.zeros(len(X)) if i < 0 else X[:, i]


def branch_current(res, ref: str):
    """Branch current of a V source / ammeter / inductor (positive from + terminal through the element)."""
    circ = res.info["circuit"]
    k = circ.by_ref[ref].k
    if "x_op" in res.info and "X" not in res.info and "H" not in res.info:
        return float(res.info["x_op"][k])
    if "H" in res.info:
        return res.info["H"][:, k]
    return res.info["X"][:, k]
