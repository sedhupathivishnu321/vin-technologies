"""Common simulation types and engine interface."""
from __future__ import annotations
import threading
import time
from dataclasses import dataclass, field
import numpy as np


class Cancelled(Exception):
    pass


class SimError(Exception):
    """A simulation could not be completed; message is shown to the user."""


@dataclass
class Diagnostic:
    severity: str          # info | warning | error
    source: str            # component ref or subsystem
    message: str
    component_id: str | None = None
    t: float = field(default_factory=time.time)


@dataclass
class Measurement:
    name: str
    value: float | str
    unit: str = ""
    source: str = ""
    note: str = ""


@dataclass
class Signal:
    name: str
    x: np.ndarray
    y: np.ndarray
    xlabel: str = "t (s)"
    ylabel: str = ""
    kind: str = "line"        # line | step | stem | scatter
    group: str = ""           # signals with the same group are drawn on the same plot
    logy: bool = False
    logx: bool = False


@dataclass
class Check:
    """Automated validation of a result against an analytic/reference value."""
    name: str
    passed: bool
    detail: str = ""


@dataclass
class SimResult:
    engine: str
    measurements: list = field(default_factory=list)
    signals: dict = field(default_factory=dict)
    table: list = field(default_factory=list)          # list[dict]
    instruments: dict = field(default_factory=dict)     # ref -> reading dict
    diagnostics: list = field(default_factory=list)
    checks: list = field(default_factory=list)
    info: dict = field(default_factory=dict)

    def m(self, name, default=None):
        for x in self.measurements:
            if x.name == name:
                return x.value
        return default

    def add(self, name, value, unit="", source="", note=""):
        self.measurements.append(Measurement(name, value, unit, source, note))

    def sig(self, name, x, y, xlabel="t (s)", ylabel="", kind="line", group="", logy=False, logx=False):
        self.signals[name] = Signal(name, np.asarray(x), np.asarray(y), xlabel, ylabel, kind, group or name,
                                    logy, logx)

    def check(self, name, passed, detail=""):
        self.checks.append(Check(name, bool(passed), detail))

    @property
    def errors(self):
        return [d for d in self.diagnostics if d.severity == "error"]


class Engine:
    """Lifecycle: validate → prepare → run (streams via on_update) → get_*.  pause/stop/reset are thread-safe."""
    name = "engine"
    streaming = False

    def __init__(self):
        self._stop = threading.Event()
        self._run_ok = threading.Event()
        self._run_ok.set()
        self.speed = 0.0                 # 0 = as fast as possible; otherwise wall-clock seconds for a full run
        self.result = SimResult(self.name)
        self.on_update = lambda res, frac: None
        self.project = None
        self.settings = {}

    # -- API from the brief
    def validate(self, project) -> list:
        return []

    def prepare(self, project, settings):
        self.project, self.settings = project, dict(settings)
        self._stop.clear()
        self._run_ok.set()
        self.result = SimResult(self.name)

    def run(self):
        raise NotImplementedError

    def pause(self):
        self._run_ok.clear()

    def resume(self):
        self._run_ok.set()

    def stop(self):
        self._stop.set()
        self._run_ok.set()

    def reset(self):
        self.stop()
        self.result = SimResult(self.name)

    def get_measurements(self):
        return self.result.measurements

    def get_waveforms(self):
        return self.result.signals

    def get_diagnostics(self):
        return self.result.diagnostics

    # -- helpers for subclasses
    def checkpoint(self, frac=None, pace=True):
        """Call between work chunks: honours stop/pause and applies speed pacing."""
        if self._stop.is_set():
            raise Cancelled()
        while not self._run_ok.wait(0.05):
            if self._stop.is_set():
                raise Cancelled()
        if pace and self.speed > 0 and frac is not None:
            time.sleep(self.speed / 40.0)
