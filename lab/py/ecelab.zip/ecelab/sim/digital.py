"""Digital logic engine: 3-valued (0/1/X) event-driven, zero-delay simulation with edge-triggered sequential state.

Declared limits: zero propagation delay (no glitches/hazards, race-around is not reproduced), no tri-state, edge
detection happens at exact event times (clock edges / switch pattern changes), not on a sampled grid.
"""
from __future__ import annotations
import heapq
import itertools
import numpy as np

from ..mcu.runner import McuRunner, McuError

from .base import Engine, SimError, Diagnostic

X = None


def n3(a): return X if a is X else 1 - a
def and3(a, b): return 0 if (a == 0 or b == 0) else (1 if (a == 1 and b == 1) else X)
def or3(a, b): return 1 if (a == 1 or b == 1) else (0 if (a == 0 and b == 0) else X)
def xor3(a, b): return X if (a is X or b is X) else a ^ b


COMB = {
    "and": lambda i: {"Y": and3(i["A"], i["B"])},
    "or": lambda i: {"Y": or3(i["A"], i["B"])},
    "not": lambda i: {"Y": n3(i["A"])},
    "nand": lambda i: {"Y": n3(and3(i["A"], i["B"]))},
    "nor": lambda i: {"Y": n3(or3(i["A"], i["B"]))},
    "xor": lambda i: {"Y": xor3(i["A"], i["B"])},
    "xnor": lambda i: {"Y": n3(xor3(i["A"], i["B"]))},
    "mux2": lambda i: {"Y": or3(and3(n3(i["S"]), i["A"]), and3(i["S"], i["B"]))},
    "hadd": lambda i: {"S": xor3(i["A"], i["B"]), "C": and3(i["A"], i["B"])},
    "fadd": lambda i: {"S": xor3(xor3(i["A"], i["B"]), i["CI"]),
                       "CO": or3(or3(and3(i["A"], i["B"]), and3(i["A"], i["CI"])), and3(i["B"], i["CI"]))},
}
SEQ = ("dff", "jkff", "tff", "counter4", "shift4")
SOURCES = ("clock", "lswitch")


def clock_level(f, t):
    return int(np.floor(round(t * 2 * f, 9))) % 2


def switch_level(p, t):
    pat = str(p.get("pattern", "")).strip()
    if pat:
        k = int(t // p["step"] + 1e-9)
        return int(pat[min(k, len(pat) - 1)])
    return int(p["value"])


class DigitalEngine(Engine):
    name = "digital"
    streaming = True

    # ---------------------------------------------------------------- validation
    def validate(self, project):
        d = []
        comps = [c for c in project.components.values() if c.defn.engine == "digital"]
        if not comps:
            return [Diagnostic("error", "digital", "No digital components on the canvas")]
        if any(c.defn.engine == "analog" for c in project.components.values()):
            d.append(Diagnostic("error", "digital", "Project mixes analog and digital parts; mixed-signal simulation "
                                "is not supported"))
        nets = project.nets()
        for net in nets:
            drivers = [(project.components[c], p) for c, p in net.pins
                       if project.components[c].defn.engine == "digital" and project.components[c].defn.pin(p).role == "out"]
            if len(drivers) > 1:
                d.append(Diagnostic("error", "digital", "Conflicting drivers on net " + net.name + ": " +
                                    ", ".join(f"{c.ref}.{p}" for c, p in drivers), drivers[0][0].id))
            inputs = [(project.components[c], p) for c, p in net.pins
                      if project.components[c].defn.engine == "digital" and project.components[c].defn.pin(p).role == "in"]
            if inputs and not drivers:
                for c, p in inputs:
                    d.append(Diagnostic("warning", f"{c.ref}.{p}", "Floating input (undriven, evaluates to X)", c.id))
        d.extend(self._loop_diagnostics(project, comps))
        for c in comps:
            if c.type == "arduino":
                try:
                    McuRunner(c.params["code"], ref=c.ref)
                except McuError as ex:
                    d.append(Diagnostic("error", c.ref, f"Sketch does not compile: {ex}", c.id))
        for c in comps:
            if c.type == "lswitch" and c.params["pattern"] and not set(c.params["pattern"]) <= set("01"):
                d.append(Diagnostic("error", c.ref, "Pattern must contain only 0 and 1", c.id))
            if c.type == "clock" and c.params["freq"] <= 0:
                d.append(Diagnostic("error", c.ref, "Clock frequency must be > 0", c.id))
            if c.type == "shift4" and (len(str(c.params["init"])) != 4 or not set(str(c.params["init"])) <= set("01")):
                d.append(Diagnostic("error", c.ref, "init must be 4 bits like 0000", c.id))
        return d

    @staticmethod
    def _loop_diagnostics(project, comps):
        """Structural combinational-loop detection (feedback through COMB gates only)."""
        comb = {c.id: c for c in comps if c.type in COMB}
        netix = {}
        for net in project.nets():
            for k in net.pins:
                netix[k] = net.index
        drives, readers = {}, {}
        for c in comb.values():
            for p in c.defn.pins:
                (drives if p.role == "out" else readers).setdefault(netix[(c.id, p.name)], []).append(c.id)
        graph = {cid: set() for cid in comb}
        for ix, srcs in drives.items():
            for s in srcs:
                graph[s].update(readers.get(ix, []))
        WHITE, GREY, BLACK = 0, 1, 2
        color = {k: WHITE for k in graph}
        out, found = [], []

        def dfs(u, stack):
            color[u] = GREY
            for v in graph[u]:
                if color[v] == GREY:
                    found.append(stack[stack.index(v):] + [v] if v in stack else [u, v])
                elif color[v] == WHITE:
                    dfs(v, stack + [v])
            color[u] = BLACK
        for k in graph:
            if color[k] == WHITE:
                dfs(k, [k])
        for cyc in found[:3]:
            refs = " → ".join(comb[i].ref for i in cyc)
            out.append(Diagnostic("error", "digital", f"Combinational loop: {refs}. Use a flip-flop part for storage "
                                  "(cross-coupled gates are not supported by the zero-delay engine)", cyc[0]))
        return out

    # ---------------------------------------------------------------- preparation
    def prepare(self, project, settings):
        super().prepare(project, settings)
        self.comps = [c for c in project.components.values() if c.defn.engine == "digital"]
        self.nets = project.nets()
        self.netix = {}
        for net in self.nets:
            for k in net.pins:
                self.netix[k] = net.index
        self.state = {}
        self.mcus = {}
        self.reset_state()
        self.result.diagnostics = [x for x in self.validate(project) if x.severity != "error"]
        self.labels = self._labels()

    def reset_state(self):
        for c in self.comps:
            if c.type in ("dff", "jkff", "tff"):
                self.state[c.id] = int(c.params["init"])
            elif c.type == "counter4":
                self.state[c.id] = 0
            elif c.type == "shift4":
                self.state[c.id] = [int(ch) for ch in str(c.params["init"])]

    def _labels(self):
        lab = {}
        for net in self.nets:
            names = []
            for cid, pin in net.pins:
                c = self.project.components[cid]
                if c.defn.engine != "digital":
                    continue
                role = c.defn.pin(pin).role
                if c.type == "lprobe":
                    names.insert(0, c.ref)
                elif c.type in SOURCES:
                    names.append(c.ref)
                elif role in ("out", "io"):
                    names.append(f"{c.ref}.{pin}")
            lab[net.index] = names[0] if names else net.name
        return lab

    def pin_net(self, c, pin):
        return self.netix[(c.id, pin)]

    # ---------------------------------------------------------------- evaluation
    def settle(self, vals, t, st=None):
        """Evaluate sources, async resets and combinational logic until stable. vals: list indexed by net."""
        st = self.state if st is None else st
        n_pass = 0
        limit = len(self.comps) + 6
        while True:
            changed = False
            n_pass += 1
            if n_pass > limit:
                loop = [c.ref for c in self.comps if c.type in COMB]
                raise SimError(f"Combinational loop or oscillation detected (no stable state at t={t:g} s); "
                               f"check feedback through: {', '.join(loop)}")
            new = {}
            for c in self.comps:
                tp = c.type
                if tp == "clock":
                    new[self.pin_net(c, "OUT")] = clock_level(c.params["freq"], t)
                elif tp == "lswitch":
                    new[self.pin_net(c, "OUT")] = switch_level(c.params, t)
                elif tp in COMB:
                    ins = {p.name: vals[self.pin_net(c, p.name)] for p in c.defn.pins if p.role == "in"}
                    for pin, v in COMB[tp](ins).items():
                        new[self.pin_net(c, pin)] = v
                elif tp == "arduino":
                    rn = self.mcus.get(c.id)
                    if rn is not None:
                        for pin, mode in rn.modes.items():
                            if mode == 1 and 2 <= pin <= 13:
                                new[self.pin_net(c, f"D{pin}")] = rn.levels.get(pin, 0)
                elif tp in SEQ:
                    r = vals[self.pin_net(c, "R")] if any(p.name == "R" for p in c.defn.pins) else 0
                    if r == 1:
                        st[c.id] = [0, 0, 0, 0] if tp == "shift4" else 0
                    s = st[c.id]
                    if tp == "counter4":
                        for k in range(4):
                            new[self.pin_net(c, f"Q{k}")] = (s >> k) & 1
                    elif tp == "shift4":
                        for k in range(4):
                            new[self.pin_net(c, f"Q{k}")] = s[k]
                    else:
                        new[self.pin_net(c, "Q")] = s
                        new[self.pin_net(c, "QN")] = 1 - s
            for ix, v in new.items():
                if vals[ix] != v:
                    vals[ix] = v
                    changed = True
            if not changed:
                return

    def _edges(self, st, prev_clk, vals, old_vals, t):
        """Trigger flops whose CLK net rose; returns True if any state changed."""
        rising = []
        for c in self.comps:
            if c.type in SEQ:
                ix = self.pin_net(c, "CLK")
                if prev_clk.get(c.id, 0) == 0 and vals[ix] == 1:
                    rising.append(c)
                prev_clk[c.id] = vals[ix] if vals[ix] is not X else 0
        if not rising:
            return False
        def inp(c, pin):
            return old_vals[self.pin_net(c, pin)]
        upd = {}
        for c in rising:
            if c.type == "dff":
                upd[c.id] = inp(c, "D")
            elif c.type == "tff":
                T = inp(c, "T")
                upd[c.id] = st[c.id] ^ T if T is not X else X
            elif c.type == "jkff":
                J, K = inp(c, "J"), inp(c, "K")
                q = st[c.id]
                if J is X or K is X:
                    upd[c.id] = X
                else:
                    upd[c.id] = q if (J, K) == (0, 0) else 0 if (J, K) == (0, 1) else 1 if (J, K) == (1, 0) else 1 - q
            elif c.type == "counter4":
                upd[c.id] = (st[c.id] + 1) & 15
            elif c.type == "shift4":
                D = inp(c, "D")
                upd[c.id] = [D] + st[c.id][:3]
        for cid, v in upd.items():
            if v is X and not isinstance(v, list):
                raise SimError(f"{self.project.components[cid].ref}: clocked with unknown (X) data input; "
                               "drive all inputs before the first clock edge")
            if isinstance(v, list) and v[0] is X:
                raise SimError(f"{self.project.components[cid].ref}: shift register input is X (undriven)")
            st[cid] = v
        return True

    def step(self, t, vals, prev_clk, first=False):
        """Advance to event time t. vals is modified in place; returns nothing."""
        old = list(vals)
        self.settle(vals, t)
        if first:
            for c in self.comps:
                if c.type in SEQ:
                    ix = self.pin_net(c, "CLK")
                    prev_clk[c.id] = vals[ix] if vals[ix] is not X else 0
            return
        snapshot = old
        for _ in range(len(self.comps) + 4):
            if not self._edges(self.state, prev_clk, vals, snapshot, t):
                return
            snapshot = list(vals)
            self.settle(vals, t)
        raise SimError(f"Clock ripple did not settle at t={t:g} s")

    # ---------------------------------------------------------------- run
    def _event_times(self, tstop):
        times = {0.0}
        for c in self.comps:
            if c.type == "clock":
                half = 0.5 / c.params["freq"]
                k = 1
                while k * half <= tstop + 1e-12:
                    times.add(round(k * half, 12)); k += 1
                    if k > 200000:
                        raise SimError("Too many clock edges; reduce tstop or clock frequency")
            elif c.type == "lswitch" and str(c.params["pattern"]).strip():
                k = 1
                while k * c.params["step"] <= tstop + 1e-12 and k < len(c.params["pattern"]):
                    times.add(round(k * c.params["step"], 12)); k += 1
        return sorted(times)

    def run(self):
        r = self.result
        if self.settings.get("analysis") == "truth":
            rows = truth_table(self.project)
            r.table = [{**ins, **{k: ("X" if v is X else v) for k, v in outs.items()}} for ins, outs in rows]
            r.add("Truth-table rows", len(rows), "", note="every combination of the logic switches; sequential state at its initial value")
            self.on_update(r, 1.0)
            return r
        tstop = float(self.settings.get("tstop", 10.0))
        static = self._event_times(tstop)
        self.reset_state()
        self.mcus = {}
        for c in self.comps:
            if c.type == "arduino":
                p = c.params
                self.mcus[c.id] = McuRunner(p["code"], [p["a0"], p["a1"], p["a2"], p["a3"], 0, 0], int(self.settings.get("seed", 1)), c.ref)
        heap, seq, token = [], itertools.count(), {}
        for cid in self.mcus:
            heapq.heappush(heap, (0.0, next(seq), "wake", cid, None))
        vals = [X] * len(self.nets)
        prev_clk = {}
        hist = []
        si, n_ev, first, last_pub = 0, 0, True, -1.0
        try:
            while True:
                cands = []
                if si < len(static):
                    cands.append(static[si])
                if heap:
                    cands.append(heap[0][0])
                if not cands:
                    break
                t = min(cands)
                if t > tstop + 1e-12:
                    break
                while si < len(static) and static[si] <= t + 1e-12:
                    si += 1
                due = []
                while heap and heap[0][0] <= t + 1e-12:
                    due.append(heapq.heappop(heap))
                self.step(t, vals, prev_clk, first=first)
                first = False
                for ev in due:
                    self._mcu_event(ev, t, vals, heap, seq, token)
                if due:
                    self.step(t, vals, prev_clk)
                hist.append((t, list(vals)))
                n_ev += 1
                if n_ev > 400000:
                    raise SimError("Too many simulation events (400000). Reduce the run time or the clock/PWM frequency.")
                if t - last_pub >= tstop / 40 or t >= tstop:
                    last_pub = t
                    self.checkpoint(min(1.0, t / tstop))
                    self._publish(hist, tstop, final=False)
                    self.on_update(r, min(1.0, t / tstop))
            self.checkpoint(1.0)
            self._publish(hist, tstop, final=True)
            self.on_update(r, 1.0)
        finally:
            for rn in self.mcus.values():
                rn.stop()
        return r

    def _mcu_event(self, ev, t, vals, heap, seq, token):
        _, _, kind, cid, extra = ev
        rn = self.mcus[cid]
        c = self.project.components[cid]
        if kind == "wake":
            inputs = {}
            for pin in range(2, 14):
                v = vals[self.pin_net(c, f"D{pin}")]
                inputs[pin] = None if v is X else v
            try:
                wake = rn.resume(t, inputs)
            except McuError as ex:
                raise SimError(str(ex)) from ex
            if wake is not None:
                heapq.heappush(heap, (max(wake, t), next(seq), "wake", cid, None))
            for pin in sorted(rn.pwm_dirty):
                token[(cid, pin)] = token.get((cid, pin), 0) + 1
                cfg = rn.pwm.get(pin)
                if cfg:
                    rn.levels[pin] = 1
                    heapq.heappush(heap, (t + cfg[0] * cfg[1], next(seq), "pwm", cid, (pin, token[(cid, pin)], 0)))
            rn.pwm_dirty.clear()
        else:                                                    # PWM edge
            pin, tok, level = extra
            if token.get((cid, pin)) != tok or pin not in rn.pwm:
                return
            duty, period = rn.pwm[pin]
            rn.levels[pin] = level
            if level == 1:
                heapq.heappush(heap, (t + duty * period, next(seq), "pwm", cid, (pin, tok, 0)))
            else:
                heapq.heappush(heap, (t + (1 - duty) * period, next(seq), "pwm", cid, (pin, tok, 1)))

    def _publish(self, hist, tstop, final):
        r = self.result
        T = np.array([h[0] for h in hist] + [max(tstop, hist[-1][0])])
        probes = [c for c in self.comps if c.type == "lprobe"]
        show = {ix for ix in range(len(self.nets)) if any(
            (self.project.components[cid].defn.engine == "digital" and
             (self.project.components[cid].defn.pin(p).role in ("out", "io") or self.project.components[cid].type == "lprobe"))
            for cid, p in self.nets[ix].pins)}
        r.signals.clear()
        for ix in sorted(show):
            y = np.array([np.nan if h[1][ix] is X else h[1][ix] for h in hist], dtype=float)
            if np.all(np.isnan(y)):
                continue                                   # never-driven net (e.g. unused MCU pin): nothing to show
            y = np.append(y, y[-1])
            r.sig(self.labels[ix], T, y, "t (s)", "logic", kind="step", group="Logic")
        r.table = []
        for t, v in hist:
            row = {"t": t}
            for c in probes:
                val = v[self.pin_net(c, "IN")]
                row[c.ref] = "X" if val is X else val
            r.table.append(row)
        for c in probes:
            r.instruments[c.ref] = {"type": "probe", "value": r.table[-1][c.ref]}
        last = hist[-1][1]
        for c in self.comps:
            if c.type == "arduino":
                r.instruments[c.ref] = {"type": "mcu", "levels": {p.name: last[self.pin_net(c, p.name)] for p in c.defn.pins}}
            if c.type == "sevenseg":
                r.instruments[c.ref] = {"type": "sevenseg", "levels": {p.name: last[self.pin_net(c, p.name)] for p in c.defn.pins}}
        ser = []
        for rn in self.mcus.values():
            ser.extend(rn.serial)
        ser.sort(key=lambda x: x[0])
        r.info["serial"] = ser
        r.info["serial_text"] = "".join(s for _, s in ser)
        if final:
            r.measurements.clear()
            for c in probes:
                col = [row[c.ref] for row in r.table]
                r.add(f"{c.ref} final", col[-1], "", c.ref)
                r.add(f"{c.ref} transitions", sum(1 for a, b in zip(col, col[1:]) if a != b), "", c.ref)
            r.info["states"] = {self.project.components[k].ref: v for k, v in self.state.items()}
            r.info["events"] = len(hist)


def truth_table(project, max_inputs=12, fixed=None):
    """Exhaustive combinational truth table over all logic switches → probes (sequential state held at init)."""
    project = project.clone()
    eng = DigitalEngine()
    errs = [d for d in eng.validate(project) if d.severity == "error"]
    if errs:
        raise SimError("; ".join(d.message for d in errs))
    eng.prepare(project, {})
    fixed = fixed or {}
    held = [c for c in eng.comps if c.type == "lswitch" and c.ref in fixed]
    for c in held:
        c.params["pattern"] = ""; c.params["value"] = int(fixed[c.ref])
    sws = sorted([c for c in eng.comps if c.type == "lswitch" and c.ref not in fixed], key=lambda c: c.ref)
    probes = sorted([c for c in eng.comps if c.type == "lprobe"], key=lambda c: c.ref)
    if len(sws) > max_inputs:
        raise SimError(f"Truth table needs 2^{len(sws)} rows; limit is {max_inputs} inputs")
    rows = []
    for combo in itertools.product((0, 1), repeat=len(sws)):
        for c, b in zip(sws, combo):
            c.params["pattern"] = ""; c.params["value"] = b
        vals = [X] * len(eng.nets)
        eng.reset_state()
        eng.settle(vals, 0.0)
        rows.append(({c.ref: b for c, b in zip(sws, combo)},
                     {p.ref: vals[eng.pin_net(p, "IN")] for p in probes}))
    return rows


def run_digital(project, **settings):
    eng = DigitalEngine()
    errs = [d for d in eng.validate(project) if d.severity == "error"]
    if errs:
        raise SimError("; ".join(d.message for d in errs))
    eng.prepare(project, settings)
    eng.run()
    eng.result.info["engine"] = eng
    return eng.result
