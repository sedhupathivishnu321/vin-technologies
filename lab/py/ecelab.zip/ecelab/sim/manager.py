"""Engine selection and synchronous execution. The Qt wrapper lives in ui/simctl.py."""
from __future__ import annotations
from .analog import AnalogEngine
from .digital import DigitalEngine
from .base import SimError, Diagnostic, SimResult


def engine_for(project):
    kinds = {c.defn.engine for c in project.components.values()} - {"none", "board"}
    if not kinds:
        raise SimError("The canvas has no simulatable components")
    if kinds == {"analog"}:
        return AnalogEngine()
    if kinds == {"digital"}:
        return DigitalEngine()
    raise SimError("Project mixes analog and digital parts; mixed-signal simulation is not supported")


def validate_project(project) -> list:
    """Diagnostics for the validation badge, without running anything."""
    diags = []
    for c in project.components.values():
        if c.defn.engine == "none":
            diags.append(Diagnostic("warning", c.ref, f"{c.defn.name} is visual-only: it will not take part in the simulation", c.id))
    try:
        eng = engine_for(project)
    except SimError as ex:
        diags.append(Diagnostic("error", "project", str(ex)))
        return diags
    return diags + eng.validate(project)


def settings_for(project, engine):
    s = dict(project.sim)
    if engine.name == "digital":
        if s.get("analysis") in (None, "transient", "op", "ac", "dc_sweep"):
            s["analysis"] = "digital"
            s["tstop"] = 10.0                      # analog-style default span is meaningless for clocked logic
    else:
        if s.get("analysis") in ("digital", "truth"):
            s["analysis"] = "transient"
    return s


def run_sync(project, settings=None, on_update=None) -> tuple:
    """Validate, prepare and run. Returns (engine, result). Raises SimError on validation errors / failure."""
    project = project.clone()
    eng = engine_for(project)
    errs = [d for d in eng.validate(project) if d.severity == "error"]
    if errs:
        err = SimError("; ".join(d.message for d in errs))
        err.diagnostics = errs
        raise err
    eng.prepare(project, settings if settings is not None else settings_for(project, eng))
    if on_update:
        eng.on_update = on_update
    eng.run()
    add_ratings(project, eng)
    return eng, eng.result


def add_ratings(project, eng):
    """Append rating warnings (power/current/voltage vs user-set specs) to the result diagnostics."""
    if eng.name == "analog":
        from .ratings import check_ratings
        eng.result.diagnostics.extend(check_ratings(project, eng.result))
