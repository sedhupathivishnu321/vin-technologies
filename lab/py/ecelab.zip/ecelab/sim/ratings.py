"""Component rating checks (power, current, voltage) against user-set specs, from the actual simulation result."""
from __future__ import annotations
import numpy as np

from .base import Diagnostic


def _peak(res, key, fallback):
    s = res.signals.get(key)
    if s is not None and len(s.y):
        return float(np.max(np.abs(s.y)))
    return fallback


def check_ratings(project, res) -> list:
    """Warnings for parts operated beyond their rated spec. Uses peak transient values when a transient was run, otherwise the DC/AC operating point."""
    out = []
    rows = {r["ref"]: r for r in res.table} if res.table else {}
    for c in project.components.values():
        p, t = c.params, c.type
        row = rows.get(c.ref)
        if t in ("resistor", "pot") and row and "P" in p:
            R = p["R"] if t == "resistor" else None
            if t == "resistor":
                i = _peak(res, f"I({c.ref})", abs(row["I"]))
                P = i * i * R if "I(%s)" % c.ref in res.signals else abs(row["P"])
                if P > p["P"] * 1.0001:
                    out.append(Diagnostic("warning", c.ref, f"{c.ref} dissipates {P*1000:.1f} mW, above its {p['P']*1000:.0f} mW rating", c.id))
        elif t in ("led", "diode") and row:
            i = _peak(res, f"I({c.ref})", abs(row["I"]))
            lim = p.get("Imax")
            if lim and i > lim * 1.0001:
                out.append(Diagnostic("warning", c.ref, f"{c.ref} carries {i*1000:.1f} mA, above its {lim*1000:.0f} mA maximum forward current", c.id))
        elif t == "zener" and row:
            i = _peak(res, f"I({c.ref})", abs(row["I"]))
            P = abs(row["V"]) * i
            if P > p["Pz"] * 1.0001:
                out.append(Diagnostic("warning", c.ref, f"{c.ref} dissipates {P*1000:.0f} mW, above its {p['Pz']*1000:.0f} mW rating", c.id))
        elif t == "npn" and row:
            P = abs(row["V"] * row["I"])
            if P > p["Pd"] * 1.0001:
                out.append(Diagnostic("warning", c.ref, f"{c.ref} dissipates {P*1000:.0f} mW, above its {p['Pd']*1000:.0f} mW rating", c.id))
        elif t == "capacitor" and row:
            v = abs(row["V"])
            if v > p["Vmax"] * 1.0001:
                out.append(Diagnostic("warning", c.ref, f"{c.ref} sees {v:.1f} V, above its {p['Vmax']:g} V rating", c.id))
    return out
