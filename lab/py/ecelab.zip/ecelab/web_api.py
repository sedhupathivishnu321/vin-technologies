"""JSON-friendly entry points for the browser build (Pyodide). The web UI calls these and never touches the engine directly."""
from __future__ import annotations
import json
import math

import numpy as np

from . import catalogue as _catalogue                                       # noqa: F401  (registers the datasheet parts)
from . import examples as _examples
from . import labs as _labs                                                  # noqa: F401  (registers the lab experiments)
from .core import parts
from .core.model import Project
from .sim.base import SimError
from .sim.manager import run_sync, validate_project

EXAMPLES = _examples.EXAMPLES
MAX_POINTS = 700
ECAP = [0.47, 1, 2.2, 4.7, 10, 22, 47, 100, 220, 470, 1000, 2200, 4700]
CAP_FILES = {0.0001: "0.0001", 0.000022: "0.000022", 0.001: "0.001", 0.01: "0.01", 0.047: "0.047", 0.1: "0.1", 0.22: "0.22", 1: "1"}
RES_VALUES = None                                                            # set by the page: sorted list of available res_<ohms> sprites


def _clean(v):
    if isinstance(v, (np.floating, float)):
        v = float(v)
        return v if math.isfinite(v) else None
    if isinstance(v, (np.integer,)):
        return int(v)
    if isinstance(v, (np.bool_,)):
        return bool(v)
    if isinstance(v, (list, tuple)):
        return [_clean(x) for x in v]
    if isinstance(v, dict):
        return {str(k): _clean(x) for k, x in v.items() if not str(k).startswith("_")}
    if isinstance(v, np.ndarray):
        return [_clean(x) for x in v.tolist()]
    if isinstance(v, (str, int, bool)) or v is None:
        return v
    return str(v)


def part_defs() -> str:
    out = {}
    for t, d in parts.REGISTRY.items():
        out[t] = dict(type=t, name=d.name, category=d.category, description=d.description, engine=d.engine, prefix=d.prefix, symbol=d.symbol,
                      box=list(d.box), label=d.label, status=d.status, level=d.level,
                      pins=[dict(name=p.name, dx=p.dx, dy=p.dy, role=p.role) for p in d.pins],
                      params={k: dict(default=_clean(p.default), unit=p.unit, label=p.label or k, choices=list(p.choices), help=p.help) for k, p in d.params.items()},
                      sprite=list(d.sprite) if d.sprite else None, links=[list(g) for g in d.links], note=d.model_note)
    return json.dumps(out)


def example_list() -> str:
    rows = []
    for k, e in EXAMPLES.items():
        rows.append(dict(key=k, title=e.title, group=e.group))
    return json.dumps(rows)


def load_example(key: str) -> str:
    e = EXAMPLES[key]
    p = e.build()
    sim = dict(p.sim); sim.update(e.sim or {})
    d = p.to_dict()
    d["sim"] = _clean(sim)
    info = dict(key=key, title=e.title, group=e.group, objective=getattr(e, "objective", ""), theory=getattr(e, "theory", ""),
                steps=list(getattr(e, "steps", []) or []), limits=getattr(e, "limits", ""), questions=list(getattr(e, "questions", []) or []))
    return json.dumps(dict(project=d, info=_clean(info)))


def sprite_names(project_json: str) -> str:
    """Artwork file (without .svg) to draw for each component: resistor colour bands, capacitor value, pot knob, LED colour ..."""
    d = json.loads(project_json)
    out = {}
    for c in d["components"]:
        df = parts.REGISTRY.get(c["type"])
        if df is None or df.sprite is None:
            continue
        out[c["id"]] = _sprite_name(df, c.get("params", {}))
    return json.dumps(out)


def _nearest(values, x):
    x = max(x, 1e-30)
    return min(values, key=lambda v: abs(math.log(v / x)))


def _sprite_name(d, prm):
    t = d.type
    if t == "resistor":
        v = _nearest(RES_VALUES or [1000.0], float(prm.get("R", 1000)))
        return "res_" + f"{v:g}"
    if t == "capacitor":
        uF = _nearest(ECAP, float(prm.get("C", 1e-4)) * 1e6)
        return f"ecap_{uF:g}"
    if t == "capacitor_ceramic":
        uF = _nearest(list(CAP_FILES), float(prm.get("C", 1e-7)) * 1e6)
        return f"cap_{CAP_FILES[uF]}"
    if t == "led":
        return f"led-{prm.get('color', 'red')}"
    if t == "pot":
        return f"pot_{int(round(min(max(float(prm.get('pos', 0.5)), 0), 1) * 10))}"
    if t == "switch":
        return "toggle_on" if prm.get("closed") else "toggle_off"
    if t == "buzzer":
        return "buzzer-active" if prm.get("kind", "active") == "active" else "buzzer-piezo"
    return d.sprite[0]


def _decimate(x, y, n=MAX_POINTS):
    x = np.asarray(x, dtype=float); y = np.asarray(y, dtype=float)
    if len(x) <= n:
        return x, y
    idx = np.unique(np.linspace(0, len(x) - 1, n).astype(int))
    return x[idx], y[idx]


def run(project_json: str, sim_json: str = "{}", key: str = "") -> str:
    """Validate and simulate. Never raises: errors come back as {ok: false, error, diagnostics}."""
    try:
        d = json.loads(project_json)
        sim = d.pop("sim", None) or {}
        sim.update(json.loads(sim_json or "{}"))
        p = Project.from_dict(d)
        p.sim.update(sim)
        diags = validate_project(p)
        errs = [x for x in diags if x.severity == "error"]
        if errs:
            return json.dumps(dict(ok=False, error="; ".join(x.message for x in errs), diagnostics=_diag(diags)))
        eng, res = run_sync(p)
    except SimError as ex:
        return json.dumps(dict(ok=False, error=str(ex), diagnostics=_diag(getattr(ex, "diagnostics", []))))
    except Exception as ex:                                                  # noqa: BLE001
        return json.dumps(dict(ok=False, error=f"{type(ex).__name__}: {ex}", diagnostics=[]))
    sigs = {}
    for name, s in res.signals.items():
        x, y = _decimate(s.x, s.y)
        sigs[name] = dict(x=_clean(x), y=_clean(y), xlabel=s.xlabel, ylabel=s.ylabel, kind=s.kind, group=s.group, logx=s.logx, logy=s.logy)
    out = dict(ok=True, engine=res.engine,
               measurements=[dict(name=m.name, value=_clean(m.value), unit=m.unit, source=m.source, note=m.note) for m in res.measurements],
               signals=sigs, table=_clean(res.table), instruments=_instruments(res.instruments), diagnostics=_diag(res.diagnostics),
               serial=res.info.get("serial_text", ""))
    out["comp"] = _component_state(p, res)
    e = EXAMPLES.get(key)
    if e is not None and getattr(e, "check", None):
        try:
            out["checks"] = [dict(name=c.name, passed=bool(c.passed), detail=c.detail) for c in e.check(p, res)]
        except Exception:                                                    # noqa: BLE001
            out["checks"] = []
    return json.dumps(out)


def _instruments(inst):
    out = {}
    for ref, d in inst.items():
        d = dict(d)
        if d.get("type") == "scope" and "t" in d:
            t = np.asarray(d["t"], dtype=float)
            idx = np.unique(np.linspace(0, len(t) - 1, min(len(t), 6000)).astype(int)) if len(t) > 6000 else slice(None)
            for k in ("t", "ch1", "ch2"):
                if k in d and d[k] is not None:
                    d[k] = np.asarray(d[k], dtype=float)[idx]
        out[ref] = _clean(d)
    return out


def _diag(diags):
    return [dict(severity=x.severity, source=x.source, message=x.message, component=x.component_id) for x in diags]


def _component_state(p, res):
    """Per-component display values: LED glow, motor, meter readings (final value of the run)."""
    rows = {r["ref"]: r for r in res.table} if res.table and isinstance(res.table[0], dict) and "ref" in res.table[0] else {}
    out = {}
    for c in p.components.values():
        st = {}
        if c.type == "led":
            sig = res.signals.get(f"I({c.ref})")
            i = float(sig.y[-1]) if sig is not None and len(sig.y) else (rows[c.ref]["I"] if c.ref in rows else None)
            if i is not None:
                st["glow"] = max(0.0, min(1.0, float(i) / 0.01))
        if c.ref in res.instruments:
            st["inst"] = _clean(res.instruments[c.ref])
        if st:
            out[c.id] = st
    return out
